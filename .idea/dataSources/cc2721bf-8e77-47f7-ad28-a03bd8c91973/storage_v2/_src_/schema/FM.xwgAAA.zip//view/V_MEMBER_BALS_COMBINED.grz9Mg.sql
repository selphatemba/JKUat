create view V_MEMBER_BALS_COMBINED as
  SELECT
    DISTINCT m.MEMBER_NO,
    reg.ID,
    reg.NAME,
    coalesce(reg.EE_BAL, 0)+coalesce(unreg.EE_BAL,0),
    coalesce(reg.EE_CONTR, 0)+coalesce(unreg.EE_CONTR, 0),
    coalesce(reg.EE_INTR, 0)+coalesce(unreg.EE_INTR, 0),
    coalesce(reg.EE_CLOSING, 0)+coalesce(unreg.EE_CLOSING, 0),
    coalesce(reg.ER_BAL, 0)+coalesce(unreg.ER_BAL, 0),
    coalesce(reg.ER_INTR, 0)+coalesce(unreg.ER_INTR, 0),
    coalesce(reg.ER_CONTR, 0)+coalesce(unreg.ER_CONTR, 0),
    coalesce(reg.ER_CLOSING, 0)+coalesce(unreg.ER_CLOSING, 0),
    coalesce(reg.AVC_BAL, 0)+coalesce(unreg.AVC_BAL, 0),
    coalesce(reg.AVC_INTR, 0)+coalesce(unreg.AVC_INTR, 0),
    coalesce(reg.AVC_CONTR, 0)+coalesce(unreg.AVC_CONTR,0),
    coalesce(reg.AVC_CLOSING, 0)+coalesce(unreg.AVC_CLOSING, 0),
    reg.AS_AT,
    reg.AP_ID,
    reg.scheme_id,
    reg.status
  FROM MEMBERS m LEFT JOIN V_MEMBER_BALS_REG reg on m.MEMBER_NO=reg.MEMBERNO LEFT JOIN V_MEMBER_BALS_UNREG unreg on m.MEMBER_NO=unreg.MEMBERNO
  ORDER BY m.MEMBER_NO ASC
/

