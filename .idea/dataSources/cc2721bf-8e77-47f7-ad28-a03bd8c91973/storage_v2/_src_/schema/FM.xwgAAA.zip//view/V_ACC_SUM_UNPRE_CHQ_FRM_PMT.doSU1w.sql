create view V_ACC_SUM_UNPRE_CHQ_FRM_PMT as
  select coalesce(sum(coalesce(ucp.CREDIT, 0)), 0)-coalesce(sum(coalesce(ucp.DEBIT, 0)), 0) ucptotal from V_ACC_UNPRESCHQS_FRM_PAYMENTS ucp
/

