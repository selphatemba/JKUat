create view V_AR_CONTPAY_TRANSFER_INS as
  select
    member_no,
    mem.surname||', '||mem.firstname||' '||other_names member_name,
    mem.SCHEME_ID as SCHEME_ID,
    con.DATE_PAID AS DATE_PAID,
    to_char(mem.DATE_JOINED_SCHEME,  'dd/MM/yyyy') join_date,
    (select name from sponsors where id = (select sponsor_id from companies where id = mem.company_id)) sponsor,
    'Transfers' reason,sum(coalesce(con.EE, 0) + coalesce(con.ER, 0) + coalesce( con.AVC, 0) + coalesce(con.AVCER, 0)) transfer,
    decode(mem.MBSHIP_STATUS, 'NOTIFIED', 'Notified','RETIRED' , 'Retired', 'RETIRED_ILL_HEALTH', 'Ill-health', 'DEATH_IN_SERVICE', 'Death in Service', mem.MBSHIP_STATUS) MBSHIP_STATUS,
    to_char(con.date_paid, 'Month') month_paid
  from members mem, contributions con where con.STATUS = 'TRANSFERS' and con.member_id = mem.id
  group by mem.id, member_no, mem.surname||', '||mem.firstname||' '||other_names,
    to_char(mem.DATE_JOINED_SCHEME,  'dd/MM/yyyy'),mem.company_id,mem.MBSHIP_STATUS,
    to_char(con.date_paid, 'Month'), mem.SCHEME_ID, con.DATE_PAID
/

