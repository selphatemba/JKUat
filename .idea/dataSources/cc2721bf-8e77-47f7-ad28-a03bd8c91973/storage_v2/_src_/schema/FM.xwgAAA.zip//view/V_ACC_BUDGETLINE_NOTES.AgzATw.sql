create view V_ACC_BUDGETLINE_NOTES as
  select
    pl.ID plId,
    p.SCHEME_ID,
    bi.CODE biCode,
    bi.NAME biName,
    coalesce(bd.NAME, '-') department,
    (select coalesce(sum(coalesce(ba.AMOUNT, 0)), 0) from BUDGET_ALLOCATIONS ba INNER JOIN ACCOUNTING_PERIODS ap on ba.AP_ID = ap.ID where ba.ITEM_ID=bi.ID and ap.FROM_DATE>=(select date_from from V_GENERAL_REPORTS_PARAMS) and ap.TO_DATE<=(select date_to from V_GENERAL_REPORTS_PARAMS)) initial_alloc,
    (select coalesce(sum(coalesce(ba.TRANSFER_IN, 0)), 0) from BUDGET_ALLOCATIONS ba INNER JOIN ACCOUNTING_PERIODS ap on ba.AP_ID = ap.ID where ba.ITEM_ID=bi.ID and ap.FROM_DATE>=(select date_from from V_GENERAL_REPORTS_PARAMS) and ap.TO_DATE<=(select date_to from V_GENERAL_REPORTS_PARAMS)) transfer_in,
    (select coalesce(sum(coalesce(ba.TRANSFER_OUT, 0)), 0) from BUDGET_ALLOCATIONS ba INNER JOIN ACCOUNTING_PERIODS ap on ba.AP_ID = ap.ID where ba.ITEM_ID=bi.ID and ap.FROM_DATE>=(select date_from from V_GENERAL_REPORTS_PARAMS) and ap.TO_DATE<=(select date_to from V_GENERAL_REPORTS_PARAMS)) transfer_out,
    (select coalesce(sum(coalesce(ba.AMOUNT_USED, 0)), 0) from BUDGET_ALLOCATIONS ba INNER JOIN ACCOUNTING_PERIODS ap on ba.AP_ID = ap.ID where ba.ITEM_ID=bi.ID and ap.FROM_DATE>=(select date_from from V_GENERAL_REPORTS_PARAMS) and ap.TO_DATE<=(select date_to from V_GENERAL_REPORTS_PARAMS)) amount_used,
    (select coalesce(sum(coalesce(ba.SUPLEMENT, 0)), 0) from BUDGET_ALLOCATIONS ba INNER JOIN ACCOUNTING_PERIODS ap on ba.AP_ID = ap.ID where ba.ITEM_ID=bi.ID and ap.FROM_DATE>=(select date_from from V_GENERAL_REPORTS_PARAMS) and ap.TO_DATE<=(select date_to from V_GENERAL_REPORTS_PARAMS)) supplement,
    (select coalesce(sum(coalesce(ba.AMOUNT, 0)), 0)+coalesce(sum(coalesce(ba.TRANSFER_IN, 0)), 0)+coalesce(sum(coalesce(ba.SUPLEMENT, 0)), 0)-coalesce(sum(coalesce(ba.TRANSFER_OUT, 0)), 0) from BUDGET_ALLOCATIONS ba INNER JOIN ACCOUNTING_PERIODS ap on ba.AP_ID = ap.ID where ba.ITEM_ID=bi.ID and ap.FROM_DATE>=(select date_from from V_GENERAL_REPORTS_PARAMS) and ap.TO_DATE<=(select date_to from V_GENERAL_REPORTS_PARAMS)) total_budget_alloc,
    (select coalesce(sum(coalesce(ba.BALANCE, 0)), 0) from BUDGET_ALLOCATIONS ba INNER JOIN ACCOUNTING_PERIODS ap on ba.AP_ID = ap.ID where ba.ITEM_ID=bi.ID and ap.FROM_DATE>=(select date_from from V_GENERAL_REPORTS_PARAMS) and ap.TO_DATE<=(select date_to from V_GENERAL_REPORTS_PARAMS)) balance,
    p.PMT_DATE,
    pl.SC_VALUE,
    pl.SPOT_RATE,
    pl.BC_VALUE,
    pl.PARTICULARS,
    crDr.NAME creditorDebtor,
    pl.ACCOUNT_ID,
    a.NAME acountName,
    a.CODE accountCode
  from PAYMENT_LINES pl
    INNER JOIN payments p on pl.PAYMENT_ID = p.ID
    LEFT JOIN CREDITOR_DEBTOR crDr on p.CREDITORDEBTOR_ID = crDr.ID
    INNER JOIN BUDGET_ITEMS bi on pl.BUDGETLINE_ID = bi.ID
    LEFT JOIN BUDGET_DEPARTMENT bd on bi.BUDGETDEPARTMENT_ID = bd.ID
    INNER JOIN ACCOUNTS a on pl.ACCOUNT_ID=a.ID
  where p.SCHEME_ID=(select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) and p.GLBATCH_ID is not NULL
        and p.PMT_DATE BETWEEN (select date_from from V_GENERAL_REPORTS_PARAMS grp) and (select date_to from V_GENERAL_REPORTS_PARAMS grp) and pl.SC_VALUE>0 ORDER BY p.PMT_DATE ASC
/

