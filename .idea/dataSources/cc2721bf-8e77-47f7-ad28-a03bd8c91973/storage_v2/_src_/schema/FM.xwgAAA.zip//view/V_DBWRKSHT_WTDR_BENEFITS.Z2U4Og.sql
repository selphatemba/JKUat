create view V_DBWRKSHT_WTDR_BENEFITS as
  select
    (select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) SCHEME_ID,
    date_certified,
    coalesce(entitlement, 0) entitlement,
    coalesce(TOT_LIAB, 0) liabilities,
    coalesce(er_tot, 0) er_tot,
    coalesce(deferred, 0) deferred_safe,
    coalesce(EE, 0) EE_CONTR,
    (((coalesce(ee_tot, 0) + coalesce(er_tot, 0)) - (coalesce(deferred, 0) + coalesce(DEFFERED_EE, 0) + coalesce(DEFFERED_REG, 0) + coalesce(DEFERED_UNREG, 0)))) payable,
    TO_CHAR(date_of_exit, 'dd/MM/yyyy') date_of_exit_fmt,
    (coalesce(er_tot, 0)+coalesce(ee_tot, 0)) tot_benefits
  from benefits where id= (select grp.BENEFITS_ID from V_GENERAL_REPORTS_PARAMS grp)
/

