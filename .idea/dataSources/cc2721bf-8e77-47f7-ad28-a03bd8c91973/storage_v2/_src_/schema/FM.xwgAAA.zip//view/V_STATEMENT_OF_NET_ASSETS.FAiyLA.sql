create view V_STATEMENT_OF_NET_ASSETS as
  SELECT
    replace(replace(replace(replace(st.CATEGORY, '<b>', ''), '</b>', ''), '<i>', ''), '</i>', '') category,
    st.P1 p1,
    st.p2 p2,
    st.DETAILID detailId,
    replace(replace(replace(replace(st.HEADER, '<b>', ''), '</b>', ''), '<i>', ''), '</i>', '') header,
    replace(replace(replace(replace(st.DETAIL, '<b>', ''), '</b>', ''), '<i>', ''), '</i>', '') detail,
    st.BALANCE,
    st.CATEGORY pre_category,
    replace(replace(replace(replace(st.STMTGROUP, '<b>', ''), '</b>', ''), '<i>', ''), '</i>', '') stmt_group,
    NULL pre_p2,
    NULL pre_detailId,
    NULL pre_header,
    NULL pre_detail,
    st.BALPREV,
    st.SCHEME_ID
  FROM STMT_OF_CHANGES_IN_ASSETS st ORDER BY P1 ASC
/

