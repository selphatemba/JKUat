create view V_BENEFITS_LISTING_D as
  with params as (
      select (select grp.DATE_FROM from V_GENERAL_REPORTS_PARAMS grp) as fdate, (select grp.DATE_TO from V_GENERAL_REPORTS_PARAMS grp) as tdate, (select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) schemep from dual
  )select
     to_char(TO_DATE(par.fdate), 'dd/MM/yyyy') from_date,
     to_char(TO_DATE(par.tdate), 'dd/MM/yyyy') to_date,
     me.member_no,
     me.surname||' '||me.FIRSTNAME||' '||me.other_names name,
     SUBSTR(me.gender, 0, 1) gender,
     to_char(me.dob, 'dd/MM/yyyy') dob,
     to_char(me.date_joined_scheme, 'dd/MM/yyyy') date_joined,
     to_char(b.date_of_exit, 'dd/MM/yyyy') date_of_exit,
     to_char(b.DATE_OF_CALCULATION, 'dd/MM/yyyy') DATE_OF_CALCULATION,
     rx.reason,
     bp.gross,
     bp.WITHOLDING_TAX,
     coalesce(NET_PAYMENT, 0) NET_PAYMENT,
     me.SCHEME_ID,
     bp.TYPE
   from BENEFITS b
     inner join params par on 'join' = 'join'
     INNER join members me on me.exit_id = b.ID
     left join BENEFIT_PAYMENTS bp on b.ID = bp.BENEFIT_ID
     INNER join reasons_for_exit rx on rx.id = b.reasonforexit_id
   where b.DATE_OF_EXIT between fdate and tdate AND me.SCHEME_ID=schemep ORDER BY MEMBER_NO
/

