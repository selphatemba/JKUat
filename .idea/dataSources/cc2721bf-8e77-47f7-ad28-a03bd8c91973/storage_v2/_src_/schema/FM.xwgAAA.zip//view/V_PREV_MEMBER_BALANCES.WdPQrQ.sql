create view V_PREV_MEMBER_BALANCES as
  SELECT ap.ID ad_id,
            member_id,
            ----------------------------AVC-------------------------------
            SUM (
               DECODE (
                  cb.status,
                  'REGISTERED',   NVL (avc_bal, 0)
                                + NVL (AVC_CONTR, 0)
                                + NVL (avc_withdr_intr, 0)
                                + NVL (avc_intr, 0)
                                + NVL (avc_balintr, 0)
                                - NVL (avc_withdr, 0)
                                + NVL (avc_rsv_income, 0)
                                ----avcer
                                + NVL (avcer_bal, 0)
                                + NVL (avcer_contr, 0)
                                + NVL (avcer_withdr_intr, 0)
                                + NVL (avcer_balintr, 0)
                                + NVL (avcer_intr, 0)
                                - NVL (avc_withdr, 0)
                                + NVL (avcer_rsv_income, 0)
                                ---avcs Transfers
                                + NVL (transfer_avc_bal, 0)
                                + NVL (transfer_avc_balintr, 0)
                                + NVL (transfer_avc, 0)
                                + NVL (transfer_avc_intr, 0)
                                + NVL (transfer_avcer_bal, 0)
                                + NVL (transfer_avcer_balintr, 0)
                                + NVL (transfer_avcer, 0)
                                + NVL (transfer_avcer_intr, 0),
                  0))
               REG_av_Bal,
            SUM (
               DECODE (
                  cb.status,
                  'UNREGISTERED',   NVL (avc_bal, 0)
                                  + NVL (AVC_CONTR, 0)
                                  + NVL (avc_withdr_intr, 0)
                                  + NVL (avc_intr, 0)
                                  + NVL (avc_balintr, 0)
                                  - NVL (avc_withdr, 0)
                                  + NVL (avc_rsv_income, 0)
                                  ----avcer
                                  + NVL (avcer_bal, 0)
                                  + NVL (avcer_contr, 0)
                                  + NVL (avcer_withdr_intr, 0)
                                  + NVL (avcer_balintr, 0)
                                  + NVL (avcer_intr, 0)
                                  - NVL (avc_withdr, 0)
                                  + NVL (avcer_rsv_income, 0)
                                  ---avcs Transfers
                                  + NVL (transfer_avc_bal, 0)
                                  + NVL (transfer_avc_balintr, 0)
                                  + NVL (transfer_avc, 0)
                                  + NVL (transfer_avc_intr, 0)
                                  + NVL (transfer_avcer_bal, 0)
                                  + NVL (transfer_avcer_balintr, 0)
                                  + NVL (transfer_avcer, 0)
                                  + NVL (transfer_avcer_intr, 0),
                  0))
               UNREG_av_Bal,
            ----------------------------EMPLOYEE---------------------------balances plus interst
            SUM (
               DECODE (
                  cb.status,
                  'REGISTERED',   NVL (EE_BAL, 0)
                                + NVL (ee_balintr, 0)
                                + NVL (EE_CONTR, 0)
                                + NVL (ee_intr, 0)
                                - NVL (EE_WITHDR, 0)
                                + NVL (EE_WITHDR_INTR, 0)
                                + NVL (ee_rsv_income, 0)
                                + NVL (EE_PAYMENTS, 0)
                                + NVL (EE_PAYMENTS_INTR, 0)
                                --transfers ee
                                + NVL (transfer_ee_bal, 0)
                                + NVL (transfer_ee, 0)
                                + NVL (transfer_ee_intr, 0)
                                + NVL (transfer_ee_balintr, 0)
                                + NVL (reserve_income, 0),
                  0))
               REG_ee_bal,
            SUM (
               DECODE (
                  cb.status,
                  'UNREGISTERED',   NVL (EE_BAL, 0)
                                  + NVL (ee_balintr, 0)
                                  + NVL (EE_CONTR, 0)
                                  + NVL (ee_intr, 0)
                                  - NVL (EE_WITHDR, 0)
                                  + NVL (EE_WITHDR_INTR, 0)
                                  + NVL (ee_rsv_income, 0)
                                  + NVL (EE_PAYMENTS, 0)
                                  + NVL (EE_PAYMENTS_INTR, 0)
                                  --transfers ee
                                  + NVL (transfer_ee_bal, 0)
                                  + NVL (transfer_ee, 0)
                                  + NVL (transfer_ee_intr, 0)
                                  + NVL (transfer_ee_balintr, 0)
                                  + NVL (reserve_income, 0),
                  0))
               UNREG_ee_bal,
            ----------------------------EMPLOYER----------------------------
            SUM (
               DECODE (
                  cb.status,
                  'REGISTERED',   NVL (ER_BAL, 0)
                                + NVL (ER_CONTR, 0)
                                - NVL (ER_WITHDR, 0)
                                + NVL (ER_WITHDR_INTR, 0)
                                + NVL (ER_INTR, 0)
                                + NVL (er_balintr, 0)
                                + NVL (er_rsv_income, 0)
                                + NVL (ER_PAYMENTS, 0)
                                + NVL (ER_PAYMENTS_INTR, 0)
                                --transfersplus inte
                                + NVL (transfer_er_bal, 0)
                                + NVL (transfer_er_balintr, 0)
                                + NVL (transfer_er, 0)
                                + NVL (transfer_er_intr, 0),
                  0))
               REG_er_bal,
            SUM (
               DECODE (
                  cb.status,
                  'UNREGISTERED',   NVL (ER_BAL, 0)
                                  + NVL (ER_CONTR, 0)
                                  - NVL (ER_WITHDR, 0)
                                  + NVL (ER_WITHDR_INTR, 0)
                                  + NVL (ER_INTR, 0)
                                  + NVL (er_balintr, 0)
                                  + NVL (er_rsv_income, 0)
                                  + NVL (ER_PAYMENTS, 0)
                                  + NVL (ER_PAYMENTS_INTR, 0)
                                  --transfersplus inte
                                  + NVL (transfer_er_bal, 0)
                                  + NVL (transfer_er_balintr, 0)
                                  + NVL (transfer_er, 0)
                                  + NVL (transfer_er_intr, 0),
                  0))
               UNREG_er_bal
       FROM CLOSING_BALANCES cb, V_ACCOUNTING_PERIODS ap
      WHERE cb.ap_id = ap.PRV_AP_ID
   GROUP BY ap.ID, member_id
/

