create view V_ACC_GLREPORT_OPENING as
  select
    schemeId,
    accountId,
    narration,
    debitBal,
    creditBal,
    debits,
    credits,
    periodEnding,
    apId,
    accountName,
    accountCode
  from
    (
      SELECT
        acc.SCHEME_ID schemeId,
        acc.ID accountId,
        'Opening Balance as at '||(select to_char(grp.DATE_FROM) from V_GENERAL_REPORTS_PARAMS grp) as narration,
        coalesce(gab.DEBIT_BAL, 0) debitBal,
        coalesce(gab.CREDIT_BAL, 0) creditBal,
        gab.DEBITS debits,
        gab.CREDITS credits,
        gab.PERIOD_ENDING periodEnding,
        gab.AP_ID apId,
        acc.NAME accountName,
        acc.CODE accountCode
      FROM ACCOUNTS acc LEFT JOIN GL_ACCOUNT_BALANCES gab on gab.ACCOUNT_ID = acc.ID
      WHERE gab.AP_ID = (SELECT grp.PREVAPID
                         FROM V_GENERAL_REPORTS_PARAMS grp)
            AND gab.ACCOUNT_ID = (SELECT grp.account_id
                                  FROM V_GENERAL_REPORTS_PARAMS grp) and ROWNUM=1
    )
/

