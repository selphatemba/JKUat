create view V_AUDIT_TRAIL_NEW as
  SELECT ID,
    rpt.AUDIT_DESC,
    rpt.EVENT_TIME,
    rpt.EVENT_TYPE,
    rpt.IP_ADDRESS,
    rpt.MODULE,
    rpt.PROCESS_DET,
    rpt.USERNAME
  FROM AUDIT_TRAIL_RPT rpt
/

