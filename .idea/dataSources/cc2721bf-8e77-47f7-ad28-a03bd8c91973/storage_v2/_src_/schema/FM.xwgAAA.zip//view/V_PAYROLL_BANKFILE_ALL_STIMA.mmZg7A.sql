create view V_PAYROLL_BANKFILE_ALL_STIMA as
  select
    (select 'STIMA_SACCO' from dual) member_no,
    al.BANK_CODE,
    (select '01120069940000' from dual) ac_no,
    (select 'STIMA SACCO SOCIETY LTD' from dual) ac_name,
    al.BANKBRANCH_ID,
    al.TRANSFER_CODE,
    al.BRANCH_CODE,
    (select a.PAYROLL_DATE from V_PAYROLL_BANKFILE_3X a where ROWNUM=1) payroll_date,
    (select sum(al.PENSION) from V_PAYROLL_BANKFILE_3X al INNER JOIN BANKS b on al.BANK_CODE=b.CODE where b.CODE='100') PENSION,
    (select a.COMMENTS from V_PAYROLL_BANKFILE_3X a where ROWNUM=1) COMMENTS,
    PENSIONER_ID
  from V_PAYROLL_BANKFILE_3X al INNER JOIN BANKS b on al.BANK_CODE=b.CODE where b.CODE='100' AND ROWNUM=1
/

