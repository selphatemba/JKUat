create view V_ACC_TAX_SCH_VAT as
  select
    p.PMT_DATE,
    p.SCHEME_ID,
    ln.PARTICULARS,
    ln.TAXABLE gross,
    ln.TAX tax,
    ln.NET_PAYMENT net_paid,
    tps.CATEGORY category,
    tps.AMOUNT_DUE total_schedule_amt,
    tps.DATE_FROM,
    tps.DATE_TO,
    tps.DATE_GENERATED,
    cd.NAME,
    case when cd.TAX_PIN is NULL then '-' else cd.TAX_PIN END pin,
    case when tps.POSTED=0 then 'Yes' else 'No' END posted,
    ln.INVOICENO, ln.id
  from TAX_PMT_LINES ln INNER JOIN TAX_PMT_SCHEDULE tps ON ln.SCHEDULE_ID = tps.ID
    INNER JOIN PAYMENTS p ON ln.payment_id=p.ID
    INNER JOIN CREDITOR_DEBTOR cd ON p.CREDITORDEBTOR_ID = cd.ID
  where tps.ID=(select grp.tax_schedule_id from V_GENERAL_REPORTS_PARAMS grp)
/

