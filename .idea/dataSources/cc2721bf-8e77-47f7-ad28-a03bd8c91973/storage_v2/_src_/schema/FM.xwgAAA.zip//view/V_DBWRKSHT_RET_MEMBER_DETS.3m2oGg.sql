create view V_DBWRKSHT_RET_MEMBER_DETS as
  with params as (
      select (select grp.MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS grp) member_param, (select grp.AP_ID from V_GENERAL_REPORTS_PARAMS grp) ap_param, (select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) scheme_param from dual
  )
  SELECT M.ID, SCHEME_ID,
    (select c.name from  companies c,members m, params p where c.id=m.company_id and m.id=p.member_param) company,
    (select to_date from accounting_periods where id = p.ap_param) to_date,
    (select contributions from interest_rates where scheme_id = m.scheme_id and status = 'REGISTERED' and type = 'DECLARED' and ap_id = p.ap_param) interest,
    (select normal from retirement_ages re where memberclass_id = m.mclass_id and re.gender = mb.gender) retire_age_normal,
    (add_months(m.dob , 12*(select normal from RETIREMENT_AGES where rownum=1 and RETIREMENT_AGES.MEMBERCLASS_ID=m.MCLASS_ID and RETIREMENT_AGES.GENDER = mb.GENDER))) retire,
    (select age_at_exit from benefits where id = exit_id) date_of_exit,
    (select date_of_exit from benefits where id = exit_id) exited_on,
    (SELECT SCHEME_NAME FROM SCHEMES WHERE ID = M.SCHEME_ID) SCHEME,
    payroll_no,
    ben.AGE_AT_EXIT age,
    DECODE(mb.TITLE,'MR','Mr.', 'MRS', 'Mrs.', 'DR', 'Dr.', 'PROF', 'Prof.', 'REV', 'Rev.', 'ENG', 'Eng.', 'MISS', 'Ms.', '')
    ||' '||mb.SURNAME
    ||', '||mb.FIRSTNAME
    ||' '||mb.OTHER_NAMES NAME,
    M.MEMBER_NO,
    mb.GENDER,
    M.DATE_JOINED_SCHEME,
    M.DATE_OF_EMPL,
    M.DEPARTMENT_NO,
    mb.DOB,
    (select coalesce(b.annual_salary, 0) from BENEFITS b INNER JOIN MEMBERS mb ON b.ID = mb.EXIT_ID where mb.ID=m.ID) emolument
  FROM MEMBERS M
    LEFT JOIN BENEFITS ben on M.EXIT_ID = ben.ID
    INNER JOIN MEMBERS_BIOS mb ON M.MEMBERBIO_ID = mb.ID, params p WHERE  M.ID = p.member_param
/

