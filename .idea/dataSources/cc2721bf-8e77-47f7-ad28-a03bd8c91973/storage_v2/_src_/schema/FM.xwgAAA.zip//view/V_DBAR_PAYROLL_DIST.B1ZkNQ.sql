create view V_DBAR_PAYROLL_DIST as
  with quarter as (
      select (select QUARTER from V_AR_PARAMS) q, (select SCHEME_ID from V_AR_PARAMS) scheme_id, (select YEAR FROM V_AR_PARAMS) yr from dual
  ),quarterdef as (
      select case
             when q = 1 then 'JAN'
             when q = 2 then 'APR'
             when q = 3 then 'JUL'
             when q = 4 then 'OCT'
             else ''
             end as first_month,
             case
             when q = 1 then 'FEB'
             when q = 2 then 'MAY'
             when q = 3 then 'AUG'
             when q = 4 then 'NOV'
             else ''
             end as second_month,
             case
             when q = 1 then 'MAR'
             when q = 2 then 'JUN'
             when q = 3 then 'SEP'
             when q = 4 then 'DEC'
             else ''
             end as third_month
      from quarter qt
  )
  select
(select SCHEME_ID from V_AR_PARAMS) scheme_id,
    first_month,
    second_month,
    third_month,
    --PAYROLL FOR FIRST MONTH OF QUARTER
    (select sum((coalesce(net,0)+coalesce(arreas,0))+(coalesce(deds,0)+coalesce(tax,0))) from payroll pay, pensioners pen where scheme_id=qtr.scheme_id and pay.pensioner_id = pen.id  and pay.month = pe.first_month and pay.year = qtr.yr) first_p_in_qtr,
    --(select date_prepared from payroll_batches payb where payb.id = (select distinct batch_id from payroll pay where  payb.month = first_month and pay.year = qtr.yr ) and payb.date_prepared is not null ) first_p_date,
    --PAYROLL FOR FIRST MONTH OF QUARTER
    (select sum((coalesce(net,0)+coalesce(arreas,0))+(coalesce(deds,0)+coalesce(tax,0))) from payroll pay, pensioners pen where scheme_id=qtr.scheme_id and pay.pensioner_id = pen.id  and pay.month = pe.second_month and pay.year = qtr.yr) second_p_in_qtr,
    --(select date_prepared from payroll_batches payb where payb.id = (select distinct batch_id from payroll pay where  payb.month = second_month and pay.year = qtr.yr) and payb.date_prepared is not null ) second_p_date,
    --PAYROLL FOR FIRST MONTH OF QUARTER
    (select sum((coalesce(net,0)+coalesce(arreas,0))+(coalesce(deds,0)+coalesce(tax,0))) from payroll pay, pensioners pen where scheme_id=qtr.scheme_id and pay.pensioner_id = pen.id  and pay.month = pe.third_month and pay.year = qtr.yr) third_p_in_qtr
  --(select date_prepared from payroll_batches payb where payb.id = (select distinct batch_id from payroll pay where  payb.month = third_month and pay.year = qtr.yr ) and payb.date_prepared is not null ) third_p_date
  from quarterdef pe,  quarter qtr
/

