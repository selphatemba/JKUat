create view V_ASS_INCOME_PER_CLASS as
  with cache as (
      select (CASE
              WHEN UPPER(inv.INVESTMENT_CATEGORY ) LIKE '%BOND%' THEN (coalesce(txns.AMOUNT, 0)*coalesce(txns.SPOT_RATE, 1))
              when UPPER(inv.INVESTMENT_CATEGORY ) LIKE '%SECURIT%' THEN (coalesce(txns.AMOUNT, 0)*coalesce(txns.SPOT_RATE, 1))
              when UPPER(inv.INVESTMENT_CATEGORY ) LIKE '%EQUITY%' THEN (coalesce(txns.AMOUNT, 0)*coalesce(txns.SPOT_RATE, 1))
              when UPPER(inv.INVESTMENT_CATEGORY ) LIKE '%PROPERTY%' THEN (coalesce(txns.AMOUNT, 0)*coalesce(txns.SPOT_RATE, 1))
              ELSE (coalesce(txns.AMOUNT, 0)*coalesce(txns.SPOT_RATE, 1)) END )amount, txns.ID as txnid
      from INVESTMENT_TXNS txns LEFT JOIN INVESTMENTS inv ON txns.INVESTMENT_ID=inv.ID
  )
  SELECT decode(inv.INVESTMENT_CATEGORY ,'GOVERNMENT_SECURITIES', 'GOVERNMENT SECURITIES' , 'CORPORATE_BONDS' , 'CORPORATE BONDS', 'PROPERTY' , 'PROPERTY', 'EQUITY', 'EQUITY', 'FIXED_TERM_DEPOSIT','FIXED TERM DEPOSITS', 'COLLECTIVE_INVESTMENTS','COLLECTIVE INVESTMENTS', 'CASH_CALL_DEPOSITS','CASH AND CALL DEPOSITS',
                inv.INVESTMENT_CATEGORY) INVESTMENT_CATEGORY, txns.PARTICULARS, sum(
             coalesce(txns.AMOUNT, 0)*(coalesce(txns.SPOT_RATE, 1))
         )income, c.amount as amount_invested, txns.SCHEME_ID
  FROM INVESTMENT_TXNS txns
    INNER JOIN INVESTMENTS inv ON txns.INVESTMENT_ID = inv.ID
    LEFT JOIN cache c on txns.ID=c.txnid
  where (LOWER(txns.PARTICULARS) LIKE '%gain%'
         or LOWER(txns.PARTICULARS) LIKE '%interest%'
         or txns.PARTICULARS LIKE '%rebate%'
         or txns.PARTICULARS LIKE '%income%'
         or txns.PARTICULARS LIKE '%profit%'
         or txns.PARTICULARS LIKE '%receivable%'
         or txns.PARTICULARS LIKE '%revaluation%')
        AND (lower(txns.PARTICULARS) NOT LIKE '%loss%'
          --AND lower(i.PARTICULARS) NOT LIKE '%receivable%'
          --AND lower(i.PARTICULARS) NOT LIKE '%recievable%'
        )
        AND txns.TRANS_DATE BETWEEN (select grp.DATE_FROM from V_GENERAL_REPORTS_PARAMS grp) and (select grp.DATE_TO from V_GENERAL_REPORTS_PARAMS grp)
        AND txns.SCHEME_ID = (select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp)
  GROUP BY INVESTMENT_CATEGORY, txns.PARTICULARS, c.amount, txns.SCHEME_ID
/

