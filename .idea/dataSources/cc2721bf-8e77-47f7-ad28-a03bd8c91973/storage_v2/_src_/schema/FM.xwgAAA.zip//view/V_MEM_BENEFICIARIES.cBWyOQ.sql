create view V_MEM_BENEFICIARIES as
  SELECT b.ID ben_id,
    MEMBER_ID,
         b.FIRSTNAME || ' ' || OTHERNAMES || ' ' || b.SURNAME full_names,
    b.ID_NO,
    DATE_OF_APPOINTMENT,
         case when upper(b.RELATIONSHIP)='HUSBAND' then NULL when upper(b.RELATIONSHIP)='WIFE' then NULL ELSE b.DOB end dob,
         decode(b.GENDER, 'MALE', 'Male', 'FEMALE', 'Female') gender,
    GUARDIAN,
    GUARDIAN_RELATION,
         NVL (LUMPSUM_ENTITLEMENT, 0) LUMPSUM_ENTITLEMENT,
    MONTHLY_ENTITLEMENT,
    NOMINATION_FORM,
         INITCAP (case when upper(RELATIONSHIP)='WIFE' then 'SPOUSE' when upper(RELATIONSHIP)='HUSBAND' then 'SPOUSE' when upper(RELATIONSHIP)='SON' then 'CHILD' when upper(RELATIONSHIP)='DAUGHTER' then 'CHILD' else '' END) RELATIONSHIP,
         INITCAP (STATUS) STATUS,
         INITCAP (RELSHIP_CATEGORY) RELSHIP_CATEGORY,
         DECODE (INITCAP (RELATIONSHIP),  'Wife', 1,  'Husband', 1,  0)
           RELATION_spouse,
         DECODE (INITCAP (RELATIONSHIP),  'Sister', 1,  'Brother', 1,  0)
           RELATION_sibling,
         DECODE (INITCAP (RELATIONSHIP),  'Daughter', 1,  'Son', 1,  0)
           RELATION_child,
         DECODE (INITCAP (RELATIONSHIP),  'Father', 1,  'Mother', 1,  0)
           RELATION_parrent,
         DECODE (INITCAP (RELATIONSHIP),  'Other', 1,  NULL, 1,  0)
           RELATION_other,
         case when upper(b.RELATIONSHIP)='HUSBAND' then NULL when upper(b.RELATIONSHIP)='WIFE' then NULL else FLOOR ( (SYSDATE - NVL (b.DOB, b.dob)) / 365) end age,
         b.CELL_PHONE BEN_PHONE,
         mb.CELL_PHONE MEMBER_PHONE,
    m.SCHEME_ID
  FROM beneficiaries b
    LEFT JOIN MEMBERS m ON b.MEMBER_ID = m.ID
    LEFT JOIN MEMBERS_BIOS mb ON m.MEMBERBIO_ID = mb.ID WHERE m.ID>=(select MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS) and m.ID<=(select MEMBER_ID_TO from V_GENERAL_REPORTS_PARAMS) and m.ID in (select st.member_id from MEMSTMT_RPT_MEMIDS st) AND UPPER(b.STATUS)!='DIVORCED' AND UPPER(b.STATUS)!='DECEASED' AND (UPPER(b.RELATIONSHIP)='SON' OR UPPER(b.RELATIONSHIP)='DAUGHTER' OR UPPER(b.RELATIONSHIP)='HUSBAND' OR UPPER(b.RELATIONSHIP)='WIFE') and m.SCHEME_ID=(select SCHEME_ID from V_GENERAL_REPORTS_PARAMS)
/

