create view V_ACCOUNTING_PERIODS as
  SELECT ID,
          FROM_DATE,
          TO_DATE,
          PERIOD_TYPE,
          PERIOD_STATUS,
          SCHEME_ID,
          LAG (ID, 1, 0)
             OVER (PARTITION BY SCHEME_ID, period_type ORDER BY ID)
             prv_ap_id
     FROM accounting_periods
/

