create view V_MEMBER_MOVEMENT as
  SELECT scheme_id,
            date_joined_scheme,
            SUM (DECODE (MBSHIP_STATUS, 'ACTIVE', 1, 0)) ACTIVE_members,
            SUM (DECODE (MBSHIP_STATUS, 'DEATH_IN_SERVICE', 1, 0))
               dead_in_service_members,
            SUM (DECODE (MBSHIP_STATUS, 'DEFFERED', 1, 0)) DEFFERED_members,
            SUM (DECODE (MBSHIP_STATUS, 'RETIRED_ILL_HEALTH', 0))
               retired_ill_health_members,
            SUM (DECODE (MBSHIP_STATUS, 'RETIRED', 1, 0)) RETIRED_members,
            SUM (DECODE (MBSHIP_STATUS, 'WITHDRAWN', 1, 0)) WITHDRAWN_memmbers,
            SUM (DECODE (MBSHIP_STATUS, 'DELETED', 1, 0)) DELETED_memmbers,
            SUM (DECODE (MBSHIP_STATUS, 'NOTIFIED', 1, 0)) NOTIFIED_memmbers,
            SUM (DECODE (MBSHIP_STATUS, 'TRANSFERED', 1, 0))
               TRANSFERED_memmbers
       FROM Members
   GROUP BY scheme_id, date_joined_scheme
/

