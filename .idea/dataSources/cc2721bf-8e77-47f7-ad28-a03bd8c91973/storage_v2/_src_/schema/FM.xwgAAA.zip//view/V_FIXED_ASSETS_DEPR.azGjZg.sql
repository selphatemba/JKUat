create view V_FIXED_ASSETS_DEPR as
  select
    fa.scheme_id,
    ac.NAME,
    ac.DEPRECIATIONMETHOD,
    ac.DEPRECIATION_FACTOR,
    ac.MONTHS_TO_DEPRECIATE,
    ac.YEARS_TO_DEPRECIATE,
    ac.DESCR,
    fa.ASSET_CODE,
    fa.NAME,
    fa.DATE_RETIRED,
    fa.STATUS,
    coalesce(fa.ORIGINAL_COST, 0) original_cost,
    coalesce(fa.INITIAL_BOOK_ALUE, 0)initial_bv,
    coalesce(fa.PREV_VALUE, 0) prev_value,
    coalesce(fa.CURRENT_VALUE, 0) current_value,
    coalesce(fad.AMOUNT, 0) asset_depr_amt,
    coalesce(ad.AMOUNT, 0) asset_class_depr_amt,
    fa.CARETAKER,
    fa.LOCATION,
    fad.PREV_DEPDATE,
    fad.DATE_PROCESSED,
    dr.CODE dr_code,
    dr.NAME dr_name,
    cr.CODE cr_code,
    cr.NAME cr_name
  from FIXED_ASSET_DEPRECIATION fad
    INNER JOIN FIXED_ASSETS fa ON fad.FIXEDASSET_ID = fa.ID
    INNER JOIN ASSET_CLASSES ac on fa.ASSETCLASS_ID = ac.ID
    INNER JOIN ASSET_DEPRECIATION ad ON fad.CLASSDEPRECIATIONTXN_ID = ad.ID
    LEFT JOIN ACCOUNTS cr ON AD.CREDITACCOUNT_ID=cr.ID
    LEFT JOIN ACCOUNTS dr ON ad.DEBITACCOUNT_ID=dr.ID
  WHERE fa.SCHEME_ID=(select scheme_id from V_GENERAL_REPORTS_PARAMS) AND fad.DATE_PROCESSED BETWEEN (select DATE_FROM from V_GENERAL_REPORTS_PARAMS) and (select DATE_TO from V_GENERAL_REPORTS_PARAMS) ORDER BY DATE_PROCESSED ASC
/

