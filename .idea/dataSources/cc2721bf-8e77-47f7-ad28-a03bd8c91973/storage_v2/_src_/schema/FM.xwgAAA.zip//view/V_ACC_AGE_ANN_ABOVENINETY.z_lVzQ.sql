create view V_ACC_AGE_ANN_ABOVENINETY as
  select ID from invoices inv where inv.SCHEME_ID=(select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) and inv.TRANS_DATE<(select grp.AGEING_ANN_NINETY from GENERAL_REPORTS_PARAMS grp) and inv.TRANS_DATE<=(select grp.DATE_TO from GENERAL_REPORTS_PARAMS grp)
/

