create view V_GL as
  SELECT gl.ID,
    gl.GL_DATE,
    gl.CHEQUE_NO,
    gl.CREDIT,
    gl.DEBIT,
    gl.DESCR,
    gl.VOUCHER_NO,
    gl.ACCOUNT_ID,
    gl.ACCOUNTINGPERIOD_ID,
    gl.GLBATCH_ID,
    gl.SCHEME_ID,
    gl.GLBATCH_ID GL_BATCH_ID,
    gb.BATCH_DATE GL_BATCH_DATE,
    gb.POSTED GL_BATCH_POSTED
  FROM gl
    LEFT JOIN GL_BATCHES gb ON gl.GLBATCH_ID = gb.ID
/

