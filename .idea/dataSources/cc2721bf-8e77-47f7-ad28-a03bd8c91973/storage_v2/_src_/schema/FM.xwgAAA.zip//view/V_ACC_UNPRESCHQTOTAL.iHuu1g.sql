create view V_ACC_UNPRESCHQTOTAL as
  select (coalesce(sum(coalesce(u.CREDIT, 0)), 0)-coalesce(sum(coalesce(u.DEBIT, 0)), 0)) unpres_chq_total from UNPRESENTED_CHEQUE u where (CLEARED='NO' OR CLEARED IS NULL) AND U.SCHEME_ID=(select SCHEME_ID from V_GENERAL_REPORTS_PARAMS)
/

