create view V_DBWRKSHT_DIR_SPCH_PEN as
  select
    (select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) scheme_id,
    case when (be.RELATIONSHIP =  'DAUGHTER' or  RELATIONSHIP = 'SON') then 'Child Monthly Pension' else 'Spouse Monthly Pension' end relationship,
    sum( coalesce(be.pct_monthly/100, 0) * (coalesce(pe. TARGET_PENSION_PRE, 0) + coalesce(TARGET_PENSION_POST,0))  / (select count(*) from BENEFICIARIES where coalesce(PCT_MONTHLY, 0)>0 and (RELATIONSHIP = 'WIFE' or  RELATIONSHIP = 'HUSBAND') and member_id = pe.member_id))/sum((case when (be.RELATIONSHIP =  'DAUGHTER' or  RELATIONSHIP = 'SON') then ((select count(*) from BENEFICIARIES bi where bi.PCT_MONTHLY>0 and (RELATIONSHIP = 'DAUGHTER' or  RELATIONSHIP = 'SON') and member_id = pe.member_id)) else (select count(*) from BENEFICIARIES where coalesce(PCT_MONTHLY, 0)>0 and (RELATIONSHIP = 'WIFE' or  RELATIONSHIP = 'HUSBAND') and member_id = pe.member_id) end)/(case when (be.RELATIONSHIP =  'DAUGHTER' or  RELATIONSHIP = 'SON') then ((select count(*) from BENEFICIARIES bi where bi.PCT_MONTHLY>0 and (RELATIONSHIP = 'DAUGHTER' or  RELATIONSHIP = 'SON') and member_id = pe.member_id)) else (select count(*) from BENEFICIARIES where coalesce(PCT_MONTHLY, 0)>0 and (RELATIONSHIP = 'WIFE' or  RELATIONSHIP = 'HUSBAND') and member_id = pe.member_id) end)) amount,
    sum((case when (be.RELATIONSHIP =  'DAUGHTER' or  RELATIONSHIP = 'SON') then ((select count(*) from BENEFICIARIES bi where bi.PCT_MONTHLY>0 and (RELATIONSHIP = 'DAUGHTER' or  RELATIONSHIP = 'SON') and member_id = pe.member_id)) else (select count(*) from BENEFICIARIES where coalesce(PCT_MONTHLY, 0)>0 and (RELATIONSHIP = 'WIFE' or  RELATIONSHIP = 'HUSBAND') and member_id = pe.member_id) end)/(case when (be.RELATIONSHIP =  'DAUGHTER' or  RELATIONSHIP = 'SON') then ((select count(*) from BENEFICIARIES bi where bi.PCT_MONTHLY>0 and (RELATIONSHIP = 'DAUGHTER' or  RELATIONSHIP = 'SON') and member_id = pe.member_id)) else (select count(*) from BENEFICIARIES where coalesce(PCT_MONTHLY, 0)>0 and (RELATIONSHIP = 'WIFE' or  RELATIONSHIP = 'HUSBAND') and member_id = pe.member_id) end)) counter,
    0 tax,
    0 arrears,
    sum( coalesce(be.pct_monthly/100, 0) * (coalesce(pe. TARGET_PENSION_PRE, 0) + coalesce(TARGET_PENSION_POST,0))  / (select count(*) from BENEFICIARIES where coalesce(PCT_MONTHLY, 0)>0 and (RELATIONSHIP = 'WIFE' or  RELATIONSHIP = 'HUSBAND') and member_id = pe.member_id)) alloc
  from pensioners pe
    inner join beneficiaries be on be.member_id = pe.member_id
  where pe.ID =  (select PENSIONER_ID from V_GENERAL_REPORTS_PARAMS grp) and be.PCT_MONTHLY > 0
  group by
    case when (be.RELATIONSHIP =  'DAUGHTER' or  RELATIONSHIP = 'SON') then 'Child Monthly Pension' else 'Spouse Monthly Pension' end, be.pct_monthly
/

