create view V_PROP_SOLD_PROPERTIES as
  select
    inv.SCHEME_ID,
    inv.ID,
    inv.DATE_OF_COMM,
    inv.DESCR,
    inv.INITIAL_VALUE,
    inv.LOCALITY,
    inv.MARKET_VALUE,
    inv.NAME,
    inv.AREA,
    inv.CODE,
    inv.DEVELOPED,
    inv.LOCATION,
    inv.LR_NUMBER,
    coalesce(inv.ROAD, '-') ROAD,
    inv.TOWN,
    pm.NAME as MANAGER,
    (select count(u.ID) from UNITS u WHERE u.INVESTMENT_ID=inv.ID) as UNITS_COUNT,
    txns.SALE_VALUE,
    TXNS.TRANS_DATE,
    txns.PARTICULARS,
    txns.POSTED,
    txns.PURCHASE_MODE,
    txns.DEPOSIT,
    txns.BALANCE,
    txns.PREPARED_DATE,
    txns.CERTIFIED_DATE,
    txns.APPROVED_DATE,
    (CASE WHEN MARKET_VALUE>SALE_VALUE then 'Loss' ELSE 'Gain' END) GAIN_LOSS,
    txns.GAIN_LOSS GAIN_LOSS_AMOUNT,
    txns.INSTALMENTS,
    ag.FIRST_NAME||' '||ag.SUR_NAME AGENT,
    txns.AGENT_COMMISION,
    txns.REF_NO,
    pb.NAME BUYER,
    pb.CELL_PHONE BUYER_PHONE,
    pb.IDENTIFICATION BUYER_ID
  from INVESTMENTS inv
    INNER JOIN PROPERTY_MANAGERS pm ON inv.MANAGER_ID = pm.ID
    INNER JOIN INVESTMENT_TXNS txns ON inv.ID = txns.INVESTMENT_ID
    INNER JOIN PROPERTY_BUYERS pb ON txns.PROPERTYBUYER_ID = pb.ID
    LEFT JOIN PROPERTY_AGENTS ag ON txns.AGENT_ID = ag.ID
  where inv.INVESTMENT_CATEGORY='PROPERTY' and inv.SCHEME_ID=(select SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) AND inv.SOLD='YES' and txns.PARTICULARS LIKE '%Sale of Property%'
/

