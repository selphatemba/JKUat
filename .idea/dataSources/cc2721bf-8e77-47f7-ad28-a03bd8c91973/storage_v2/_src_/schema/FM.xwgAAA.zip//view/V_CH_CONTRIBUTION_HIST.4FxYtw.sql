create view V_CH_CONTRIBUTION_HIST as
  select
    (select max(date_paid) from contributions where member_id=co.member_id and rownum = 1) to_date,
    to_date(to_char(date_paid, 'Mon/yyyy'), 'Mon/yyyy') dated,
    to_char(date_paid, 'Mon/yyyy') month,
    to_char(to_date(month||'/'||year, 'MON/yyyy'), 'Mon/yyyy') con_month,
    to_char(date_paid, 'Mon') mon,
    to_char(date_paid, 'yyyy') yr,
    date_paid,
    max(salary) salary,
    (select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) scheme_id,
    (select MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS grp) member_id,
    sum(case when (co.status = 'UNREGISTERED' and co.type='NORMAL') then co.ee else 0
        end) ee_unreg, sum(case when (co.status = 'REGISTERED' and co.type='NORMAL') then (co.ee) else 0 end) ee_reg,
    sum(case when (co.status = 'UNREGISTERED' and co.type='ARREARS') then (0) else 0 end) ee_unreg_arrears, sum(case when (co.type='ARREARS') then (co.ee) else 0 end) ee_reg_arrears,
    sum(case when (co.status = 'UNREGISTERED' and co.type='TRANSFERS') then (co.ee +  + co.avc) else 0 end) ee_unreg_trans,
    sum(case when (co.status = 'REGISTERED' and co.type='TRANSFERS') then (co.ee + co.avc) else 0 end) ee_reg_trans,
    sum(case when (co.status = 'UNREGISTERED' and co.type='NORMAL') then co.er else 0 end) er_unreg,
    sum(case when (co.status = 'REGISTERED' and co.type='NORMAL') then (co.er) else 0 end) er_reg,
    sum(case when (co.status = 'UNREGISTERED' and type='ARREARS') then (0) else 0 end) er_unreg_arrears,
    sum(case when (co.type='ARREARS') then (co.er) else 0 end) er_reg_arrears,
    sum(case when (co.status = 'UNREGISTERED' and type='TRANSFERS') then (co.er + co.avcer) else 0 end) er_unreg_trans,
    sum(case when (co.status = 'REGISTERED' and co.type='TRANSFERS') then (co.er + avcer) else 0 end) er_reg_trans,
    sum(case when (co.status = 'REGISTERED' and co.type='TRANSFERS') then (co.TRANSFER_DEF_AMOUNT) else 0 end) reg_locked,
    sum(case when (co.status = 'UNREGISTERED' and co.type='TRANSFERS') then (co.TRANSFER_DEF_AMOUNT) else 0 end) unreg_locked,
    sum(case when (co.status = 'UNREGISTERED' and co.type='NORMAL') then co.avc else 0 end) avc_unreg,
    sum(case when (co.status = 'REGISTERED' and co.type='NORMAL') then (co.avc) else 0 end) avc_reg,
    sum(case when (co.status = 'UNREGISTERED' and co.type='NORMAL') then co.avcer else 0 end) avcer_unreg,
    sum(case when (co.status = 'REGISTERED' and co.type='NORMAL') then (co.avcer) else 0 end) avcer_reg,
    sum(case when (co.status = 'REGISTERED' and co.type='NORMAL') then (co.life_cover) else 0 end) life_cover,
    sum(case when (co.status = 'REGISTERED' and (co.TYPE='RBA_LEVY' OR co.TYPE='ADMIN_FEES' OR co.TYPE='RBA_LEVY_REVERSE' OR co.TYPE='ADMIN_FEES_REVERSE' OR co.TYPE='OTHER_FEES')) then (co.ee) else 0 end) fees
  from contributions co where member_id=(select MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS grp) group by date_paid, to_char(to_date(month||'/'||year, 'MON/yyyy'), 'Mon/yyyy'), member_id, to_date(to_char(date_paid, 'Mon/yyyy'), 'Mon/yyyy'), to_char(date_paid, 'Mon/yyyy') order by to_date(to_char(date_paid, 'Mon/yyyy'), 'Mon/yyyy') asc
/

