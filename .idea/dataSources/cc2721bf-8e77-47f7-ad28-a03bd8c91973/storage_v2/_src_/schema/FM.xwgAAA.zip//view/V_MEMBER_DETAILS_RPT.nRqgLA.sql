create view V_MEMBER_DETAILS_RPT as
  WITH m_pvt
  AS (                 -------------------------------------------------
    -------------------------------------------------
    ---   _____not_working !!!____
    -------------------------------------------------
    -------------------------------------------------
      SELECT ID,
        DECODE (FLOOR (ROWNUM / 9),
                0, MOD (ROWNUM, 9),
                MOD (ROWNUM, 9) + 1)
                                    dummy_id,
        MOD (FLOOR (ROWNUM / 9), 2) dummy_id2,
        DECODE (MOD (FLOOR (ROWNUM / 9), 2), 0, FIELD_NAME, '')
                                    FIELD_NAME_1,
        DECODE (MOD (FLOOR (ROWNUM / 9), 2), 0, FIELD_VALUE, '')
                                    FIELD_VALUE_1,
        DECODE (MOD (FLOOR (ROWNUM / 9), 2), 1, FIELD_NAME, '')
                                    FIELD_NAME_2,
        DECODE (MOD (FLOOR (ROWNUM / 9), 2), 1, FIELD_VALUE, '')
                                    FIELD_VALUE_2
      FROM V_MEMBER_DETAILS_pivot)
  SELECT a.ID,
    a.FIELD_NAME_1,
    a.FIELD_VALUE_1,
    b.FIELD_NAME_2,
    b.FIELD_VALUE_2
  FROM m_pvt a
    LEFT JOIN m_pvt b ON a.dummy_id=b.dummy_id and a.dummy_id2+1=b.dummy_id2 and a.ID=b.ID
/

