create view V_ACC_BEN_PAYMENTS as
  select
    i.ID,
    b.DATE_OF_EXIT,
    b.DATE_OF_CALCULATION,
    m.MEMBER_NO,
    mb.FIRSTNAME||' '||mb.SURNAME||' '||mb.OTHER_NAMES member_name,
    cd.NAME creditor,
    bk.NAME bank_name,
    bb.NAME branch_name,
    cd.ACCOUNT_NO,
    m.ACCOUNT_NO,
    i.CONTROL_AMNT INVOICE_AMT,
    i.PARTICULARS,
    bp.NET_PAYMENT bp_net_payment,
    b.TOT_LIAB BEN_LIABILITIES,
    replace(bp.TYPE, '_', ' ') TYPE,
    b.TOT_GLLIAB GRPLIFE_LIAB,
    b.NET_GROUPLIFE_AMOUNT,
    bp.DATE_PROCESSED date_from_admin,
    i.POSTED,
    i.DATE_PMT_PROCESSED
  from INVOICES i
    INNER JOIN BENEFIT_PAYMENTS bp on bp.ID = i.BENEFITPAYMENT_ID
    INNER JOIN BENEFITS b on b.ID=bp.BENEFIT_ID
    INNER JOIN MEMBERS m on b.ID=m.EXIT_ID
    INNER JOIN MEMBERS_BIOS mb on m.MEMBERBIO_ID = mb.ID
    INNER JOIN CREDITOR_DEBTOR cd on i.DEBTOR_ID = cd.ID
    LEFT JOIN BANK_BRANCHES bb on cd.BANKBRANCH_ID = bb.ID
    LEFT JOIN BANKS bk on cd.BANK_ID = bk.ID
  where b.DATE_OF_EXIT BETWEEN (select grp.DATE_FROM from V_GENERAL_REPORTS_PARAMS grp) and (select grp.DATE_TO from V_GENERAL_REPORTS_PARAMS grp)
        and m.SCHEME_ID=(select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) and bp.DATE_PROCESSED is not NULL
/

