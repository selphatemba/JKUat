create view V_INV_PVS_REPORT as
  with params as(
      select TOTAL_HOLDING from V_INV_PVS_TOTALHOLDING total_holding
  )
  select
    inv.SCHEME_ID,
    inv.NAME,
    (case when to_char(inv.CODE) is NULL then to_char(inv.REF_CODE) else to_char(inv.code) end)code,
    case when inv.SETTLMNT_DATE is null then inv.DEAL_DATE else inv.SETTLMNT_DATE END SETTLEMENT_DATE,
    hold.ACQUISITIONS,
    hold.SALES,
    hold.VALUATION,
    fvhold.HOLDING as face_value,
    /*(case when inv.INVESTMENT_CATEGORY='EQUITY' then coalesce(inv.VALUE_PER_SHARE, 0)*coalesce(fvhold.HOLDING, 0)
   WHEN (inv.INVESTMENT_CATEGORY='GOVERNMENT_SECURITIES' or inv.INVESTMENT_CATEGORY='CORPORATE_BONDS')
     THEN coalesce((select max(sv.VALUATION_INDEX) from SECURITY_VALUATION sv where sv.INVESTS_ID=inv.ID and sv.VALUATION_DATE=(select max(VALUATION_DATE) from SECURITY_VALUATION s where s.INVESTS_ID=inv.ID and s.VALUATION_DATE<=(select date_to from V_GENERAL_REPORTS_PARAMS))), 0)*coalesce(fvhold.HOLDING, 0)
   else hold.HOLDING end)MARKET_VALUE,*/
     hold.HOLDING,
      case when inv.INVESTMENT_CATEGORY='EQUITY' then inv.VALUE_PER_SHARE
      WHEN (inv.INVESTMENT_CATEGORY='GOVERNMENT_SECURITIES' or inv.INVESTMENT_CATEGORY='CORPORATE_BONDS')
        THEN (select max(sv.VALUATION_INDEX) from SECURITY_VALUATION sv where sv.INVESTS_ID=inv.ID and sv.VALUATION_DATE=(select max(VALUATION_DATE) from SECURITY_VALUATION s where s.INVESTS_ID=inv.ID))
      else 0 end price,
      (hold.HOLDING/(p.TOTAL_HOLDING+0.000001))*100 percentage_total_holding,
      p.TOTAL_HOLDING,
      cls.CLASS,
      inv.INTRST_FREQ,
      inv.MATURITY_DATE,
      inv.MATURED,
      inv.REDEEMED,
      inv.COUPON_RATE,
      inv.BOND_TPE,
     inv.FUNDMANAGER_ID,
     fm.NAME fund_manager,
     (case when inv.APPROVEDISSUER_ID is NOT NULL then issuers.NAME when (inv.APPROVEDISSUER_ID is NULL and ISSUER is not NULL)then ISSUER else inv.ISSUERS END) ISSUER
      from params p, INVESTMENTS inv
     INNER JOIN V_INVESTMENT_CLASSES cls on inv.INVESTMENT_CATEGORY=cls.CATEGORY
     INNER JOIN V_INV_PVS_HOLDINGPERINV hold ON inv.ID=hold.ID
     LEFT JOIN FUND_MANAGERS fm ON inv.FUNDMANAGER_ID = fm.ID
     LEFT JOIN APPROVED_ISSUERS issuers ON inv.APPROVEDISSUER_ID=issuers.ID
     LEFT JOIN V_INV_PVS_FV_HOLDINGPERINV fvhold ON inv.ID=fvhold.ID
     where inv.INVESTMENT_CATEGORY in (select CATEGORY from V_INVESTMENT_CLASSES)
     AND inv.SCHEME_ID=(select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) and (inv.DELETED!='DELETED' or inv.DELETED is null)
/

