create view V_PROP_ALL_TRANSACTIONS as
  select tx.TRANS_DATE, p.PMT_DATE DATE_PMT_PROCESSED, p.POSTED_DATE pmt_post_date, i.name investment_name,
    u.UNIT_NO, tx.PARTICULARS, tx.AMOUNT, initcap(replace(tx.INVTXN_TYPE, '_', ' '))txn_type,
    inv.BALANCE, cd.NAME creditor_debtor, initcap(inv.INVOICE_TYPE) invoice_type
  from INVESTMENT_TXNS tx
    INNER JOIN INVESTMENTS i on tx.INVESTMENT_ID = i.ID
    INNER JOIN CREDITOR_DEBTOR cd on tx.CREDITORDEBTOR_ID=cd.ID
    INNER JOIN INVOICES inv on inv.INVESTMENTTXN_ID=tx.ID
    LEFT JOIN PAYMENT_APPLICATIONS pa on inv.ID = pa.INVOICE2_ID
    LEFT JOIN payments p on p.ID=pa.PAYMENT2_ID
    LEFT JOIN units u on tx.UNIT_ID=u.ID
  where i.INVESTMENT_CATEGORY='PROPERTY' and i.SCHEME_ID=(select scheme_id from V_GENERAL_REPORTS_PARAMS grp) ORDER BY TRANS_DATE ASC
/

