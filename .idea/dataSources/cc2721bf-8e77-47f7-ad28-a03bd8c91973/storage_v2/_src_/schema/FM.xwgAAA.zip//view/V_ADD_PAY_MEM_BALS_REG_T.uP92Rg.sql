create view V_ADD_PAY_MEM_BALS_REG_T as
  with params as (
      select  (SELECT grp.MEMBER_ID_FROM FROM V_GENERAL_REPORTS_PARAMS grp) member_id from dual
  )
  SELECT
    (SELECT grp.SCHEME_ID FROM V_GENERAL_REPORTS_PARAMS grp) SCHEME_ID,
    sum(coalesce(0, 0)) transfer,
    sum(coalesce(AVC_CONTR, 0)) AVC_CONTR,
    sum(coalesce(AVC_BAL, 0))AVC_BAL,
    sum(coalesce(AVC_BALINTR, 0))AVC_BALINTR,
    sum(coalesce(AVC_INTR, 0))AVC_INTR,
    sum(coalesce(AVCER_CONTR, 0)) AVCER_CONTR,
    sum(coalesce(AVCER_BAL, 0))AVCER_BAL,
    sum(coalesce(AVCER_BALINTR, 0))AVCER_BALINTR,
    sum(coalesce(AVCER_INTR, 0))AVCER_INTR,
    sum(coalesce(EE_CONTR, 0)) EE_CONTR,
    sum(coalesce(EE_BAL, 0))EE_BAL,
    sum(coalesce(EE_BALINTR, 0)) EE_BALINTR,
    sum(coalesce(EE_INTR, 0))EE_INTR,
    sum(coalesce(ER_CONTR, 0)) ER_CONTR,
    sum(coalesce(ER_BAL, 0))ER_BAL,
    sum(coalesce(ER_BALINTR, 0))ER_BALINTR,
    sum(coalesce(ER_INTR, 0))ER_INTR,
    sum(coalesce(er_bal,0) + coalesce(ee_bal,0)) combined_bals
  FROM CLOSING_BALANCES cb, params par
  where cb.member_id = (select MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS)
        and cb.STATUS = 'REGISTERED'
        and cb.ID=(select cb.ID from CLOSING_BALANCES cb where cb.STATUS = 'REGISTERED' and cb.MEMBER_ID=(select MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS) and cb.ASAT=(select MAX(cb.ASAT) from CLOSING_BALANCES cb where cb.STATUS = 'REGISTERED' and cb.MEMBER_ID=(select MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS)))
  group by par.member_id
/

