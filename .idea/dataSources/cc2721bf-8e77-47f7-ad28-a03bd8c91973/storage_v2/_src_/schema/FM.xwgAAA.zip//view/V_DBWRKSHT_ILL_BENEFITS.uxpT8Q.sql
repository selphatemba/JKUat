create view V_DBWRKSHT_ILL_BENEFITS as
  select target_pre, target_post, (select SCHEME_ID from V_GENERAL_REPORTS_PARAMS) SCHEME_ID
  from benefits where id = (select benefit_id from benefit_payments where id = (select BENEFIT_PAYMENTS_ID from V_GENERAL_REPORTS_PARAMS) and rownum=1)
/

