create FUNCTION "GET_FULLTEXT" (

p_scheme_Id  in  acc_view.scheme_id%TYPE,

p_accName  in  acc_view.name%TYPE)

  RETURN VARCHAR2

IS

  l_text  VARCHAR2(32767) := NULL;

BEGIN

  FOR cur_rec IN (SELECT name1 FROM Acc_View WHERE LFT = p_accName and scheme_Id = p_scheme_Id)

  LOOP

    l_text := l_text || '->' || cur_rec.name1;

  END LOOP;

  RETURN LTRIM(l_text, '->');

END;

/

