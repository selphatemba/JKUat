create view V_PAYMENT_LINES_AGG as
  SELECT PAYMENT_ID,
            LISTAGG (ID, ',') WITHIN GROUP (ORDER BY id) palyment_lines_ids,
            ACCOUNT_ID,
            DRCR,
            SUM (BC_VALUE) BC_VALUE,
            SUM (SC_VALUE) SC_VALUE
       FROM payment_lines
   GROUP BY PAYMENT_ID, ACCOUNT_ID, DRCR
/

