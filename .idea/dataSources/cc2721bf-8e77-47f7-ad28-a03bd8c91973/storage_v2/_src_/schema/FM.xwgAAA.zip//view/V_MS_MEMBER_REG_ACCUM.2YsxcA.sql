create view V_MS_MEMBER_REG_ACCUM as
  with params as(
      select grp.MS_APIDONE apIdOne, grp.MS_AP_ID apIdLast from V_GENERAL_REPORTS_PARAMS grp
  )
  select cb.MEMBER_ID,
    sum(coalesce(cb.EE_BALINTR,0)) EE_BALINTR,
    sum(coalesce(cb.ER_BALINTR,0)) ER_BALINTR,
    sum(coalesce(cb.AVC_BALINTR,0)) AVC_BALINTR,
    sum(coalesce(cb.EE_CONTR,0)) EE_CONTR,
    sum(coalesce(cb.ER_CONTR,0)) ER_CONTR,
    sum(coalesce(cb.AVC_CONTR,0)) AVC_CONTR,
    sum(coalesce(cb.EE_INTR,0)) EE_INTR,
    sum(coalesce(cb.ER_INTR,0)) ER_INTR,
    sum(coalesce(cb.AVC_INTR,0)) AVC_INTR,
    sum(coalesce(cb.TRANSFER_EE,0)) TRANSFER_EE,
    sum(coalesce(cb.TRANSFER_ER,0)) TRANSFER_ER,
    sum(coalesce(cb.TRANSFER_AVC,0)) TRANSFER_AVC,
    sum(coalesce(cb.EE_PAYMENTS,0)) EE_PAYMENTS,
    sum(coalesce(cb.ER_PAYMENTS,0)) ER_PAYMENTS,
    sum(coalesce(cb.AVC_PAYMENTS,0)) AVC_PAYMENTS
  FROM CLOSING_BALANCES cb, params p where cb.AP_ID BETWEEN p.apIdOne and p.apIdLast and status='REGISTERED' and MEMBER_ID in (select st.member_id from MEMSTMT_RPT_MEMIDS st) GROUP BY cb.MEMBER_ID
/

