create view V_CH_MEMBER_DETAILS as
  with params as (
      select (select MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS grp) member_param, (select AP_ID from V_GENERAL_REPORTS_PARAMS grp) ap_param,(select SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) scheme_param from dual
  )
  SELECT mb.ID ID, mb.ID_NO ID_NO,
         (select contributions from interest_rates where scheme_id = m.scheme_id and status = 'REGISTERED' and type = 'DECLARED' and ap_id = p.ap_param and rownum = 1) interest,
         (select normal from retirement_ages re where memberclass_id = m.mclass_id and re.gender = mb.gender  and rownum = 1) retire_age_normal,
         add_months(mb.DOB, 12*(select normal from retirement_ages re where memberclass_id = m.mclass_id and re.gender = mb.gender and rownum = 1)) retire,
         (SELECT SCHEME_NAME FROM SCHEMES WHERE ID = M.SCHEME_ID  and rownum = 1) SCHEME,
    m.PAYROLL_NO,
         (to_char(current_date, 'yyyy')-to_char(mb.dob,'yyyy'))age,
         DECODE(mb.TITLE,'MR','Mr.', 'MRS', 'Mrs.', 'DR', 'Dr.', 'PROF', 'Prof.', 'REV', 'Rev.', 'ENG', 'Eng.', 'MISS', 'Ms.', '')
         ||' '||mb.SURNAME
         ||', '||mb.FIRSTNAME
         ||' '||mb.OTHER_NAMES NAME,
    M.MEMBER_NO,
    mb.GENDER,m.DESIGNATION,
    M.DATE_JOINED_SCHEME,
    M.DATE_OF_EMPL,
    M.DEPARTMENT_NO,mb.DEPOT,
    mb.SUB_REGION, mb.REGION_ADDR,
    mb.DOB,
         (select name from sponsors where rownum = 1 and id in (select sponsor_id from companies where id = m.company_id)) sponsor, m.SCHEME_ID
  FROM MEMBERS M,MEMBERS_BIOS mb, params p WHERE  m.ID = p.member_param AND m.MEMBERBIO_ID=mb.ID AND (upper(MBSHIP_STATUS)='ACTIVE' OR upper(MBSHIP_STATUS)='DEFERRED' OR upper(MBSHIP_STATUS)='DEFFERED')
/

