create view V_ACC_ACCOUNT_DETAILS as
  SELECT
    a.ID,
    a.NAME accountName,
    a.CODE accountCode,
    a.STATUS,
    a.CATEGORY,
    a.SCHEME_ID,
    a.ACCOUNT_TYPE
  FROM ACCOUNTS a WHERE a.id=(select grp.account_id from V_GENERAL_REPORTS_PARAMS grp)
/

