create view V_NET_PAYROLL_LIST as
  with params as (
      select (select MONTH from V_NET_PAYROLL_PARAMS) monthpar, (select YEAR from V_NET_PAYROLL_PARAMS) yearpar from dual
  ), addparams as(
      select to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM')-1, 'MON') prevmonth,
             to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM')-1, 'YYYY') prevyear,
             to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM'), 'Month') monthlong,
        par.*
      from params par
  ), cachetab as(
      select * from payroll pay, addparams adp
      where (pay.year = adp.yearpar and pay.month = adp.monthpar) or (pay.month = adp.prevmonth and pay.year = adp.prevyear )
  ), lastpayroll as(
      select ct.* from cachetab ct, addparams adp where month = adp.prevmonth and year = adp.prevyear
  ) , thispayroll as(
      select ct.* from cachetab ct, addparams adp where month = adp.monthpar and year = adp.yearpar
  ), list as(
      select ou.member_no, ou.account_no, ou.branch,
        case when mod(to_number(coalesce(SUBSTR(to_char(net), INSTR(to_char(net),'.') + 1), '0')), 5) = 0 then net
        when to_number(coalesce(SUBSTR(to_char(net), INSTR(to_char(net),'.') + 1), '0')) < 10 then net
        else net end net,
        (select pen.ACCOUNT_NAME from pensioners pen where pen.ID = (select p.PENSIONER_ID from payroll p where p.ACCOUNT_NO = ou.ACCOUNT_NO and rownum = 1) and rownum = 1) name,
        (select pension_no from PENSIONERS pen where pen.id = (select p.PENSIONER_ID from payroll p where p.ACCOUNT_NO = ou.ACCOUNT_NO  and rownum = 1) and rownum = 1) pension_no,
        (select SCHEME_ID from V_NET_PAYROLL_PARAMS) scheme_id
      from(
            select ACCOUNT_NO,member_no, branch, round((sum(net))*20)/20 net from (select pay.ACCOUNT_NO, (coalesce(pay.GROSS, 0) + coalesce(pay.ARREAS, 0) - coalesce(pay.DEDS, 0) - coalesce(pay.TAX, 0)) net,
                                                                                                          (select member_no from members where id = (case when pen.member_id is not null then pen.member_id else (select member_id from beneficiaries where id = pen.BENEFICIARY_ID)  end)) member_no,
                                                                                                          (case when pen.member_id is null then (select beneficiaries.FIRSTNAME||' '||beneficiaries.OTHERNAMES||' '||beneficiaries.surname from beneficiaries  where id = pen.BENEFICIARY_ID) else (select members.FIRSTNAME||' '||members.OTHER_NAMES||' '||members.SURNAME from members where id = pen.member_id) end) name,
                                                                                                          (case when pen.member_id is not null then pen.pension_no else (select pension_no from pensioners where member_id = (select member_id from beneficiaries where id = pen.beneficiary_id) and rownum = 1) end) pension_no,
                                                                                                          (select name from BANK_BRANCHES bb where id = pay.BANKBRANCH_ID) branch from thispayroll pay inner join pensioners pen on pay.PENSIONER_ID = pen.ID
                                                                                   where (pay.pension_status = 'ACTIVE' or pay.pensioner_id in ( select lp.pensioner_id from lastpayroll lp where lp.pension_status = 'ACTIVE' and pay.pension_status = 'STOPPED')) and pay.BANKBRANCH_ID in (select id from BANK_BRANCHES where BANK_BRANCHES.BANK_ID = (select BANK_ID from V_NET_PAYROLL_PARAMS)) and pen.SCHEME_ID=(select SCHEME_ID from V_NET_PAYROLL_PARAMS)) GROUP BY account_no, member_no, branch,net) ou
  )select member_no, account_no, branch, sum(net) net, name, pension_no, scheme_id from list group by member_no, scheme_id, account_no, branch, name, pension_no order by ACCOUNT_NO asc
/

