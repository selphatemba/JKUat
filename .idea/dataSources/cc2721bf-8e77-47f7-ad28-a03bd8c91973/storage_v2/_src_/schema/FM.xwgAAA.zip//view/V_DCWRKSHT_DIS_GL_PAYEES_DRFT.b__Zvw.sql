create view V_DCWRKSHT_DIS_GL_PAYEES_DRFT as
  select cd.NAME, cd.SCHEME_ID, glb.AMOUNT, glb.COMMENTS, glb.BENEFIT_ID from GROUP_LIFE_LIABILITIES glb INNER JOIN creditor_debtor cd on glb.CREDITOR_ID = cd.ID where glb.BENEFIT_ID=(select BENEFITS_ID from V_GENERAL_REPORTS_PARAMS)
/

