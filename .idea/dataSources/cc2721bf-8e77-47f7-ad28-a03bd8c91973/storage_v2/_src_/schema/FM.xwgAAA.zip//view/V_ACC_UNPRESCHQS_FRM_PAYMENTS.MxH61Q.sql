create view V_ACC_UNPRESCHQS_FRM_PAYMENTS as
  select p.id, p.POSTED_DATE, (coalesce(p.CONTROL_AMT, 0)*coalesce(p.SPOT_RATE, 1)) CREDIT, 0 debit, p.PARTICULARS, p.CHEQUE_NO, p.PMT_DATE, p.SCHEME_ID, p.PAYMENT_NO, (case when g.CLEARED is NULL then 'NO' else g.cleared END) cleared from gl g INNER JOIN GL_BATCHES gb ON g.GLBATCH_ID = gb.ID INNER JOIN payments p on gb.ID = p.GLBATCH_ID
  where g.GL_DATE BETWEEN
        (select br.CB_OPENING_BALDATE from BANK_RECONCILIATION br where br.id=(select grp.BANK_RECON_ID from V_GENERAL_REPORTS_PARAMS grp))
        and
        (select br.RECON_DATE from BANK_RECONCILIATION br where br.id=(select grp.BANK_RECON_ID from V_GENERAL_REPORTS_PARAMS grp))
        and
        g.ACCOUNT_ID=(select sb.GLACCOUNT_ID from SCHEME_BANKS sb where sb.id=(select br.CASHBOOK_ID from BANK_RECONCILIATION br where br.id=(select grp.BANK_RECON_ID from V_GENERAL_REPORTS_PARAMS grp)))
        AND (g.CLEARED IS NULL OR g.CLEARED='NO') AND p.PMT_DATE BETWEEN (select br.CB_OPENING_BALDATE from BANK_RECONCILIATION br where br.id=(select grp.BANK_RECON_ID from V_GENERAL_REPORTS_PARAMS grp)) and (select br.RECON_DATE from BANK_RECONCILIATION br where br.id=(select grp.BANK_RECON_ID from V_GENERAL_REPORTS_PARAMS grp))
        and
        (g.DATE_CLEARED is NULL or g.DATE_CLEARED>(select br.RECON_DATE from BANK_RECONCILIATION br where br.id=(select grp.BANK_RECON_ID from V_GENERAL_REPORTS_PARAMS grp))
        ) and p.PAYMENT_TYPE='DISBURSEMENT' and (p.REVERSED IS NULL OR p.REVERSED='NO') and (p.REVERSAL IS NULL OR p.REVERSAL='NO') AND p.SCHEME_ID=(select SCHEME_ID from V_GENERAL_REPORTS_PARAMS)
/

