create view V_PAYREC_HEADERS as
  with params as (
      select (SELECT MONTH FROM V_PAYREC_PARAMS) monthpar, (SELECT YEAR FROM V_PAYREC_PARAMS) yearpar from dual
  ), addparams as(
      select to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM')-1, 'MON') prevmonth,
             to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM')-1, 'YYYY') prevyear,
             to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM'), 'Month') monthlong,
        par.*
      from params par
  ), cachetab as(
      select * from payroll pay, addparams adp
      where (pay.year = adp.yearpar and pay.month = adp.monthpar) or (pay.month = adp.prevmonth and pay.year = adp.prevyear )
  ) , thispayroll as(
      select ct.* from cachetab ct, addparams adp where month = adp.monthpar and year = adp.yearpar
  ), lastpayroll as(
      select ct.* from cachetab ct, addparams adp where month = adp.prevmonth and year = adp.prevyear
  )
  select (select PAYROLL_RECON_PARAMS.SCHEME_ID from PAYROLL_RECON_PARAMS) scheme_id,
         (select adp.monthlong||', '||yearpar from addparams adp) monthlong,
         (select adp.prevmonth||' - '||monthpar || ' ' ||yearpar from addparams adp) title,
         (select sum((coalesce(gross,0)+coalesce(arreas,0))-(coalesce(deds,0)+coalesce(tax,0))+(coalesce(tax_on_arreas,0)))  from lastpayroll  where PENSION_STATUS = 'ACTIVE' or PENSION_STATUS = 'SUSPENDED') + ((select sum(coalesce(tax,0)) from lastpayroll where (pension_status = 'ACTIVE'))) lastamount,
         (select  count(*) from lastpayroll lp  where (pension_status = 'ACTIVE' or pension_status = 'SUSPENDED') and account_no not in(select d.account_no from deductions d inner join lastpayroll lp on  d.account_no = lp.account_no)) lastcount,
         ((select sum((coalesce(net,0)+coalesce(arreas,0))+(coalesce(deds,0)+coalesce(tax,0)))  from thispayroll where account_no not in(select d.account_no from deductions d inner join thispayroll tp on  d.account_no = tp.account_no))) - (select  coalesce(sum((coalesce(lp.net,0)+coalesce(lp.arreas,0))+(coalesce(lp.deds,0)+coalesce(lp.tax,0))), 0) from lastpayroll lp where lp.pension_status = 'SUSPENDED' and (lp.pensioner_id not in (select tp.pensioner_id from thispayroll tp , pensioners p where tp.pensioner_id = p.id and p.pension_status = 'STOPPED' or p.pension_status = 'DECEASED') or lp.pensioner_id  in (select distinct(tp.pensioner_id) from thispayroll tp  where (tp.pension_status = 'STOPPED' or tp.pension_status = 'DECEASED')))) currentamount,
         ((select count(*) from thispayroll where account_no not in(select d.account_no from deductions d inner join thispayroll tp on  d.account_no = tp.account_no))) - (select  count(*) from lastpayroll lp where lp.pension_status = 'SUSPENDED' and (lp.pensioner_id not in (select tp.pensioner_id from thispayroll tp , pensioners p where tp.pensioner_id = p.id and p.pension_status = 'STOPPED' or p.pension_status = 'DECEASED') or lp.pensioner_id  in (select distinct(tp.pensioner_id) from thispayroll tp  where (tp.pension_status = 'STOPPED' or tp.pension_status = 'DECEASED')))) currentcount,
         ((select sum((coalesce(gross,0)+coalesce(arreas,0) - coalesce(tax,0))) from thispayroll, pensioners pe where pe.id = pensioner_id and (pe.pension_status = 'ACTIVE'))) currentamountactiveonly,
         (select count(*) from thispayroll, pensioners pe  where pe.id = pensioner_id and  (pe.pension_status = 'ACTIVE') ) currentcountactiveonly,
    --tax component last payroll
         ((select count(*) from lastpayroll where coalesce(tax,0)>0 and  (pension_status = 'ACTIVE')  and account_no not in(select d.account_no from deductions d inner join lastpayroll lp on  d.account_no = lp.account_no))) lasttaxcount,
         ((select sum(coalesce(tax,0)+coalesce(tax_on_arreas,0)) from lastpayroll where (pension_status = 'ACTIVE'))) lasttax,
    --tax component this payroll
         ((select sum(coalesce(tax,0)+coalesce(tax_on_arreas,0)) from thispayroll where (pension_status = 'ACTIVE'))) thistax, ((select count(*) from thispayroll where coalesce(tax,0)>0 and  (pension_status = 'ACTIVE') and account_no not in(select d.account_no from deductions d inner join thispayroll tp on  d.account_no = tp.account_no))) thistaxcount,
         ((select sum(coalesce(tax_on_arreas,0)) from thispayroll where (pension_status = 'ACTIVE'))) thistax_arreas,
    --SUSPENSIONS
         ((select COALESCE(sum((coalesce(gross,0)+coalesce(arreas,0))-(coalesce(deds,0)+coalesce(tax,0)+ coalesce(tax_on_arreas,0))), 0) from lastpayroll where ( pension_status = 'SUSPENDED'))) sus_lastamount,
         (select count(*) from lastpayroll  where ( pension_status = 'SUSPENDED') and deds = 0  and account_no not in(select d.account_no from deductions d inner join lastpayroll lp on  d.account_no = lp.account_no)) sus_lastcount,
    --((select sum((coalesce(lp.arreas,0) + coalesce(lp.net,0))) from   lastpayroll lp, pensioners pe where (lp.pension_status='ACTIVE' ) and pe.id = lp.pensioner_id  and lp.pensioner_id in (select pensioner_id from thispayroll where pension_status='SUSPENDED'))) sus_currentamount,
         (select coalesce(sum((coalesce(lp.arreas,0) + coalesce(lp.net,0))), 0) from lastpayroll lp, thispayroll tp where lp.pensioner_id =  tp.pensioner_id and lp.pension_status='ACTIVE' and tp.pension_status='SUSPENDED') sus_currentamount,
    --***(select count(*) from   lastpayroll lp, pensioners pe, thispayroll tp where (lp.pension_status='ACTIVE' ) and pe.id = lp.pensioner_id and pe.id = tp.pensioner_id and lp.pensioner_id in (select pensioner_id from thispayroll where pension_status='SUSPENDED')) sus_currentcount,
         (select count(*) from lastpayroll lp, thispayroll tp where lp.pensioner_id =  tp.pensioner_id and lp.pension_status='ACTIVE' and tp.pension_status='SUSPENDED') sus_currentcount,-- and lp.pensioner_id in (select pensioner_id from thispayroll where pension_status='SUSPENDED')) sus_currentcount,
    --(select count(*) from thispayroll where pension_status='SUSPENDED') sus_currentcount,
         ((select COALESCE(sum((coalesce(gross,0)+coalesce(arreas,0))-(coalesce(deds,0)+coalesce(tax,0)+ coalesce(tax_on_arreas,0))), 0) from thispayroll tp, params par where  ( tp.pension_status = 'SUSPENDED'))) sus_currentamounttot,
         (select count(*) from thispayroll  tp, params par where ( tp.pension_status = 'SUSPENDED')) sus_currentcounttot,
    --net current
         ((select sum(coalesce(NET,0)+coalesce(ARREAS,0)) from thispayroll where (pension_status = 'ACTIVE'))) currentNet,
    --net previous
         ((select sum(coalesce(NET,0)+coalesce(ARREAS,0)) from lastpayroll where (pension_status = 'ACTIVE'))) previousNet,
    --NEW ENTRANTS
         ((select sum((coalesce(gross,0)+coalesce(arreas,0))-(coalesce(deds,0)+coalesce(tax,0)+ coalesce(tax_on_arreas,0))) from lastpayroll, pensioners pe where ( recont_type = 'NEW_ENTRANT'))) lastrecontamt,
         (select count(*) from lastpayroll  where ( recont_type = 'NEW_ENTRANT')  and account_no not in(select d.account_no from deductions d inner join lastpayroll lp on  d.account_no = lp.account_no)) lastrecontcount,
         ((select sum((coalesce(gross,0)+coalesce(arreas,0))-(coalesce(deds,0)+coalesce(tax,0))) from thispayroll where ( recont_type = 'NEW_ENTRANT'))) currentrecontamt,
         (select count(*) from thispayroll  where ( recont_type = 'NEW_ENTRANT') and account_no not in(select d.account_no from deductions d inner join thispayroll tp on  d.account_no = tp.account_no)) currentrecontcount,
    --REINSTATEMENTS
         ((select coalesce(sum((coalesce(net,0)+coalesce(arreas,0))-(coalesce(deds,0)+coalesce(tax,0)+coalesce(tax_on_arreas,0))), 0) from lastpayroll where ( recont_type = 'RE_INTRODUCTION'))) lastintroamt,
         (select count(*) from lastpayroll  where ( recont_type = 'RE_INTRODUCTION') and account_no not in(select d.account_no from deductions d inner join lastpayroll lp on  d.account_no = lp.account_no)) lastintrocount,
         ((select coalesce(sum((coalesce(gross,0)+coalesce(arreas,0))-(coalesce(deds,0)+coalesce(tax,0)+ coalesce(tax_on_arreas,0))), 0) from thispayroll where ( recont_type = 'RE_INTRODUCTION'))) currentintroamt,
         (select count(*) from thispayroll  where ( recont_type = 'RE_INTRODUCTION') and account_no not in(select d.account_no from deductions d inner join thispayroll tp on  d.account_no = tp.account_no)) currentintrocount, (select count(*) from thispayroll tp, lastpayroll lp where lp.pensioner_id = tp.pensioner_id and lp.pension_status='SUSPENDED' and (tp.pension_status = 'ACTIVE')) currentreintro,
         (select coalesce(sum((coalesce(tp.gross,0)+coalesce(tp.arreas,0))-(coalesce(tp.deds,0)+coalesce(tp.tax,0)+ coalesce(tp.tax_on_arreas,0))), 0) from thispayroll tp, lastpayroll lp where lp.pensioner_id = tp.pensioner_id and lp.pension_status='SUSPENDED'  and (tp.pension_status = 'ACTIVE')) currentreintroamount,
    --INCREMENT
    --((select sum((coalesce(gross,0)+coalesce(arreas,0))-(coalesce(deds,0)+coalesce(tax,0)+ coalesce(tax_on_arreas,0))) from lastpayroll where ( recont_type = 'INCREASE'))) lastincramt,
    --(select count(*) from lastpayroll  where ( recont_type = 'INCREASE')  and account_no not in(select d.account_no from deductions d inner join lastpayroll lp on  d.account_no = lp.account_no)) lastincrcount,
    --(select sum((coalesce(tp.arreas,0) + coalesce(tp.net,0))-(coalesce(lp.arreas,0) + coalesce(lp.net,0))) from thispayroll tp, lastpayroll lp where lp.pensioner_id = tp.pensioner_id and (lp.gross<tp.gross) and tp.account_no not in(select d.account_no from deductions d inner join thispayroll tp on  d.account_no = tp.account_no)  and tp.pensioner_id not in (select tp.pensioner_id from thispayroll t, lastpayroll l where l.pensioner_id = t.pensioner_id and l.pension_status='SUSPENDED' and (t.pension_status = 'ACTIVE'))) currentincramt,
    --(select count(*) from thispayroll tp, lastpayroll lp where lp.pensioner_id = tp.pensioner_id and (lp.gross<tp.gross) and tp.account_no not in(select d.account_no from deductions d inner join thispayroll tp on  d.account_no = tp.account_no)  and tp.pensioner_id not in (select tp.pensioner_id from thispayroll t, lastpayroll l where l.pensioner_id = t.pensioner_id and l.pension_status='SUSPENDED' and (t.pension_status = 'ACTIVE'))) currentincrcount,
    --rev increases logic
         (select count(*) from lastpayroll lp,thispayroll tp, pensioners pe  where tp.recont_type = 'INCREASES' and coalesce(tp.deds, 0)=0 and pe.id = tp.pensioner_id and (pe.pension_status='ACTIVE' OR pe.pension_status='SUSPENDED') and tp.pensioner_id = lp.pensioner_id and (coalesce(lp.gross,0)< coalesce(tp.gross,0) or coalesce(lp.arreas,0) < coalesce(tp.arreas,0))) increasesrev,
         (select coalesce(sum((coalesce(tp.gross,0)+coalesce(tp.arreas,0))-(coalesce(tp.deds,0)+coalesce(tp.tax,0)+ coalesce(tp.tax_on_arreas,0))), 0) from lastpayroll lp,thispayroll tp, pensioners pe  where  tp.recont_type = 'INCREASES' and coalesce(tp.deds, 0)=0 and pe.id = tp.pensioner_id and tp.pensioner_id = lp.pensioner_id and (coalesce(lp.gross,0)< coalesce(tp.gross,0) or coalesce(lp.arreas,0) < coalesce(tp.arreas,0))) increasesamt,
    --EXITS
         ((select sum((coalesce(gross,0)+coalesce(arreas,0))-(coalesce(deds,0)+coalesce(tax,0)+ coalesce(tax_on_arreas,0))) from lastpayroll, pensioners pe where pe.id = pensioner_id and (  pe.pension_status = 'STOPPED' or pe.pension_status = 'DECEASED'))) lastexitsamt,
         (select count(*) from lastpayroll  where ( pension_status = 'STOPPED' or pension_status = 'DECEASED')  and account_no not in(select d.account_no from deductions d inner join lastpayroll lp on  d.account_no = lp.account_no)) lastexitscount,
    --(select  sum((coalesce(lp.gross,0)+coalesce(lp.arreas,0))-(coalesce(lp.deds,0)+coalesce(lp.tax,0))+coalesce(lp.tax_on_arreas,0)) from lastpayroll lp where lp.pension_status != 'SUSPENDED' and lp.pensioner_id not in (select pensioner_id from thispayroll tp , pensioners p where tp.pensioner_id = p.id and p.pension_status = 'STOPPED' or p.pension_status = 'DECEASED')) currentexitsamt,
    --(select count(*) from lastpayroll lp where lp.pension_status != 'SUSPENDED' and lp.pensioner_id not in (select pensioner_id from thispayroll tp , pensioners p where tp.pensioner_id = p.id and p.pension_status = 'STOPPED' or p.pension_status = 'DECEASED')) currentexitscount,
    --exits that were on suspension
    --(select count(*) from lastpayroll lp where lp.pension_status = 'SUSPENDED' and lp.pensioner_id not in (select pensioner_id from thispayroll tp , pensioners p where tp.pensioner_id = p.id and p.pension_status = 'STOPPED' or p.pension_status = 'DECEASED')) susexitscount,
    --(select  sum((coalesce(lp.gross,0)+coalesce(lp.arreas,0))-(coalesce(lp.deds,0)+coalesce(lp.tax,0))+coalesce(lp.tax_on_arreas,0)) from lastpayroll lp where lp.pension_status = 'SUSPENDED' and lp.pensioner_id not in (select pensioner_id from thispayroll tp , pensioners p where tp.pensioner_id = p.id and p.pension_status = 'STOPPED' or p.pension_status = 'DECEASED')) susexitsamt,
    --DECREASES
         ((select sum((coalesce(gross,0)+coalesce(arreas,0))-(coalesce(deds,0)+coalesce(tax,0))) from lastpayroll where (recont_type = 'DECREASES'))) lastdecamt,
         (select count(*) from lastpayroll  where (recont_type = 'DECREASES') and account_no not in(select d.account_no from deductions d inner join lastpayroll lp on  d.account_no = lp.account_no)) lastdeccount,
         (select sum((coalesce(lp.gross,0)+coalesce(lp.arreas,0))-(coalesce(lp.deds,0)+coalesce(lp.tax,0))) - sum((coalesce(tp.gross,0)+coalesce(tp.arreas,0))-(coalesce(tp.deds,0)+coalesce(tp.tax,0)+ coalesce(tp.tax_on_arreas,0)))  from thispayroll tp, lastpayroll lp  where lp.pension_status!='SUSPENDED' and lp.pensioner_id = tp.pensioner_id and ( tp.recont_type = 'DECREASES')) currentdecamt,
         (select count(tp.pensioner_id) from thispayroll tp, lastpayroll lp where lp.pension_status!='SUSPENDED' and lp.pensioner_id = tp.pensioner_id and ( tp.recont_type = 'DECREASES')) currentdeccount,
    --rev decreases logic
         (select count(*) from lastpayroll lp,thispayroll tp, pensioners pe  where  tp.recont_type = 'DECREASES' and  pe.id = tp.pensioner_id and coalesce(tp.deds, 0)=0 and tp.pensioner_id = lp.pensioner_id and   tp.recont_type='INCREASES' and (coalesce(lp.gross,0)>coalesce(tp.gross,0) or coalesce(lp.arreas,0) > coalesce(tp.arreas,0))) decreasesrev,
         (select coalesce(sum((coalesce(tp.gross,0)+coalesce(tp.arreas,0))-(coalesce(tp.deds,0)+coalesce(tp.tax,0))), 0) from lastpayroll lp,thispayroll tp, pensioners pe   where tp.recont_type = 'DECREASES' AND pe.id = tp.pensioner_id and  tp.recont_type='INCREASES' and coalesce(tp.deds, 0)=0 and tp.pensioner_id = lp.pensioner_id and  (coalesce(lp.gross,0)>coalesce(tp.gross,0) or coalesce(lp.arreas,0) > coalesce(tp.arreas,0))) decreasesamt from dual
/

