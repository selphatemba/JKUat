create view V_AR_MEMBERS_STATISTICS as
  with quarter as (
      select (select QUARTER from V_AR_PARAMS) q, (select SCHEME_ID from V_AR_PARAMS) scheme_id, (select YEAR FROM V_AR_PARAMS) yr from dual
  ),quarterdef as (
      select case
             when q = 1 then '01-JAN-'||''||qt.yr
             when q = 2 then '01-APR-'||''||qt.yr
             when q = 3 then '01-JUL-'||''||qt.yr
             when q = 4 then '01-OCT-'||''||qt.yr
             else ''
             end as from_date_qt,
             case
             when q = 1 then '31-MAR-'||''||qt.yr
             when q = 2 then '30-JUN-'||''||qt.yr
             when q = 3 then '30-SEP-'||''||qt.yr
             when q = 4 then '31-DEC-'||''||qt.yr
             else ''
             end as to_date_qt
      from quarter qt
  )
  select
    q as quarter,
    yr as year,
    scheme_id,
    to_char(to_date(to_date_qt),'dd/MM/yyyy') to_date,
    to_char(to_date(from_date_qt),'dd/MM/yyyy') from_date,
    (select count(distinct(mhs.member_id)) from members_status_history mhs
      inner join members mem on mem.id = mhs.member_id
      inner join quarterdef pe on mhs.status_change_date < pe.from_date_qt
      inner join quarter qtr on mem.scheme_id=qtr.scheme_id
    where
      status_change_date = (select max(status_change_date) from members_status_history where member_id = mem.id and rownum = 1)
      and
      (mhs.status_after = 'ACTIVE') and mem.approved = 'YES') before_quater_active,
    (select count(*) from members where MBSHIP_STATUS = 'ACTIVE' and approved = 'YES' and scheme_id=qtr.scheme_id and date_joined_scheme <= to_date_qt ) after_quater_active,
    (select count(*) from members mem, benefits ben where mem.exit_id = ben.id and (MBSHIP_STATUS = 'DEATH_IN_SERVICE' or MBSHIP_STATUS = 'RETIRED_ILL_HEALTH' or MBSHIP_STATUS = 'RETIRED') and scheme_id=qtr.scheme_id and date_of_exit < from_date_qt ) before_quater_ret_death,
    (select count(*) from members where MBSHIP_STATUS = 'ACTIVE' and scheme_id=qtr.scheme_id and date_joined_scheme between from_date_qt and to_date_qt) quater_active,
    (select count(*) from members mem, benefits ben where mem.exit_id = ben.id and (MBSHIP_STATUS = 'DEFFERED'or MBSHIP_STATUS = 'DEFERRED') and scheme_id=qtr.scheme_id and ben.DATE_OF_EXIT between from_date_qt and to_date_qt) quater_deferred,
    (select count(*) from members mem, benefits ben where mem.exit_id = ben.id and (MBSHIP_STATUS = 'RETIRED_ILL_HEALTH' or MBSHIP_STATUS = 'RETIRED') and scheme_id=qtr.scheme_id and date_of_exit between from_date_qt and to_date_qt) quater_retirements,
    (select count(*) from members mem left join benefits ben on mem.exit_id = ben.id where scheme_id=qtr.scheme_id and date_of_exit between from_date_qt and to_date_qt and (ben.reasonforexit_id in (select id from REASONS_FOR_EXIT where (reason = 'Death in service' or reason = 'Death Notice')))) quater_deaths,
    (select count(*) from members mem, benefits ben where mem.exit_id = ben.id and (MBSHIP_STATUS = 'DEATH_IN_SERVICE' or MBSHIP_STATUS = 'RETIRED_ILL_HEALTH' or MBSHIP_STATUS = 'RETIRED' or MBSHIP_STATUS = 'ACTIVE') and scheme_id=qtr.scheme_id and date_joined_scheme between from_date_qt and to_date_qt  and (date_of_exit between from_date_qt and to_date_qt)) quater_all,
    (select count(*) from members where  scheme_id=qtr.scheme_id and date_joined_scheme between from_date_qt and to_date_qt) new_entrants, --entrants in the quarter
    (select count(*) from members mem, benefits ben where mem.exit_id = ben.id and MBSHIP_STATUS='WITHDRAWN'  and scheme_id=qtr.scheme_id and date_of_exit between from_date_qt and to_date_qt) withdrawals, --entrants in the quarter
    (select count(*) from members mem, benefits ben where mem.exit_id = ben.id and ben.reasonforexit_id = (select id from REASONS_FOR_EXIT where reason = 'Resignation')  and scheme_id=qtr.scheme_id and date_of_exit between from_date_qt and to_date_qt) wdr_res,
    (select count(*) from members mem, benefits ben where mem.exit_id = ben.id and ben.reasonforexit_id in (select id from REASONS_FOR_EXIT where (reason = 'Termination' or reason = 'Dismissal'))  and scheme_id=qtr.scheme_id and date_of_exit between from_date_qt and to_date_qt) wdr_ter_dis,
    (select count(*) from members mem, benefits ben where mem.exit_id = ben.id and ben.reasonforexit_id in (select id from REASONS_FOR_EXIT where (reason = 'Immigrants' or reason = 'Transfer of Contributions'))  and scheme_id=qtr.scheme_id and date_of_exit between from_date_qt and to_date_qt) wdr_mig_tra,
    (select count(*) from members mem, benefits ben where mem.exit_id = ben.id and MBSHIP_STATUS='RETIRED_ILL_HEALTH'  and scheme_id=qtr.scheme_id and date_of_exit between from_date_qt and to_date_qt) ret_med,
    (select count(*) from members mem, benefits ben where mem.exit_id = ben.id and MBSHIP_STATUS='RETIRED' and ben.reasonforexit_id in (select id from REASONS_FOR_EXIT where reason = 'Normal Retirement')  and scheme_id=qtr.scheme_id and date_of_exit between from_date_qt and to_date_qt) retired,
    --deferred movement
    (select count(distinct(mhs.member_id)) from members_status_history mhs
      inner join members mem on mem.id = mhs.member_id
      inner join quarterdef pe on mhs.status_change_date < pe.from_date_qt
      inner join quarter qtr on mem.scheme_id=qtr.scheme_id
    where
      status_change_date = (select max(status_change_date) from members_status_history where member_id = mem.id and rownum = 1)
      and
      mhs.status_after = 'DEFFERED' and mem.approved = 'YES') before_qtr_def, --entrants in the quarter
    (select count(*) from members mem, benefits ben where mem.exit_id = ben.id and MBSHIP_STATUS='DEFFERED'  and scheme_id=qtr.scheme_id and date_of_exit between from_date_qt and to_date_qt) in_qtr_def,
    (select count(*) from members mem,benefits ben where mem.exit_id = ben.id and MBSHIP_STATUS!='DEFFERED' and scheme_id=qtr.scheme_id and date_of_exit between from_date_qt and to_date_qt and mem.id in (select mhs.member_id from members_status_history mhs
      inner join members mem on mem.id = mhs.member_id
      inner join quarterdef pe on mhs.status_change_date < pe.from_date_qt
      inner join quarter qtr on mem.scheme_id=qtr.scheme_id
    where
      status_change_date = (select max(status_change_date) from members_status_history where member_id = mem.id and rownum = 1)
      and
      mhs.status_after = 'DEFFERED' and mem.approved = 'YES')) def_paid_out,
    (select count(*) from members mem, benefits ben where mem.exit_id = ben.id and MBSHIP_STATUS='DEFFERED'  and scheme_id=qtr.scheme_id and date_of_exit < to_date_qt) def_all
  from quarterdef pe,  quarter qtr
/

