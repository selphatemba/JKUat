create view V_AR_SCHEME_DETAILS as
  select sc.ID scheme_id, scheme_name, fax, email, building, fixed_phone ,postal_address||', '||TOWN||', '||COUNTRY postal_address, road, country, website  from schemes sc where id = (select par.SCHEME_ID from V_AR_PARAMS par)
/

