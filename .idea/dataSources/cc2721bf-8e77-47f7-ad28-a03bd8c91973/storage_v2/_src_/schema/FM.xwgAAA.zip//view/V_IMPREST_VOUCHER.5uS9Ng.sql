create view V_IMPREST_VOUCHER as
  select
    si.id,
    si.DATE_APPLIED imprest_date,
    det.NAME name,
    si.REFNO refno,
    coalesce(si.AMT_APPLIED, 0) amount_applied,
    coalesce(si.AMT_USED, 0) amount_used,
    coalesce(si.AMT_APPLIED, 0)-coalesce(si.AMT_USED, 0) refund,
    spell_number(nvl(trunc(si.AMT_APPLIED, 0), 0)) WORDS,
    nvl(ROUND(si.AMT_APPLIED, 2), 0) original_amt,
    nvl((nvl(ROUND(si.AMT_APPLIED, 2), 0) - nvl(trunc(si.AMT_APPLIED, 0), 0))*100, 0) cents,
    spell_number((nvl(ROUND(si.AMT_APPLIED, 2), 0) - nvl(trunc(si.AMT_APPLIED, 0), 0))*100)CENTS_WORDS,
    (spell_number(nvl(trunc(si.AMT_APPLIED, 0), 0)) ||' shillings, '|| coalesce(spell_number((nvl(ROUND(si.AMT_APPLIED, 2), 0) - nvl(trunc(si.AMT_APPLIED, 0), 0))*100), 'zero'))||' cents  Only.' FULL_WORDS,
    si.PURPOSE,
    si.SCHEME_ID scheme_id,
    det.ID_NO applier_idno,
    si.DATE_CERTIFIED,
    si.DATE_APPROVED,
    si.DATE_POSTED,
    si.DATE_RETIRED,
    si.DATE_TOBE_RETIRE,
    si.RETURN_DATE,
    prep.FIRSTNAME||' '||prep.OTHERNAMES preparer,
    '-' certifier,
    app.FIRSTNAME||' '||app.OTHERNAMES approver
  from STAFF_IMPREST si
    INNER JOIN STAFF det ON si.STAFF_ID = det.ID
    LEFT JOIN USERS prep ON si.PREPAREDBY_ID = prep.ID
    LEFT JOIN USERS cert ON si.CERTIFIEDBY_ID = cert.ID
    LEFT JOIN USERS app ON si.APPROVEDBY_ID = app.ID
  where si.ID=(SELECT grp.IMPREST_ID FROM GENERAL_REPORTS_PARAMS grp)
/

