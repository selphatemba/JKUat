create view V_NET_P_TOTAL_AMOUNT as
  with params as (
      select (select MONTH FROM NET_PAYROLL_PB_PARAMS) month_p, (select YEAR FROM NET_PAYROLL_PB_PARAMS) year_p , (select SCHEME_ID FROM NET_PAYROLL_PB_PARAMS) scheme from dual
  ), tabo as(
      select
        (to_char(trunc(to_date('01-'||par.month_p||'-'||par.year_p),'MM')-1, 'MON') ) prevmonth,
        to_char(trunc(to_date('01-'||par.month_p||'-'||par.year_p),'MM')-1, 'YYYY') prevyear
      from params par
  )
  select bank_name, (select SCHEME_ID FROM NET_PAYROLL_PB_PARAMS) AS SCHEME_ID, (select BANK_ID FROM NET_PAYROLL_PB_PARAMS) AS BANK_ID,
                    case when mod(to_number(coalesce(SUBSTR(to_char(amount), INSTR(to_char(amount),'.') + 1), '0')), 5) = 0 then amount
                    when to_number(coalesce(SUBSTR(to_char(amount), INSTR(to_char(amount),'.') + 1), '0')) < 10 then amount
                    else amount end amount from (
    select  bank_name,  round((sum(amount))*20)/20 amount from(
      select
        pa.pensioner_id,
        (select name from banks where id = (select bank_id from bank_branches where  pa.bankbranch_id=BANK_BRANCHES.ID AND BANK_BRANCHES.BANK_ID = (select NET_PAYROLL_PB_PARAMS.BANK_ID FROM NET_PAYROLL_PB_PARAMS) )) bank_name, coalesce(pa.net ,0)+coalesce(pa.arreas ,0) amount from payroll pa inner join params pr on 'true' = 'true' inner join BANK_BRANCHES br on br.id = pa.bankbranch_id where month = pr.month_p and year = pr.year_p
                                                                                                                                                                                                                                                                                                                                                                                                           --- eliminating suspended in previous month and stopped in current month
                                                                                                                                                                                                                                                                                                                                                                                                           and (pa.pension_status <> 'SUSPENDED' and pa.PENSIONER_ID not in (select PENSIONER_ID from payroll pi, tabo where month = prevmonth and year = prevyear and pension_status = 'SUSPENDED' and pi.PENSIONER_ID in (select PENSIONER_ID from payroll pii where pii.month = pa.month and pii.year = pa.year and pension_status = 'STOPPED' )))
    ) group by bank_name
  ) where bank_name is not null order by bank_name
/

