create view V_MS_MEMBER_DETAILS as
  with params as (
      select (select MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS grp) member_param, (select MEMBER_ID_TO from V_GENERAL_REPORTS_PARAMS grp) member_param2, (select MS_AP_ID from V_GENERAL_REPORTS_PARAMS grp) ap_param, (select SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) scheme_param from dual
  )
  SELECT
    m.ID ID,
    case when m.id_no is null then mb.id_no else m.id_no end ID_NO,
    (select DATE_TO from V_GENERAL_REPORTS_PARAMS grp) to_date,--(select to_date from accounting_periods where id = p.ap_param and rownum=1) to_date,
    (select contributions from interest_rates where scheme_id = m.scheme_id and status = 'REGISTERED' and type = 'DECLARED' and ap_id = p.ap_param and rownum=1) interest,
    (select normal from retirement_ages re where memberclass_id = m.mclass_id and re.gender = case when M.GENDER is null then mb.gender else m.gender end and rownum=1) retire_age_normal,
    add_months(case when mb.dob is null then m.dob else mb.dob end, 12*(select normal from retirement_ages re where memberclass_id = m.mclass_id and re.gender = case when M.GENDER is null then mb.gender else m.gender end and rownum=1)) retire,
    (SELECT SCHEME_NAME FROM SCHEMES WHERE ID = M.SCHEME_ID and rownum=1) SCHEME,
    payroll_no,
    FLOOR ( (SYSDATE - NVL (mb.dob, m.DOB)) / 365)age,
    DECODE(case when m.TITLE is null then mb.title else m.title end,'MR','Mr.', 'MRS', 'Mrs.', 'DR', 'Dr.', 'PROF', 'Prof.', 'REV', 'Rev.', 'ENG', 'Eng.', 'MISS', 'Ms.', '')
    ||' '||case when M.SURNAME is null then mb.surname else m.surname end
    ||', '||case when M.FIRSTNAME is null then mb.firstname else m.firstname end
    ||' '||case when M.OTHER_NAMES is null then mb.other_names else m.other_names end NAME,
    M.MEMBER_NO,
    decode(case when mb.GENDER is null then m.gender else mb.gender end, 'MALE', 'Male', 'FEMALE', 'Female') gender,
    DESIGNATION,
    M.DATE_JOINED_SCHEME,
    M.DATE_OF_EMPL,
    initcap(M.DEPARTMENT_NO),
    m.DEPOT,
    case when mb.SUB_REGION is null then m.sub_region else mb.sub_region end SUB_REGION,
    case when mb.REGION_ADDR is null then m.region_addr else mb.region_addr end region_addr,
    (select sponsors.name from sponsors where sponsors.id = (select companies.sponsor_id from companies where id = m.company_id)) sponsor,
    case when mb.dob is null then m.dob else mb.dob end DOB,
    SCHEME_ID
  FROM MEMBERS M
    left join params p on 'join' = 'join'
    left join members_bios mb on mb.id = m.memberbio_id
  WHERE m.ID in (select st.member_id from MEMSTMT_RPT_MEMIDS st)
/

