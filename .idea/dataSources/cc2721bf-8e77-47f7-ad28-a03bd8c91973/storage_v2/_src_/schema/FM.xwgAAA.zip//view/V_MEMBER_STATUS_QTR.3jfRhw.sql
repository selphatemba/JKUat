create view V_MEMBER_STATUS_QTR as
  SELECT m.id member_id,
  m.approved,
  m.date_joined_scheme,
       TO_CHAR (m.date_joined_scheme, 'YYYY"Q"Q') qrtr_joined_scheme,
       TRUNC (m.date_joined_scheme, 'Q') qrtr_joined_scheme_start_date,
       TRUNC (ADD_MONTHS (m.date_joined_scheme, 3), 'Q') - 1
         qrtr_joined_scheme_end_date,
  m.scheme_id,
  b.date_of_exit,
       TO_CHAR (b.date_of_exit, 'YYYY"Q"Q') qrtr_date_of_exit,
       TRUNC (b.date_of_exit, 'Q') qrtr_date_of_exit_start_date,
       TRUNC (ADD_MONTHS (b.date_of_exit, 3), 'Q') - 1
         qrtr_date_of_exit_end_date,
  r.reason,
  r.mbship_status,
  msh.WITHDRAWN_STATUS_CHNG,
  msh.DELETED_STATUS_CHNG,
  msh.DEFFERED_STATUS_CHNG,
  msh.NOTIFIED_STATUS_CHNG,
  msh.ACTIVE_STATUS_CHNG,
  msh.TRANSFERED_STATUS_CHNG,
  msh.RETIRED_ILL_HEALTH_STATUS_CHNG,
  msh.DEATH_IN_SERVICE_STATUS_CHNG,
  msh.RETIRED_STATUS_CHNG
FROM members m
  LEFT JOIN BENEFITS b ON m.EXIT_ID = b.ID
  LEFT JOIN REASONS_FOR_EXIT r ON b.REASONFOREXIT_ID = r.ID
  LEFT JOIN V_MEMBERS_STATUS_HISTORY msh ON m.ID=msh.MEMBER_ID
/

