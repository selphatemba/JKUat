create view V_CONTRIBUTIONS_SUMMARY as
  select scheme_id, sponsor, mbship_status, id, member_no, name, det, sum(jan_ee)jan_ee, sum(jan_er)jan_er, sum(feb_ee)feb_ee, sum(feb_er)feb_er,sum(mar_ee) mar_ee,sum(mar_er)mar_er,sum(apr_ee) apr_ee, sum(apr_er)apr_er, sum(may_ee)may_ee, sum(may_er)may_er, sum(jun_ee)jun_ee, sum(jun_er)jun_er, sum(jul_ee)jul_ee, sum(jul_er)jul_er, sum(aug_ee)aug_ee, sum(aug_er)aug_er, sum(sep_ee)sep_ee,sum(sep_er) sep_er,sum(oct_ee) oct_ee, sum(oct_er)oct_er,sum(nov_ee) nov_ee, sum(nov_er)nov_er, sum(dec_ee)dec_ee, sum(dec_er)dec_er from(
    select
      me.SCHEME_ID,
      (select name from sponsors where id = (select sponsor_id from companies where id = (select company_id from members where id = me.id ))) sponsor,
      me.MBSHIP_STATUS,
      co.month,
      me.id,
      me.member_no,
      me.OTHER_NAMES||' '||me.FIRSTNAME||' '||me.SURNAME name,
      case when to_char(date_paid, 'MON') = month and type = 'NORMAL' then '1_same' else '2_different' end det,
      case when to_char(date_paid, 'MON') = 'JAN'  and month = 'JAN' and type = 'NORMAL' then (ee) when to_char(date_paid, 'MON') = 'JAN' and month <> 'JAN' and  (type = 'NORMAL' or type = 'ARREARS') then (ee) else  (0) end jan_ee,
      case when to_char(date_paid, 'MON') = 'JAN'  and month = 'JAN' and type = 'NORMAL' then (er) when to_char(date_paid, 'MON') = 'JAN' and month <> 'JAN' and  (type = 'NORMAL' or type = 'ARREARS') then (er) else  (0) end jan_er,
      case when to_char(date_paid, 'MON') = 'FEB'  and month = 'FEB' and type = 'NORMAL' then (ee) when to_char(date_paid, 'MON') = 'FEB' and month <> 'FEB' and  (type = 'NORMAL' or type = 'ARREARS') then (ee) else  (0) end FEB_ee,
      case when to_char(date_paid, 'MON') = 'FEB'  and month = 'FEB' and type = 'NORMAL' then (er) when to_char(date_paid, 'MON') = 'FEB' and month <> 'FEB' and  (type = 'NORMAL' or type = 'ARREARS') then (er) else  (0) end FEB_er,
      case when to_char(date_paid, 'MON') = 'MAR'  and month = 'MAR' and type = 'NORMAL' then (ee) when to_char(date_paid, 'MON') = 'MAR' and month <> 'MAR' and  (type = 'NORMAL' or type = 'ARREARS') then (ee) else  (0) end MAR_ee,
      case when to_char(date_paid, 'MON') = 'MAR'  and month = 'MAR' and type = 'NORMAL' then (er) when to_char(date_paid, 'MON') = 'MAR' and month <> 'MAR' and  (type = 'NORMAL' or type = 'ARREARS') then (er) else  (0) end MAR_er,
      case when to_char(date_paid, 'MON') = 'APR'  and month = 'APR' and type = 'NORMAL' then (ee) when to_char(date_paid, 'MON') = 'APR' and month <> 'APR' and  (type = 'NORMAL' or type = 'ARREARS') then (ee) else  (0) end APR_ee,
      case when to_char(date_paid, 'MON') = 'APR'  and month = 'APR' and type = 'NORMAL' then (er) when to_char(date_paid, 'MON') = 'APR' and month <> 'APR' and  (type = 'NORMAL' or type = 'ARREARS') then (er) else  (0) end APR_er,
      case when to_char(date_paid, 'MON') = 'MAY'  and month = 'MAY' and type = 'NORMAL' then (ee) when to_char(date_paid, 'MON') = 'MAY' and month <> 'MAY' and  (type = 'NORMAL' or type = 'ARREARS') then (ee) else  (0) end MAY_ee,
      case when to_char(date_paid, 'MON') = 'MAY'  and month = 'MAY' and type = 'NORMAL' then (er) when to_char(date_paid, 'MON') = 'MAY' and month <> 'MAY' and  (type = 'NORMAL' or type = 'ARREARS') then (er) else  (0) end MAY_er,
      case when to_char(date_paid, 'MON') = 'JUN'  and month = 'JUN' and type = 'NORMAL' then (ee) when to_char(date_paid, 'MON') = 'JUN' and month <> 'JUN' and  (type = 'NORMAL' or type = 'ARREARS') then (ee) else  (0) end JUN_ee,
      case when to_char(date_paid, 'MON') = 'JUN'  and month = 'JUN' and type = 'NORMAL' then (er) when to_char(date_paid, 'MON') = 'JUN' and month <> 'JUN' and  (type = 'NORMAL' or type = 'ARREARS') then (er) else  (0) end JUN_er,
      case when to_char(date_paid, 'MON') = 'JUL'  and month = 'JUL' and type = 'NORMAL' then (ee) when to_char(date_paid, 'MON') = 'JUL' and month <> 'JUL' and  (type = 'NORMAL' or type = 'ARREARS') then (ee) else  (0) end JUL_ee,
      case when to_char(date_paid, 'MON') = 'JUL'  and month = 'JUL' and type = 'NORMAL' then (er) when to_char(date_paid, 'MON') = 'JUL' and month <> 'JUL' and  (type = 'NORMAL' or type = 'ARREARS') then (er) else  (0) end JUL_er,
      case when to_char(date_paid, 'MON') = 'AUG'  and month = 'AUG' and type = 'NORMAL' then (ee) when to_char(date_paid, 'MON') = 'AUG' and month <> 'AUG' and  (type = 'NORMAL' or type = 'ARREARS') then (ee) else  (0) end AUG_ee,
      case when to_char(date_paid, 'MON') = 'AUG'  and month = 'AUG' and type = 'NORMAL' then (er) when to_char(date_paid, 'MON') = 'AUG' and month <> 'AUG' and  (type = 'NORMAL' or type = 'ARREARS') then (er) else  (0) end AUG_er,
      case when to_char(date_paid, 'MON') = 'SEP'  and month = 'SEP' and type = 'NORMAL' then (ee) when to_char(date_paid, 'MON') = 'SEP' and month <> 'SEP' and  (type = 'NORMAL' or type = 'ARREARS') then (ee) else  (0) end SEP_ee,
      case when to_char(date_paid, 'MON') = 'SEP'  and month = 'SEP' and type = 'NORMAL' then (er) when to_char(date_paid, 'MON') = 'SEP' and month <> 'SEP' and  (type = 'NORMAL' or type = 'ARREARS') then (er) else  (0) end SEP_er,
      case when to_char(date_paid, 'MON') = 'OCT'  and month = 'OCT' and type = 'NORMAL' then (ee) when to_char(date_paid, 'MON') = 'OCT' and month <> 'OCT' and  (type = 'NORMAL' or type = 'ARREARS') then (ee) else  (0) end OCT_ee,
      case when to_char(date_paid, 'MON') = 'OCT'  and month = 'OCT' and type = 'NORMAL' then (er) when to_char(date_paid, 'MON') = 'OCT' and month <> 'OCT' and  (type = 'NORMAL' or type = 'ARREARS') then (er) else  (0) end OCT_er,
      case when to_char(date_paid, 'MON') = 'NOV'  and month = 'NOV' and type = 'NORMAL' then (ee) when to_char(date_paid, 'MON') = 'NOV' and month <> 'JUN' and  (type = 'NORMAL' or type = 'ARREARS') then (ee) else  (0) end NOV_ee,
      case when to_char(date_paid, 'MON') = 'NOV'  and month = 'NOV' and type = 'NORMAL' then (er) when to_char(date_paid, 'MON') = 'NOV' and month <> 'JUN' and  (type = 'NORMAL' or type = 'ARREARS') then (er) else  (0) end NOV_er,
      case when to_char(date_paid, 'MON') = 'DEC'  and month = 'DEC' and type = 'NORMAL' then (ee) when to_char(date_paid, 'MON') = 'DEC' and month <> 'DEC' and  (type = 'NORMAL' or type = 'ARREARS') then (ee) else  (0) end DEC_ee,
      case when to_char(date_paid, 'MON') = 'DEC'  and month = 'DEC' and type = 'NORMAL' then (er) when to_char(date_paid, 'MON') = 'DEC' and month <> 'DEC' and  (type = 'NORMAL' or type = 'ARREARS') then (er) else  (0) end DEC_er
    from members me
      inner join contributions co on me.id = co.member_id
    where year = (select grp.YEAR from GENERAL_REPORTS_PARAMS grp) and  (type = 'NORMAL' or type = 'ARREARS') and scheme_id = (select grp.SCHEME_ID from GENERAL_REPORTS_PARAMS grp)
  ) group by scheme_id, sponsor, det, mbship_status, id, member_no, name order by member_no
/

