create view V_INV_PVM_FACEVSALE_PER_INV as
  select
    txns.INVESTMENT_ID,
    sum(
        case when inv.INVESTMENT_CATEGORY = 'EQUITY' and (txns.TRANSACTION_TYPE = 'EQUITY_SALE') then coalesce(txns.SHARES_SOLD, 0)
        when (inv.INVESTMENT_CATEGORY = 'CORPORATE_BONDS' or inv.INVESTMENT_CATEGORY='GOVERNMENT_SECURITIES') AND txns.BONDTRANS_TYPE='SALE' then coalesce(txns.FACE_VALUE, 0)
        when (inv.INVESTMENT_CATEGORY = 'FIXED_TERM_DEPOSIT' AND txns.TRANSACTION_TYPE='FXD_TRM_DEP_TRANS') then coalesce(0, 0)
        when (inv.INVESTMENT_CATEGORY = 'CASH_CALL_DEPOSITS' AND (txns.TRANSACTION_TYPE='CSH_CLL_DEP_SALE')) then coalesce(txns.AMOUNT, 0)
        when inv.INVESTMENT_CATEGORY = 'PROPERTY' and txns.INVTXN_TYPE='PROPERTY_SALE' and txns.TRANSACTION_TYPE='PROPERTY_TXN' then coalesce(txns.AMOUNT, 0)
        ELSE 0
        END
    )SALES
  from INVESTMENTS inv
    INNER JOIN INVESTMENT_TXNS txns ON inv.ID = txns.INVESTMENT_ID
  where inv.SCHEME_ID=(select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp)
and txns.TRANS_DATE>=(select grp.DATE_FROM from V_GENERAL_REPORTS_PARAMS grp)
and txns.TRANS_DATE<=(select grp.DATE_TO from V_GENERAL_REPORTS_PARAMS grp)
and (txns.DELETED!='DELETED' or txns.DELETED is null) and (inv.DELETED!='DELETED' or inv.DELETED is null)
  GROUP BY txns.INVESTMENT_ID
/

