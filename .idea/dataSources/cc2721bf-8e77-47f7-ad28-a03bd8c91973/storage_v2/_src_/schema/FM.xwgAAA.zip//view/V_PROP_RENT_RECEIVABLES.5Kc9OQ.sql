create view V_PROP_RENT_RECEIVABLES as
  select
    i.ID,
    i.AMOUNT_BOOKED amount_booked,
    i.BALANCE balance,
    i.DATE_BOOKED,
    i.MONTH,
    i.YEAR,
    i.PREPARED_DATE,
    i.INVOICE_NO,
    i.PARKING_FEE,
    i.PARKING_FEE_TAX,
    i.RENT_PAYABLE,
    i.RENT_PAYABLE_TAX,
    i.SERVICE_CHARGE,
    i.SERVICE_CHARGE_TAX,
    i.TOTAL_TAX,
    i.SRC_AMOUNT,
    i.SPOT_RATE,
    i.TAX_DETAILS,
    ag.FREQUENCY,
    i.POSTED,
    ag.CONTRACT_NO,
    u.UNIT_NO,
    ten.NAME,
    ag.ESCALATION_RATE,
    ag.TIME_PERIOD ||' '|| ag.TIME_FORMAT escalation_period,
    i.DATE_BOOKED,
    ag.NEXT_INVOICE_DATE
  from RENT_INVOICES i
    INNER JOIN TEN_AGRMNTS ag on i.CONTRACT_ID = ag.ID
    INNER JOIN TENANTS ten on ag.TENANT_ID = ten.ID
    INNER JOIN UNITS u on ag.UNIT_ID = u.ID
    INNER JOIN CURRENCIES curr on ag.CURRENCY_ID = curr.ID
  WHERE i.DATE_BOOKED BETWEEN (select grp.DATE_FROM from V_GENERAL_REPORTS_PARAMS grp) and (select grp.DATE_TO from V_GENERAL_REPORTS_PARAMS grp) and ag.SCHEME_ID=(select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) and ag.PROPERTY_ID=(select grp.INVEST_ID_FROM from V_GENERAL_REPORTS_PARAMS grp)
/

