create view V_PENSION_TAX_CERT as
  with params as (
      select (SELECT PENSIONER_ID FROM V_GENERAL_REPORTS_PARAMS) pensioner_id, (SELECT DATE_FROM FROM V_GENERAL_REPORTS_PARAMS) from_date, (SELECT DATE_TO FROM V_GENERAL_REPORTS_PARAMS) to_date from dual
  ),
      txh as
    (
        select * from pension_tax_header p ,params pr where p.effective_date between pr.from_date and pr.to_date
    ),
      mons as (select to_date(p.from_date) as dt1, to_date(p.to_date) as dt2 from pension_tax_header t,params p,dual
    )
  select
    (select SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) scheme_id,
    (select s.SCHEMEPIN from SCHEMES s where s.ID=(select SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) AND ROWNUM=1) scheme_pin,
    (case
     when pe.beneficiary_id is null then (select m.postal_address from members m where m.id = pe.member_id)
     when pe.member_id is null then (select address from beneficiaries where id = pe.beneficiary_id)
     else '--'
     end
    ) address,
    (case
     when pe.beneficiary_id is null then (select m.TOWN from members m where m.id = pe.member_id)
     when pe.member_id is null then (select TOWN from beneficiaries where id = pe.beneficiary_id)
     else '--'
     end
    ) town,
    coalesce(pe.monthly_pension,0)+coalesce(pe.monthly_pension2,0) gross_monthly,
    pe.account_no pensioner_account,
    (
      case when pe.member_id is null then (select member_no from members where id = (select member_id from beneficiaries where id=pe.beneficiary_id))
      when pe.beneficiary_id is null then (select member_no from members where id = pe.member_id)
      else 0
      end
    ) staff_no,
    (
      case when pe.member_id is null then (select pin from members where id = (select member_id from beneficiaries where id=pe.beneficiary_id))
      when pe.beneficiary_id is null then (select pin from members where id = pe.member_id)
      else ''
      end
    ) pin,
    (case
     when pe.beneficiary_id is null then (select DECODE(m.TITLE,'MR','Mr.', 'MRS', 'Mrs.', 'DR', 'Dr.', 'PROF', 'Prof.', 'REV', 'Rev.', 'ENG', 'Eng.', 'MISS', 'Ms.', '')||' '||M.FIRSTNAME||' '||M.OTHER_NAMES||' '||M.SURNAME from members m where m.id = pe.member_id)
     when pe.member_id is null then (select firstname||' '||othernames from beneficiaries where id = pe.beneficiary_id)
     else '--'
     end
    )  pensioner_name,
    (select
       trunc( months_between(dt2,dt1)+1 )
     from mons where rownum=1
    )mths,
    ((select extract(month from p.effective_date) from pension_tax_header p ,params pr where p.effective_date between pr.from_date and pr.to_date and rownum=1))H1,
    ((select extract(month from to_date(pr.from_date)) from pension_tax_header p ,params pr where p.effective_date between pr.from_date and pr.to_date and rownum=1))H,
    ((select extract(month from to_date(pr.to_date)) from pension_tax_header p ,params pr where p.effective_date between pr.from_date and pr.to_date and rownum=1))H2,
    (select count(pi.gross) from payroll pi, params pr where (to_date('01'||'-'||pi.month||'-'||pi.year) between pr.from_date and pr.to_date) and pi.pensioner_id = pe.id   and type='NORMAL' )count,
    --((select coalesce (tax_free_amount,0)  from pension_tax_header p ,params pr where p.effective_date between pr.from_date and pr.to_date and rownum=1))taxfree,
    (select coalesce (tax_free_amount,0) from pension_tax_header p,params pa where p.effective_date=(select max(p.effective_date)  from pension_tax_header p where p.effective_date<pa.from_date) )taxfree,
    (select coalesce (tax_free_amount,0) from pension_tax_header p,params pa where p.effective_date=(select max(p2.effective_date)  from pension_tax_header p2 where p2.effective_date<pa.from_date) )prevTaxfree,
    (select sum(coalesce(pi.gross, 0)) from payroll pi, params pr where (to_date('01'||'-'||pi.month||'-'||pi.year) between pr.from_date and pr.to_date) and pi.pensioner_id = pe.id   and type='NORMAL' )gross,
    (select sum(coalesce(pi.ARREAS, 0)) from payroll pi, params pr where (to_date('01'||'-'||pi.month||'-'||pi.year) between pr.from_date and pr.to_date) and pi.pensioner_id = pe.id   and type='NORMAL' )arrears,
    (select sum(coalesce(pi.DEDS, 0)) from payroll pi, params pr where (to_date('01'||'-'||pi.month||'-'||pi.year) between pr.from_date and pr.to_date) and pi.pensioner_id = pe.id   and type='NORMAL' )deds,
    (select sum(coalesce(pi.tax, 0)) from payroll pi, params pr where (to_date('01'||'-'||pi.month||'-'||pi.year) between pr.from_date and pr.to_date) and pi.pensioner_id = pe.id   and type='NORMAL' )tax,
    (select sum(coalesce(pi.tax_on_arreas, 0)) from payroll pi, params pr where (to_date('01'||'-'||pi.month||'-'||pi.year) between pr.from_date and pr.to_date) and pi.pensioner_id = pe.id and type='NORMAL' ) tax_on_arrears,
    (select sum(coalesce(pi.net, 0)) from payroll pi, params pr where (to_date('01'||'-'||pi.month||'-'||pi.year) between pr.from_date and pr.to_date) and pi.pensioner_id = pe.id   and type='NORMAL')net,
    (select sum(case when pi.gross>(select coalesce(tax_free_amount,0) from pension_tax_header p ,params pr where p.effective_date between pr.from_date and pr.to_date and rownum=1) then pi.gross-(select coalesce(tax_free_amount,0) from pension_tax_header p ,params pr where p.effective_date between pr.from_date and pr.to_date and rownum=1) else pi.gross end) taxable from payroll pi, params pr where (to_date('01'||'-'||pi.month||'-'||pi.year) between pr.from_date and pr.to_date) and pi.pensioner_id = pe.id   and type='NORMAL') taxable
  from pensioners pe, params pa where pe.ID = pa.pensioner_id
/

