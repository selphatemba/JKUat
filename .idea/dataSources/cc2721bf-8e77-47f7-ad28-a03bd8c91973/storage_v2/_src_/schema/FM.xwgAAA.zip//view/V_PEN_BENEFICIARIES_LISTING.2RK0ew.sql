create view V_PEN_BENEFICIARIES_LISTING as
  select rownum id,
       (select pension_no from pensioners pi where pi.beneficiary_id = be.id and rownum = 1) pensioner_no,
       (select firstname||' '||othernames||' '||surname from members where id = be.member_id) member_name,
       (select member_no from members where id = be.member_id) member_no,
       firstname||' '||othernames||' '||surname name,dob,
       coalesce(LUMPSUM_ENTITLEMENT, 0) allocation ,
       decode(relationship, 'DAUGHTER', 'Daughter', 'SON', 'Son', 'WIFE', 'Wife', relationship) relationship,
       decode(be.status, 'ELIGIBLE', 'Eligible','INELIGIBLE', 'Ineligible','MARRIED','Married', be.status) status
  ,(select coalesce(MONTHLY_PENSION,0)+coalesce(MONTHLY_PENSION2,0)
    from pensioners pi where pi.beneficiary_id = be.id and rownum = 1) monthly_pension,
  be.care_of,be.town,
       (case when be.postal_address IS null then 'N/A' else be.postal_address end )address,be.cell_phone,
       (select pi.SCHEME_ID from pensioners pi WHERE pi.BENEFICIARY_ID = be.ID and rownum = 1) scheme_id,
       (select pi.PENSION_START_DATE from pensioners pi WHERE pi.BENEFICIARY_ID = be.ID and rownum = 1) pension_start_date,
       (select pi.PENSION_FREQ from pensioners pi WHERE pi.BENEFICIARY_ID = be.ID and rownum = 1) pension_freq,
       (select pi.ALIVE from pensioners pi WHERE pi.BENEFICIARY_ID = be.ID and rownum = 1) alive,
       (select pi.PENSIONER_TYPE from pensioners pi WHERE pi.BENEFICIARY_ID = be.ID and rownum = 1) type,
       (select pi.PENSION_STATUS from pensioners pi WHERE pi.BENEFICIARY_ID = be.ID and rownum = 1) pension_status,
  pi.ACCOUNT_NAME, pi.ACCOUNT_NO, bb.CODE branchcode, bk.CODE bankcode, bb.NAME branchname, bk.NAME bankname
from beneficiaries be INNER join PENSIONERS pi on be.ID = pi.BENEFICIARY_ID
  LEFT JOIN FM.BANK_BRANCHES bb on pi.BRANCH_ID = bb.ID
  LEFT JOIN FM.BANKS bk on bb.BANK_ID = bk.ID
where be.id in (select p.beneficiary_id from pensioners p where p.approved='YES') and pi.SCHEME_ID=(select SCHEME_ID from V_GENERAL_REPORTS_PARAMS)
/

