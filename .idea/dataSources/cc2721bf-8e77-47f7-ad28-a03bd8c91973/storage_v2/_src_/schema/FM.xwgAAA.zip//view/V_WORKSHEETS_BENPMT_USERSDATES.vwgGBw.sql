create view V_WORKSHEETS_BENPMT_USERSDATES as
  select
                                                             (select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp)scheme_id,
    bp.DATE_PREPARED, bp.DATE_CERTIFIED, bp.DATE_AUTHORIZED, bp.DATE_PROCESSED datePmtProcessed,
                                                             prep.FIRSTNAME||' '||prep.OTHERNAMES preparer,
                                                             cert.FIRSTNAME||' '||cert.OTHERNAMES certifier,
                                                             app.FIRSTNAME||' '||app.OTHERNAMES approver,
                                                             proc.FIRSTNAME||' '||proc.OTHERNAMES pmt_processor
  from BENEFIT_PAYMENTS bp
    LEFT JOIN USERS prep ON bp.PREPAREDBY_ID = prep.ID
    LEFT JOIN USERS cert ON bp.CERTIFIEDBY_ID = cert.ID
    LEFT JOIN USERS app ON bp.AUTHORIZEDBY_ID = app.ID
    LEFT JOIN USERS proc ON bp.PROCESSEDBY_ID = proc.ID
  where bp.ID=(select grp.BENEFITPAYMENTID from V_GENERAL_REPORTS_PARAMS grp)
/

