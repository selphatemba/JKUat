create view V_DBWRKSHT_RET_BENEFITS as
  select (select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) scheme_id, b.target_pre, b.target_post,
         (select firstname||' '||othernames||', '||firstname auser from users where id = b.authorizedby_id ) author,
         (select firstname||' '||othernames||', '||firstname auser from users where id = b.certifiedby_id ) certifier,
         (select firstname||' '||othernames||', '||firstname auser from users where id = b.preparedby_id ) processor,
    date_approved, date_certified, date_authorized,DATE_PREPARED,
    monthly_pens, monthly_pens2, net_arrears,
         coalesce(TOT_LIAB , 0) liabilities
  from benefits b where id = (select grp.BENEFITS_ID from V_GENERAL_REPORTS_PARAMS grp)
/

