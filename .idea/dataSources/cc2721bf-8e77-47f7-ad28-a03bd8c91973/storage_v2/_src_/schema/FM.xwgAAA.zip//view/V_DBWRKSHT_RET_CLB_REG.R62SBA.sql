create view V_DBWRKSHT_RET_CLB_REG as
  select
    (select grp.MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS grp) SCHEME_ID,
    --------employer------
    coalesce(AVCER_BAL,0) AVCER_BAL,
    coalesce(AVCER_INTR,0) AVCER_INTR,
    coalesce(AVCER_CONTR,0) AVCER_CONTR,
    coalesce(AVCER_WITHDR_INTR,0) AVCER_WITHDR_INTR,
    coalesce(AVCER_BALINTR,0) AVCER_BALINTR,
    coalesce(AVCER_WITHDR,0) AVCER_WITHDR,
    ---------employee------
    coalesce(AVC_CONTR,0) AVC_CONTR,
    coalesce(AVC_INTR,0) AVC_INTR,
    coalesce(AVC_BAL,0) AVC_BAL,
    coalesce(AVC_BALINTR,0) AVC_BALINTR,
    coalesce(AVC_WITHDR_INTR,0) AVC_WITHDR_INTR,
    coalesce(AVC_WITHDR,0) AVC_WITHDR,
    -----------employer-------------
    coalesce(ER_BAL,0) ER_BAL,
    coalesce(ER_INTR,0) ER_INTR,
    coalesce(ER_CONTR,0) ER_CONTR,
    coalesce(ER_BALINTR,0) ER_BALINTR,
    coalesce(ER_WITHDR_INTR,0) ER_WITHDR_INTR,
    coalesce(ER_WITHDR,0)  ER_WITHDR,
    ------------employee------------
    coalesce(EE_BAL,0) EE_BAL,
    coalesce(EE_INTR,0) EE_INTR,
    coalesce(EE_CONTR,0) EE_CONTR,
    coalesce(EE_BALINTR,0) EE_BALINTR,
    coalesce(EE_WITHDR_INTR,0) EE_WITHDR_INTR,
    coalesce(EE_WITHDR,0) EE_WITHDR
  from closing_balances cl where cl.member_id = (select grp.MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS grp) and ap_id = (select grp.AP_ID from V_GENERAL_REPORTS_PARAMS grp) and status = 'REGISTERED'
/

