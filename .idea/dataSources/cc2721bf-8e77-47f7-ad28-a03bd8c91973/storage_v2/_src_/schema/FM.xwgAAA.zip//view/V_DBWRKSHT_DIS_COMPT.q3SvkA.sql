create view V_DBWRKSHT_DIS_COMPT as
  SELECT
    prep.FIRSTNAME||' '||prep.OTHERNAMES preparer,
    cert.FIRSTNAME||' '||cert.OTHERNAMES certifier,
    auth.FIRSTNAME||' '||auth.OTHERNAMES authorizer,
    (select count(*) from V_DBWRKSHT_DIS_SPSE_DETS where id is not NULL) count_spouse,
    (select count(*) from V_DBWRKSHT_DIS_CHILD_DETS where id is not NULL) count_child,
    (select SCHEME_ID from V_GENERAL_REPORTS_PARAMS) SCHEME_ID
  FROM V_DBWRKSHT_DIS_BENEFITS ben
    LEFT JOIN USERS prep ON ben.PREPAREDBY_ID=prep.ID
    LEFT JOIN USERS cert ON ben.CERTIFIEDBY_ID=cert.ID
    LEFT JOIN USERS auth ON ben.AUTHORIZEDBY_ID=auth.ID
/

