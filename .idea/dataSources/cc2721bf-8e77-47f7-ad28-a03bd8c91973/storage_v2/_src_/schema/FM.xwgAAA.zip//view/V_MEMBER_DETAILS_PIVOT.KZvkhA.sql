create view V_MEMBER_DETAILS_PIVOT as
  SELECT id, field_name, field_value
  FROM (SELECT id,
          full_names,
          id_no,
          TO_CHAR (member_no) member_no,
          TO_CHAR (dob, 'dd/mm/yyyy') dob,
          TO_CHAR (date_of_empl, 'dd/mm/yyyy') date_of_empl,
          TO_CHAR (date_joined_scheme, 'dd/mm/yyyy')
            date_joined_scheme,
          TO_CHAR (normal_ret_date, 'dd/mm/yyyy') normal_ret_date,
          TO_CHAR (normal_ret_ages) normal_ret_ages,
          NVL (sponsor_name, '-') sponsor_name,
          NVL (region_addr, '-') region_addr,
          NVL (sub_region, '-') sub_region,
          NVL (depot, '-') depot,
          NVL (designation, '-') designation,
          TO_CHAR (current_age) current_age,
          NVL (policy_no, '-') policy_no,
          ' ' dummy
        FROM v_member_details                         --where id = 282580
  ) UNPIVOT (field_value
          FOR field_name
          IN  (full_names AS 'Name of\A0 Member',
            member_no AS 'Member Number',
            id_no AS 'ID/Passport Number',
            dob AS 'Date of Birth',
            date_of_empl AS 'Date of Employment',
            date_joined_scheme AS 'Date Joined Scheme',
            normal_ret_date AS 'Normal Retirement Date',
            normal_ret_ages AS 'Normal Retirement Age',
            sponsor_name AS 'Sponsor',
            region_addr AS 'Region',
            sub_region AS 'Sub Region',
            depot AS 'Depot',
            designation AS 'Designation',
            current_age AS 'Current Age',
            policy_no AS 'Policy Number',
            dummy AS ' ',
            dummy AS ' '))
/

