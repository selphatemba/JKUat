create view V_ACC_BUDGET_VARIANCE as
  select NULL, bi.NAME, bi.CODE, bi.TYPE, NULL, NULL, sum(coalesce(ba.AMOUNT, 0)) budgeted, sum(coalesce(ba.TRANSFER_IN, 0)) transferIn, sum(coalesce(ba.SUPLEMENT, 0)) supplement, sum(coalesce(ba.AMOUNT_USED, 0)) used, sum(coalesce(ba.TRANSFER_OUT, 0)) transferOut, sum(coalesce(ba.BALANCE, 0)) balance, ba.SCHEME_ID, NULL, NULL, NULL ,
                                                      sum((coalesce(AMOUNT, 0)+COALESCE(TRANSFER_IN, 0)+coalesce(ba.SUPLEMENT, 0))-(COALESCE(AMOUNT_USED, 0)+coalesce(TRANSFER_OUT, 0))) variance
  from BUDGET_ALLOCATIONS ba
    INNER JOIN BUDGET_ITEMS bi on ba.ITEM_ID = bi.ID
    INNER JOIN ACCOUNTING_PERIODS ap ON ba.AP_ID = ap.ID
  where ba.FISCALYEAR_ID!=ba.AP_ID and ba.SCHEME_ID=(select grp.scheme_id from V_GENERAL_REPORTS_PARAMS grp) AND ba.AP_ID in (select ID from ACCOUNTING_PERIODS ap where ap.FROM_DATE>=(select DATE_FROM from V_GENERAL_REPORTS_PARAMS grp) and ap.TO_DATE<=(select DATE_TO from V_GENERAL_REPORTS_PARAMS grp))
  GROUP BY bi.NAME, bi.CODE, bi.TYPE, ba.SCHEME_ID
/

