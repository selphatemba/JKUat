create view V_ACC_TAX_SCH_LUMPSUM as
  select
    ln.TXN_DATE,
    m.SCHEME_ID,
    ln.PARTICULARS,
    ln.TAXABLE taxable_amt,
    ln.TAX tax,
    (p.NET_PAYMENT) net_paid,
    decode(tps.CATEGORY, 'LUMPSUM', 'Lumpsum') category,
    tps.AMOUNT_DUE total_schedule_amt,
    tps.DATE_FROM,
    tps.DATE_TO,
    tps.DATE_GENERATED,
    mb.FIRSTNAME||' '||mb.SURNAME||' '||mb.OTHER_NAMES payer,
    case when mb.PIN is NULL then '-' else mb.PIN END pin,
    case when tps.POSTED=0 then 'Yes' else 'No' END posted,
    m.MEMBER_NO,
    ln.INVOICENO,
    ln.id,
    ln.AMT_BOOKED_GROSS,
    ln.NET_PAYMENT,
    ln.BENEFIT_PAYMENT_ID
  from TAX_PMT_LINES ln INNER JOIN TAX_PMT_SCHEDULE tps ON ln.SCHEDULE_ID = tps.ID
    LEFT JOIN BENEFIT_PAYMENTS p ON ln.BENEFIT_PAYMENT_ID=p.ID
    LEFT JOIN BENEFITS b ON p.BENEFIT_ID=b.ID
    LEFT JOIN MEMBERS m on m.EXIT_ID = b.ID
    LEFT JOIN MEMBERS_BIOS mb ON m.MEMBERBIO_ID = mb.ID
  where tps.ID=(select grp.tax_schedule_id from V_GENERAL_REPORTS_PARAMS grp) ORDER by ln.TXN_DATE ASC
/

