create view V_BUDGET_ITEMS as
  SELECT bi.ID,
    bi.CODE,
    bi.DESCRIPTION,
    bi.NAME,
    bi.TYPE,
    bh.NAME HDR_NAME,
    bi.SCHEME_ID
  FROM budget_items bi LEFT JOIN BUDGETHEADER bh ON bi.HDR_ID = bh.ID
/

