create view V_PROV_TOTALS as
  SELECT (select sum(contr.AVC_REG+contr.AVC_UNREG+contr.EE_REG+contr.EE_UNREG+contr.ER_REG+contr.ER_UNREG) from V_PROV_CONTRIB_FORMATED contr)contr_total,
           (SELECT SUM(intr.OPENING_BAL_AVC+intr.OPENING_BAL_EE+intr.OPENING_BAL_AVC+intr.NORMAL_EE+intr.NORMAL_ER+intr.COMBINED_AVC_INTR) from V_PROV_SUMMARY intr) interest,
           (select sum(opn.AVCALL+opn.EE_BAL+opn.ER_BAL) from V_PROV_OPENBAL_REGUNREG opn) openingbal_total,
           (select SCHEME_ID from V_GENERAL_REPORTS_PARAMS) scheme_id
    FROM dual
/

