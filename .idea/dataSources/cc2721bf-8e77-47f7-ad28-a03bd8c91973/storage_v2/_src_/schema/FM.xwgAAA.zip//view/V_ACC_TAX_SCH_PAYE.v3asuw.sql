create view V_ACC_TAX_SCH_PAYE as
  select
    pb.DATE_PREPARED,
    pen.SCHEME_ID,
    ln.PARTICULARS,
    p.GROSS gross,
    ln.TAX tax,
    (p.NET) net_paid,
    tps.CATEGORY category,
    tps.AMOUNT_DUE total_schedule_amt,
    tps.DATE_FROM,
    tps.DATE_TO,
    tps.DATE_GENERATED,
    pen.BENEFICIARY_ID,
    pen.MEMBER_ID,
    case when bio.FIRSTNAME is not NULL then (bio.FIRSTNAME||' '||bio.SURNAME||' '||bio.OTHER_NAMES) else (ben.FIRSTNAME||' '||ben.SURNAME||' '||ben.OTHERNAMES) END payer,
    case when bio.PIN is not NULL then bio.PIN else ben.TAX_PIN END pin,
    case when tps.POSTED=0 then 'Yes' else 'No' END posted,
    mb.MEMBER_NO,
    ln.INVOICENO, ln.id
  from TAX_PMT_LINES ln INNER JOIN TAX_PMT_SCHEDULE tps ON ln.SCHEDULE_ID = tps.ID
    INNER JOIN PAYROLL p ON ln.PENSION_PAYROLL_ID=p.ID
    INNER JOIN PAYROLL_BATCHES pb on p.BATCH_ID = pb.ID
    INNER JOIN PENSIONERS pen on p.PENSIONER_ID= pen.ID
    left JOIN MEMBERS mb on pen.MEMBER_ID = mb.ID
    left JOIN MEMBERS_BIOS bio on mb.MEMBERBIO_ID = bio.ID
    left JOIN beneficiaries ben on ben.ID= pen.BENEFICIARY_ID
  where tps.ID=(select grp.tax_schedule_id from V_GENERAL_REPORTS_PARAMS grp)
/

