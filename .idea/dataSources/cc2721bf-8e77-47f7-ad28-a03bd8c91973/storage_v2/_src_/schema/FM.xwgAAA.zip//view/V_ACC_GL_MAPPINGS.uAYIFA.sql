create view V_ACC_GL_MAPPINGS as
  SELECT
    sp.SCHEME_ID,
    sp.PROCESS_MAP,
    sp.SUBPROCESS_MAP,
    sp.NAME SUBPROCESS_NAME,
    case when alloc.FUNDMANAGER_ID is NULL then '-' ELSE fm.NAME END  fund_manager,
    drAcc.CODE dr_acc_code,
    drAcc.NAME dr_acc_name,
    crAcc.CODE cr_acc_code,
    crAcc.NAME cr_acc_name,
    case when alloc.REASONFOREXIT_ID is NULL then '-' ELSE rfe.REASON END exit_reason,
    case when alloc.PROPERTYMANAGER_ID is NULL then '-' ELSE pm.NAME END property_manager
  from SUB_PROCESSES sp
    INNER JOIN ALLOCATIONS alloc ON sp.ID = alloc.SUBPROCESS_ID
    INNER JOIN ACCOUNTS drAcc ON alloc.DEBITACCOUNT_ID = drAcc.ID
    INNER JOIN ACCOUNTS crAcc ON alloc.CREDITACCOUNT_ID = crAcc.ID
    LEFT JOIN FUND_MANAGERS fm ON alloc.FUNDMANAGER_ID = fm.ID
    LEFT JOIN REASONS_FOR_EXIT rfe ON alloc.REASONFOREXIT_ID = rfe.ID
    LEFT JOIN PROPERTY_MANAGERS pm ON alloc.PROPERTYMANAGER_ID = pm.ID
  WHERE sp.SCHEME_ID=(select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) ORDER BY sp.PROCESS_MAP ASC
/

