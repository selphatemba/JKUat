create view V_GL_AGG as
  SELECT gl.GL_DATE,
    gl.CHEQUE_NO,
    SUM (gl.CREDIT) CREDIT,
    SUM (gl.DEBIT) DEBIT,
    LISTAGG (DECODE (NVL (gl.DEBIT, 0), 0, ACCOUNT_ID, ''), ',')
    WITHIN GROUP (ORDER BY id)
                    CREDIT_ACCOUNTS,
    LISTAGG (DECODE (NVL (gl.CREDIT, 0), 0, ACCOUNT_ID, ''), ',')
    WITHIN GROUP (ORDER BY id)
                    DEBIT_ACCOUNTS,
    gl.ACCOUNTINGPERIOD_ID,
    gl.GLBATCH_ID,
    gl.SCHEME_ID
  FROM gl
  GROUP BY gl.GL_DATE,
    gl.CHEQUE_NO,
    gl.ACCOUNTINGPERIOD_ID,
    gl.GLBATCH_ID,
    gl.SCHEME_ID
/

