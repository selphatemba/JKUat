create view V_ACC_WITHHOLDINGTAX_P9_FIN as
  select draft.MONTH_POSTED,
    case when draft.MONTH_POSTED='JAN' then 1
    when draft.MONTH_POSTED='FEB' then 2
    when draft.MONTH_POSTED='MAR' then 3
    when draft.MONTH_POSTED='APR' then 4
    when draft.MONTH_POSTED='MAY' then 5
    when draft.MONTH_POSTED='JUN' then 6
    when draft.MONTH_POSTED='JUL' then 7
    when draft.MONTH_POSTED='AUG' then 8
    when draft.MONTH_POSTED='SEP' then 9
    when draft.MONTH_POSTED='OCT' then 10
    when draft.MONTH_POSTED='NOV' then 11
    ELSE 12 end sort,
    draft.YEAR_POSTED,
    sum(draft.CHARGABLE_PAY) basicSalary,
    0 as benefitsNonCash,
    0 as valueOfQuarters,
    sum(draft.CHARGABLE_PAY) totalGross,
    0 as dcE1,
    0 as dcE2,
    0 as dcE3,
    0 as ownerOccupiedInterest,
    0 as retContrOwnerIntr,
    sum(draft.CHARGABLE_PAY) chargeablePay,
    sum(draft.WITHHOLDING_TAX) taxCharged,
    0 as personalRElief,
    sum(draft.WITHHOLDING_TAX) payeTax from V_ACC_WITHHOLDINGTAX_P9_DRAFT draft GROUP BY draft.MONTH_POSTED, draft.YEAR_POSTED
/

