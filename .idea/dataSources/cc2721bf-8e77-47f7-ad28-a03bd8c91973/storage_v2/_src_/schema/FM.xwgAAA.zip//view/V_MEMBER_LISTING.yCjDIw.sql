create view V_MEMBER_LISTING as
  select
    m.ID,
    m.SCHEME_ID,
    m.MEMBER_NO,
    initcap(replace(m.MBSHIP_STATUS, '_', ' ')),
    mb.FIRSTNAME||' '||mb.OTHER_NAMES||' '||mb.SURNAME FULL_NAME,
    mb.ID_NO,
    mb.GENDER,
    mb.DOB dob,
    m.DATE_OF_EMPL,
    m.DATE_JOINED_SCHEME,
    case when mb.CELL_PHONE is null then '-' ELSE mb.CELL_PHONE end as PHONE,
    case when mb.PIN is null then m.PIN when mb.PIN is NULL and m.PIN is null then '-' else mb.PIN end pin,
    sp.NAME sponsor,
    to_char(mb.DOB, 'dd-mm-yyyy') dobStr,
    to_char(m.DATE_OF_EMPL, 'dd-mm-yyyy') dateOfEmplStr,
    to_char(m.DATE_JOINED_SCHEME, 'dd-mm-yyyy') dateJoinedStr
  from MEMBERS m
    INNER JOIN MEMBERS_BIOS mb ON m.MEMBERBIO_ID = mb.ID
    INNER JOIN MEMBER_CLASSES mc ON m.MCLASS_ID = mc.ID
    INNER JOIN SPONSORS sp ON mc.SPONSOR_ID = sp.ID
  where m.SCHEME_ID=(select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp)
/

