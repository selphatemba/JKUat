create view V_MEMBER_STATEMENT_FOOTNOTE as
  SELECT ap.id ap_id,
    ap.FROM_DATE,
    ap.NAME,
    ap.PERIOD_STATUS,
    ap.PERIOD_TYPE,
    ap.SEQ,
    ap.TO_DATE,
    ap.FINANCIALYEAR_ID,
    ap.PARENT_ID,
    ap.SCHEME_ID,
    ap.SPONSOR_ID,
    ap.TARGET_AMOUNT,
         TO_CHAR (TO_DATE, 'yyyy') year_,
         ir.TYPE int_rate_type,
    ir.REGISTERED_CONTR,
    ir.UNREGISTERED_CONTR,
         TO_CHAR (sf.details) sf_details,
         LAG (TO_CHAR (TO_DATE, 'yyyy'), 1, 0)
         OVER (PARTITION BY ap.SCHEME_ID ORDER BY ap.id)
           prv_year,
         LAG (ir.TYPE, 1, 0) OVER (PARTITION BY ap.SCHEME_ID ORDER BY ap.id)
           prv_int_rate_type,
         LAG (ir.REGISTERED_CONTR, 1, 0)
         OVER (PARTITION BY ap.SCHEME_ID ORDER BY ap.id)
           prv_REGISTERED_CONTR,
         LAG (ir.UNREGISTERED_CONTR, 1, 0)
         OVER (PARTITION BY ap.SCHEME_ID ORDER BY ap.id)
           prv_UNREGISTERED_CONTR,
    sf.details,
         sf.id s_footnote_id
  FROM accounting_periods ap
    LEFT JOIN STATEMENT_FOOTNOTE sf on ap.ID = sf.AP_ID
    LEFT JOIN V_INTEREST_RATES ir on ap.ID = ir.AP_ID
/

