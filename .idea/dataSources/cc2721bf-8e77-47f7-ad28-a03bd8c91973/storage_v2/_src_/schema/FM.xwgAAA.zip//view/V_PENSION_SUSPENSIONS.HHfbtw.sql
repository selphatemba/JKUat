create view V_PENSION_SUSPENSIONS as
  select DISTINCT
    p.PENSION_NO,
    p.PENSIONER_TYPE,
    CASE WHEN p.BENEFICIARY_ID is not NULL and p.MEMBER_ID is NULL then ben.ACCOUNT_NAME
    WHEN p.MEMBER_ID is not NULL and p.BENEFICIARY_ID is NULL then m.BANK_ACCOUNT
    ELSE '-' end accountName,
    ps.SUSP_DATE,
    ps.REASON_STRING,
    p.SCHEME_ID,
    CASE WHEN p.BENEFICIARY_ID is not NULL and p.MEMBER_ID is NULL then ben.FIRSTNAME||' '||ben.SURNAME||' '||ben.OTHERNAMES
    WHEN p.MEMBER_ID is not NULL and p.BENEFICIARY_ID is NULL then  mb.FIRSTNAME||' '||mb.SURNAME||' '||mb.OTHER_NAMES
    ELSE '-' end name,
    CASE WHEN p.MEMBER_ID is not null then m.MEMBER_NO
    WHEN p.BENEFICIARY_ID is not NULL then (select mbs.MEMBER_NO from members mbs where mbs.id=(select bn.MEMBER_ID from BENEFICIARIES bn where bn.ID=p.BENEFICIARY_ID))
    else 0 end memberNo
  from PENSION_SUSPENSION ps
    INNER JOIN PENSIONERS p on ps.PENSIONER_ID=p.ID
    LEFT JOIN members m on m.ID = p.MEMBER_ID
    LEFT JOIN MEMBERS_BIOS mb on m.MEMBERBIO_ID = mb.ID
    LEFT JOIN BENEFICIARIES ben on ben.ID = p.BENEFICIARY_ID
  where ps.CURR='YES' and p.PENSION_STATUS='SUSPENDED' and p.SCHEME_ID=(select SCHEME_ID from V_GENERAL_REPORTS_PARAMS)
/

