create view V_INV_EQUITY_TXNS as
  select
    tx.ID,
    lc.NAME,
    lc.CODE,
    case when tx.PARTICULARS LIKE '%Opening Balance for %' then 'Opening Balance' else replace(r.TXNTYPE, '_', ' ') end txn_type,
    r.CONTRACTNOTE,
    r.DEALDATE,
    r.FUNDMANAGER,
    r.POSTED,
    r.SHARESBOUGHT,
    r.SHARESSOLD,
    r.SHARESONSPLIT,
    r.SHARESREFUNDED,
    r.BONUSSHARES,
    tx.PNL_ON_SALE,
    r.PRICEPERSHARE,
    r.AMOUNT amount_plus_gl,
    r.RUNNINGBALAMT,
    r.RUNNINGBALSHARES,
    tx.PARTICULARS
  from equity_txns_rpt r
    INNER JOIN INVESTMENT_TXNS tx on r.TXN_ID=tx.id
    INNER JOIN investments i on tx.INVESTMENT_ID=i.ID
    INNER JOIN LISTED_COMPANIES lc on i.LISTEDCOMPANY_ID = lc.ID ORDER BY r.ID ASC
/

