create view V_INVOICES as
  SELECT DISTINCT inv.ID invoice_id,
    inv.INVOICE_NO,
    inv.BALANCE,
    inv.CLEARED,
    inv.CONTROL_AMNT,
    inv.REG_AMOUNT,
    inv.UNREG_AMOUNT,
    inv.WITH_TAX,
    inv.TRANS_DATE,
    inv.INVOICE_TYPE,
    inv.PARTICULARS,
    inv.POSTED,
    inv.REF_INVOICE_NO,
    inv.SPOT_RATE,
    inv.PERIOD_ID,
    inv.SCHEME_ID,
    inv.PROCESS_MAPPING,
    inv.PRL_BATCH_ID,
                  ap.FROM_DATE AP_FROM_DATE,
                  ap.TO_DATE AP_TO_DATE,
                  ap.PERIOD_TYPE AP_PERIOD_TYPE,
                  ap.PERIOD_STATUS AP_PERIOD_STATUS,
                  ap.PRV_AP_ID AP_PRV_AP_ID,
    inv.CURRENCY_ID,
                  c.name currency_name,
                  c.code currency_code,
    inv.DEBTOR_ID,
    cd.CREDITOR_DEBTOR_ID,
                  cd.BUILDING CREDITOR_DEBTOR_BUILDING,
                  cd.CELL_PHONE CREDITOR_DEBTOR_CELL_PHONE,
                  cd.COUNTRY CREDITOR_DEBTOR_COUNTRY,
                  cd.EMAIL CREDITOR_DEBTOR_EMAIL,
                  cd.POSTAL_ADDRESS CREDITOR_DEBTOR_POSTAL_ADDRESS,
                  cd.NAME CREDITOR_DEBTOR_NAME,
                  cd.CREDITORDEBTORTYPE CREDITOR_DEBTOR_TYPE,
                  CASE WHEN inv.ID in (select id from V_ACC_AGE_ANN_THIRTY) then 'A. Below 30 Days'
                  WHEN inv.ID in (select id from V_ACC_AGE_ANN_THIRTY) OR inv.ID in (select id from V_ACC_AGE_ANN_SIXTY) THEN 'B. Between 30 and 60 Days'
                  WHEN inv.ID in (select id from V_ACC_AGE_ANN_SIXTY) OR inv.ID in (select id from V_ACC_AGE_ANN_NINETY) THEN 'C. Between 60 and 90 Days'
                  WHEN inv.ID in (select id from V_ACC_AGE_ANN_ABOVENINETY) then 'D. Above 90 Days' else 'E. Non-Grouped' end age_group,
                  cd.REGION_ADDR CREDITOR_DEBTOR_REGION_ADDR,
                  cd.SUB_REGION CREDITOR_DEBTOR_SUB_REGION,
                  cd.PARTY_ID CREDITOR_DEBTOR_PARTY_ID,
    inv.GLBATCH_ID,
                  gb.BATCH_DATE GL_BAT_BATCH_DATE,
                  gb.POSTED GL_BAT_POSTED,
                  gb.BATCH_DATE GL_BAT_DATE_PREPARED,
                  coalesce((select sum(coalesce(AMOUNT_APPLIED,0)) from PAYMENT_APPLICATIONS pl WHERE INVOICE2_ID=inv.ID),0) total_amt_applied
  FROM INVOICES inv
    LEFT JOIN V_ACCOUNTING_PERIODS ap ON inv.PERIOD_ID = ap.ID
    LEFT JOIN CURRENCIES c on inv.CURRENCY_ID = c.ID
    LEFT JOIN V_CREDITOR_DEBTOR cd ON inv.DEBTOR_ID = cd.CREDITOR_DEBTOR_ID
    LEFT JOIN GL_BATCHES gb ON inv.GLBATCH_ID = gb.ID
    LEFT JOIN PAYMENT_APPLICATIONS pl ON inv.ID = pl.INVOICE2_ID
  WHERE inv.SCHEME_ID=(select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) AND inv.TRANS_DATE BETWEEN (select grp.DATE_FROM from V_GENERAL_REPORTS_PARAMS grp) AND (select grp.DATE_TO from V_GENERAL_REPORTS_PARAMS grp) AND (inv.CONTROL_AMNT-coalesce((select sum(coalesce(AMOUNT_APPLIED,0)) from PAYMENT_APPLICATIONS pl WHERE INVOICE2_ID=inv.ID),0))>0
/

