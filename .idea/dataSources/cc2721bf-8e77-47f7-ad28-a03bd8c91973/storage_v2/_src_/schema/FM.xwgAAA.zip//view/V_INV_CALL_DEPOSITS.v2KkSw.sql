create view V_INV_CALL_DEPOSITS as
  select
    i.ID,
    i.INVESTMENT_CATEGORY,
    replace(initcap(i.INVESTMENT_CATEGORY),'_', ' ') category,
    replace(initcap(i.INVESTMENT_TYPE),'_', ' ') type,
    i.ACCRUEDINTEREST,
    i.ACCUM_INTEREST_BKD,
    i.DESCR,
    i.FACE_VALUE,
    i.INV_REDEEMED,
    i.REDEEMED,
    i.LAST_INTRCALCDATE,
    i.LASTINTRDATEBOOK,
    i.LOCALITY,
    i.INTRST_FREQ,
    i.INTEREST_TYPE,
    i.INTEREST_RATE,
    i.MARKET_VALUE,
    i.DAYSINAYEAR,
    i.SCHEME_ID,
    iss.NAME issuer,
    curr.NAME currency,
    fm.NAME fund_manager,
    i.DEAL_DATE
  from INVESTMENTS i
    INNER JOIN APPROVED_ISSUERS iss on i.APPROVEDISSUER_ID = iss.ID
    INNER JOIN FUND_MANAGERS fm on i.FUNDMANAGER_ID = fm.ID
    INNER JOIN currencies curr on i.CURRENCY_ID = curr.ID
  where i.INVESTMENT_CATEGORY='CASH_CALL_DEPOSITS' and i.SCHEME_ID=(select GRP.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp)
        and (i.DATE_REDEEMED IS NULL OR i.DATE_REDEEMED>=(select grp.DATE_FROM from V_GENERAL_REPORTS_PARAMS grp))
        and i.FUNDMANAGER_ID=(select grp.FUND_MANAGER_ID from FM.V_GENERAL_REPORTS_PARAMS grp)
/

