create view V_PENSION_TAX_FILE as
  select "SCHEME_ID","PIN","BANK_NAME","MEMBER_NAME","MEMBER_NO","ACCOUNT_NUMBER","ACCOUNT_NAME","GROSS","TAXABLE","TAX","NET","DATE_AUTHORIZED","DATE_CHECKED","DATE_PREPARED","AUTHOR","CHECKER","PREPARER" from(
  select
    (select grp.scheme_id from V_GENERAL_REPORTS_PARAMS grp) scheme_id,
    (select (select pin from members where id =
                                           (case
                                            when pe.member_id is null then (select member_id from beneficiaries where id = pe.beneficiary_id and rownum = 1)
                                            when pe.beneficiary_id is null then pe.member_id
                                            else 0
                                            end)
    )from pensioners pe where pe.id = p.pensioner_id) pin,
    (select name from banks where id = (select bank_id from bank_branches where id = p.bankbranch_id))bank_name,
    (select (select firstname||' '||surname from members where id =
                                                               (case
                                                                when pe.member_id is null then (select member_id from beneficiaries where id = pe.beneficiary_id and rownum = 1)
                                                                when pe.beneficiary_id is null then pe.member_id
                                                                else 0
                                                                end)
    ) from pensioners pe where pe.id = p.pensioner_id) member_name,
    (select (select member_no from members where id =
                                                 (case
                                                  when pe.member_id is null then (select member_id from beneficiaries where id = pe.beneficiary_id and rownum = 1)
                                                  when pe.beneficiary_id is null then pe.member_id
                                                  else 0
                                                  end)
    ) from pensioners pe where pe.id = p.pensioner_id) member_no,
    p.ACCOUNT_NO ACCOUNT_NUMBER,
    (select ACCOUNT_NAME from pensioners where id = p.pensioner_id) ACCOUNT_NAME,gross,
    (
      case when gross>25000 then gross-25000
      when gross<25000 then 0
      else 0
      end
    )taxable,
    coalesce(tax_on_arreas, 0) + coalesce(tax, 0) tax, coalesce(net, 0) + coalesce(arreas, 0) net,
    (select DATE_AUTHORIZED from payroll_batches where id = batch_id and rownum = 1) DATE_AUTHORIZED,
    (select DATE_CHECKED  from payroll_batches where id = batch_id and rownum = 1) DATE_CHECKED ,
    (select DATE_PREPARED from payroll_batches where id = batch_id and rownum = 1) DATE_PREPARED,
    (select FIRSTNAME||''||OTHERNAMES from users where id = (select AUTHORIZEDBY_ID  from payroll_batches where id = batch_id and rownum = 1)) author,
    (select FIRSTNAME||''||OTHERNAMES from users where id = (select CHECKEDBY_ID   from payroll_batches where id = batch_id and rownum = 1)) checker,
    (select FIRSTNAME||''||OTHERNAMES from users where id = (select PREPAREDBY_ID   from payroll_batches where id = batch_id and rownum = 1)) preparer
  from payroll p
    inner join pensioners pe on pe.id = p.pensioner_id and pe.SCHEME_ID = (select grp.scheme_id from V_GENERAL_REPORTS_PARAMS grp)
  where tax>0 and  p.pension_status='ACTIVE'  and p.month = (select grp.MONTH from V_GENERAL_REPORTS_PARAMS grp) and p.year = (select grp.year from V_GENERAL_REPORTS_PARAMS grp)
) order by member_no
/

