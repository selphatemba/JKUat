create view V_ACC_WITHHOLDINGTAX_P9_DRAFT as
  select
    p.POSTED_DATE,
    to_char(POSTED_DATE,'MON') monthposted,
    extract(YEAR from POSTED_DATE) yearposted,
    pl.particulars,
    (coalesce(pl.SC_VALUE, 0)-COALESCE(pl.VAT_AMOUNT, 0))*COALESCE(pl.SPOT_RATE, 1) chargablePay,
    coalesce(pl.wht_amount, 0)*COALESCE(pl.SPOT_RATE, 1) tax,
    p.id payment_id,
    pl.whtax_id taxId,
    (select i.invoice_no from INVOICES i where i.id=pa.INVOICE2_ID) invoiceNo,
    coalesce(p.WHVAT_AMOUNT, 0)*COALESCE(pl.SPOT_RATE, 1) withholdingVat,
    coalesce(p.CONTROL_AMT, 0)*COALESCE(pl.SPOT_RATE, 1) controlAmt,
    coalesce(p.VAT_AMOUNT, 0)*COALESCE(pl.SPOT_RATE, 1) vatAmt,
    (select rate.RATE from WITHHOLDINGTAX_RATES rate where rate.ID=pl.WHTAX_ID) rate
  from payments p
    LEFT JOIN PAYMENT_APPLICATIONS pa on p.ID=pa.PAYMENT2_ID, payment_lines pl
  where payment_type = 'DISBURSEMENT'
        and POSTED = 'YES'
        and (P.REVERSED is null or p.REVERSED != 'YES')
        and p.id = pl.payment_id
        and p.scheme_id=(SELECT grp.SCHEME_ID FROM V_GENERAL_REPORTS_PARAMS grp)
        and p.POSTED_DATE between (SELECT grp.DATE_FROM FROM V_GENERAL_REPORTS_PARAMS grp) and (SELECT grp.DATE_TO FROM V_GENERAL_REPORTS_PARAMS grp)
        and pl.wht_amount > 0
        and (select whrate.CATEGORY_ID from WITHHOLDINGTAX_RATES whrate where whrate.ID=pl.WHTAX_ID)=(select grp.TAX_CATEGORY from V_GENERAL_REPORTS_PARAMS grp)
        and p.CREDITORDEBTOR_ID in (SELECT grp.creditorDebtorId FROM V_GENERAL_REPORTS_PARAMS grp)
/

