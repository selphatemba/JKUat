create view V_PAYREC_STOPPED_ATT_AGE as
  with params as (
      select (SELECT MONTH FROM V_PAYREC_PARAMS) monthpar, (SELECT YEAR FROM V_PAYREC_PARAMS) yearpar from dual
  ), addparams as(
      select to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM')-1, 'MON') prevmonth,
             to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM')-1, 'YYYY') prevyear,
             to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM'), 'Month') monthlong,
        par.*
      from params par
  ), cachetab as(
      select * from payroll pay, addparams adp
      where (pay.year = adp.yearpar and pay.month = adp.monthpar) or (pay.month = adp.prevmonth and pay.year = adp.prevyear )
  ) , thispayroll as(
      select ct.* from cachetab ct, addparams adp where month = adp.monthpar and year = adp.yearpar
  ), lastpayroll as(
      select ct.* from cachetab ct, addparams adp where month = adp.prevmonth and year = adp.prevyear
  )
  select (select PAYROLL_RECON_PARAMS.SCHEME_ID from PAYROLL_RECON_PARAMS) scheme_id,
         case when pe.pension_status = 'STOPPED' and pe.member_id is null  then 'Attained Age' else pe.pension_status end label,
         case when pe.member_id is null then (select member_no from beneficiaries ben, members mem where ben.member_id=mem.id and ben.id = pe.BENEFICIARY_ID) else (select member_no from  members where id= pe.member_id) end member_no,
    pe.pension_no,
         case when pe.member_id is null  then (select surname||', '||firstname||' '||othernames from beneficiaries where id = pe.BENEFICIARY_ID) else (select surname||', '||firstname||' '||other_names from  members where id= pe.member_id) end names,
         (coalesce(lp.gross,0)+coalesce(lp.arreas,0))-(coalesce(lp.deds,0)+coalesce(lp.tax,0)+ coalesce(lp.tax_on_arreas,0)) last_pension,
         (coalesce(0,0)+coalesce(0,0))-(coalesce(0,0)+coalesce(0,0)) this_pension,
    pe.account_no,
         (select bb.name from bank_branches bb where bb.id = pe.branch_id) current_branch,
         (select b.name from banks b where b.id = (select bb.bank_id from bank_branches bb where bb.id = pe.branch_id)) current_bank
  from lastpayroll lp, pensioners pe
  where pe.id = lp.pensioner_id
        and lp.pension_status = 'SUSPENDED'
        and (lp.pensioner_id not in (select tp.pensioner_id from thispayroll tp , pensioners p where tp.pensioner_id = p.id and p.pension_status = 'STOPPED' or p.pension_status = 'DECEASED')
             or lp.pensioner_id  in (select distinct(tp.pensioner_id) from thispayroll tp  where (tp.pension_status = 'STOPPED' or tp.pension_status = 'DECEASED'))
        )
  order by pe.pension_no DESC
/

