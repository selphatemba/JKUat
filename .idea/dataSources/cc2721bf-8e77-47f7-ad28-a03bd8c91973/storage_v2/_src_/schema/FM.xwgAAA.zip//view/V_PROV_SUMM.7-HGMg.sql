create view V_PROV_SUMM as
  with pa1 as (
      select (SELECT MEMBER_ID_FROM FROM V_GENERAL_REPORTS_PARAMS) member_id_p, (SELECT AP_ID FROM V_GENERAL_REPORTS_PARAMS) ap_id_p from dual
  ), pa0 as (
      select id from accounting_periods, pa1  p where  scheme_id=(select scheme_id from members where id = p.member_id_p) and id=p.ap_id_p  and period_type=(select period_type from accounting_periods where id = p.ap_id_p ) order by id desc
  ),pa2 as(
      select id prev_ap from pa0 where rownum=1
  )
  SELECT
    ----------------------------INTEREST------------------
    coalesce(sum( coalesce(ee_intr,0)+coalesce(EE_PAYMENTS_INTR,0)+coalesce(EE_WITHDR_INTR,0)+coalesce(transfer_ee_intr,0)),0) as "Normal Employee",
    coalesce(sum(coalesce(er_intr,0)+coalesce(ER_WITHDR_INTR,0)+coalesce(TRANSFER_ER_INTR,0)),0) as "Normal Employer",
    coalesce(sum(coalesce(AVCER_INTR,0) + coalesce(AVCER_WITHDR_INTR,0) +coalesce(AVC_INTR,0) + coalesce(AVC_WITHDR_INTR,0)+ coalesce(TRANSFER_AVC_INTR ,0)+ coalesce(TRANSFER_AVCER_INTR ,0)),0) as "Combined Avc Interest",
    coalesce((sum(coalesce(ee_intr,0))+sum(coalesce(er_intr,0))+(sum(coalesce(avc_intr,0)+coalesce(avcer_intr,0)+coalesce(AVC_WITHDR_INTR,0)+coalesce(AVCER_WITHDR_INTR,0)+coalesce(EE_PAYMENTS_INTR,0)))),0)total,
    coalesce(sum( coalesce(ER_BALINTR,0)+coalesce(TRANSFER_ER_BALINTR,0)),0) as "Opening Balance Employer",
    coalesce(sum(coalesce(EE_BALINTR,0)+coalesce(TRANSFER_EE_BALINTR,0)),0) as "Opening Balance Employee",
    coalesce(sum(coalesce(AVCER_BALINTR,0)+coalesce(AVC_BALINTR,0)+coalesce(TRANSFER_AVC_BALINTR,0)+coalesce(TRANSFER_AVCER_BALINTR,0)),0) as "Opening Balance Avc",
    coalesce(sum(coalesce(EE_BAL,0)+coalesce(EE_WITHDR,0)+
                 coalesce(AVC_BAL,0)+coalesce(AVCER_BAL,0)+coalesce(AVCER_WITHDR,0)+coalesce(AVC_WITHDR,0)+
                 coalesce(ER_BAL,0)+coalesce(ER_WITHDR,0)+
                 coalesce(EE_BALINTR,0)+
                 coalesce(AVCER_BALINTR,0)+coalesce(AVC_BALINTR,0)+
                 coalesce(ER_BALINTR,0)+
                 coalesce(EE_CONTR,0)+
                 coalesce(AVC_CONTR,0)+coalesce(AVCER_CONTR,0)+
                 coalesce(ER_CONTR,0)+
                 coalesce(EE_INTR,0)+coalesce(EE_WITHDR_INTR,0)+
                 coalesce(AVCER_INTR,0) + coalesce(AVCER_WITHDR_INTR,0)
                 +coalesce(AVC_INTR,0) +
                 coalesce(AVC_WITHDR_INTR,0) +
                 coalesce(ER_INTR,0)+coalesce(ER_WITHDR_INTR,0)+
                 coalesce(er_payments,0) + coalesce(ee_payments,0)+coalesce(TRANSFER_ER,0) +
                 coalesce(TRANSFER_ER_BAL,0) +  coalesce(TRANSFER_ER_BALINTR ,0)  +
                 coalesce(TRANSFER_ER_INTR,0) + coalesce(TRANSFER_EE  ,0) +
                 coalesce(TRANSFER_EE_BAL,0)  + coalesce(TRANSFER_EE_BALINTR,0) +
                 coalesce(TRANSFER_EE_INTR,0)  + coalesce(TRANSFER_AVC,0) +
                 coalesce(TRANSFER_AVC_BAL,0) + coalesce(TRANSFER_AVC_BALINTR,0) +
                 coalesce(TRANSFER_AVC_INTR,0) + coalesce(TRANSFER_AVCER_BALINTR,0) +
                 coalesce(TRANSFER_AVCER_INTR,0) + coalesce(TRANSFER_AVCER,0)+
                 coalesce(TRANSFER_AVCER_BAL,0)+coalesce(EE_RSV_INCOME,0) ),0) as "Grand Total "
  FROM CLOSING_BALANCES cb, pa2 p, pa1 ps where member_id = member_id_p and ASAT=(select max(ASAT) from CLOSING_BALANCES cb WHERE cb.MEMBER_ID=member_id_p)
/

