create view V_DBWRKSHT_RET_PENSIONER as
  select p.*
  from pensioners p where member_id = (select grp.MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS grp)
/

