create view V_ACC_TB_NOTES as
  select
    ID,
    ACCOUNT_CODE,
    ACCOUNT_ID,
    ACCOUNT_NAME,
    AP_ID,
    CR,
    DR,
    SCHEME_ID,
    TXN_DATE
  from TBNOTESREPORT
/

