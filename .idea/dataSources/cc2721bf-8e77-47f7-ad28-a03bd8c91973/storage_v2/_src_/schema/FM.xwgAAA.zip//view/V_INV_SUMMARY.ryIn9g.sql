create view V_INV_SUMMARY as
  WITH params AS (SELECT '' schemeid, 1 todate FROM DUAL),
      CACHE
    AS (  SELECT inv.id,
            TO_CHAR (txn.TRANS_DATE, 'YYYY') inv_year,
            inv.scheme_id,
            inv.investment_category,
            ---current holding for bonds acquisition + accrued interest
            SUM (
                CASE
                WHEN investment_type = 'SECURITY_BOND'
                  THEN
                    COALESCE (inv.initial_value, 0)
                WHEN investment_type = 'FIXED_TERM_DEPOSIT'
                  THEN
                    COALESCE (inv.initial_value, 0)
                WHEN investment_type = 'CASH_AND_CALL_DEPOSIT'
                  THEN
                    COALESCE (inv.initial_value, 0)
                WHEN investment_type = 'PROPERTY'
                  THEN
                    COALESCE (inv.initial_value, 0)
                WHEN investment_type = 'EQUITY'
                  THEN
                    COALESCE (inv.market_value, 0)
                    * COALESCE (inv.quantity, 0)
                ELSE
                  0
                END)
            + COALESCE (
                SUM (
                    CASE
                    WHEN     investment_type = 'SECURITY_BOND'
                             AND txn.bondtrans_type = 'ACQUISITION'
                             AND transaction_type = 'BOND_TRANSACTION'
                      THEN
                        COALESCE (txn.amount, 0)
                    WHEN investment_type = 'FIXED_TERM_DEPOSIT'
                      THEN
                        COALESCE (txn.amount, 0)
                    WHEN investment_type = 'CASH_AND_CALL_DEPOSIT'
                      THEN
                        COALESCE (txn.amount, 0)
                    WHEN investment_type = 'PROPERTY_TXN'
                      THEN
                        COALESCE (txn.amount, 0)
                    WHEN txn.transaction_type =
                         'EQUITY_ACQUISITION'
                      THEN
                        COALESCE (txn.shares_bought, 0)
                        * COALESCE (txn.price_per_share, 0)
                    ELSE
                      0
                    END),
                0)
            + SUM (COALESCE (inc.accrued_income, 0))
                                             holding
          FROM INVESTMENTS inv
            LEFT JOIN INVESTMENT_TXNS txn
              ON inv.id = txn.investment_id
            INNER JOIN params par ON 'join' = 'join'
            LEFT JOIN INTREST_INCOME_DUE inc ON inc.bond_id = inv.id
          GROUP BY inv.investment_category,
            inv.scheme_id,
            inv.id,
            TO_CHAR (txn.TRANS_DATE, 'YYYY'))
  SELECT COUNT (id) id,
    scheme_id,
    inv_year,
    investment_category,
         (SELECT SUM (holding) FROM CACHE) grand,
         SUM (holding) face_value,
         SUM (holding) holding,
         SUM (holding) / (SELECT SUM (holding) FROM CACHE) * 100 actual,
         0 target,
         SUM (holding) / (SELECT SUM (holding) FROM CACHE) * 100 - 0
           VARIANCE
  FROM CACHE
  GROUP BY investment_category, scheme_id, inv_year
/

