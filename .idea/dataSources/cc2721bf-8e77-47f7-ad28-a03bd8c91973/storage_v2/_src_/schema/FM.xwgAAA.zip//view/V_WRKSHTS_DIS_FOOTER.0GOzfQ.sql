create view V_WRKSHTS_DIS_FOOTER as
  select (select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) SCHEME_ID,
         (select
            case when  (r.CATEGORY!='WITHDRWAL' and m.MBSHIP_STATUS!='DIFFERED') then 0
            else case when (r.CATEGORY='WITHDRWAL' and m.MBSHIP_STATUS='DIFFERED') then
              (coalesce(b.Er_TOT,0)*0.5)else coalesce(b.Er_TOT,0)
                 end
            end
          from benefits ben inner join reasons_for_exit r on r.id=ben.REASONFOREXIT_ID
            inner join members m on m.exit_id =ben.id  where ben.id=b.id)forfeiture,
         (select firstname||' '||OTHERNAMES  from users where id = authorizedby_id) authorize_psn,
         (select firstname||' '||OTHERNAMES from users where id = preparedby_id) prepare_psn,
         (select firstname||' '||OTHERNAMES from users where id = certifiedby_id) certifier,
         (select sum(coalesce(pct_monthly/100, 0))*(coalesce(b.arrears_period,0))*((coalesce(b.monthly_pens,0))+(coalesce(b.monthly_pens2,0))) from beneficiaries where member_id =(select id from members where exit_id = b.id) ) pension_arrears,
         coalesce(tot_liab, 0) liabilities
  from benefits b where to_char(id) = (select grp.benefits_id from V_GENERAL_REPORTS_PARAMS grp)
/

