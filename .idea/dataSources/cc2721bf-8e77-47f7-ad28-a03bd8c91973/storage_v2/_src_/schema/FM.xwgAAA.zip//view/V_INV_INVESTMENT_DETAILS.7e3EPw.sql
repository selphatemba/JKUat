create view V_INV_INVESTMENT_DETAILS as
  select i.NAME, i.CODE from investments i where i.ID=(select grp.INVEST_ID_FROM from V_GENERAL_REPORTS_PARAMS grp)
/

