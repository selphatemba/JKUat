create view V_PAYROLL_BANKFILE_3X as
  with params as
  (select
     (select grp.MONTH from V_GENERAL_REPORTS_PARAMS grp) monthpar,
     (select grp.YEAR from V_GENERAL_REPORTS_PARAMS grp) yearpar from dual
  ),
      addparams as
    (select to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM')-1, 'MON') prevmonth,
            to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM')-1, 'YYYY') prevyear,
            to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM'), 'Month') monthlong,par.* from params par
    ),
      cachetab as
    (select * from payroll pay, addparams adp where (pay.year = adp.yearpar and pay.month = adp.monthpar) or (pay.month = adp.prevmonth and pay.year = adp.prevyear )),
      lastpayroll as
    (select ct.* from cachetab ct, addparams adp where month = adp.prevmonth and year = adp.prevyear),
      thispayroll as
    (select ct.* from cachetab ct, addparams adp where month = adp.monthpar and year = adp.yearpar),
      list as
    (select ou.MEMBER_NO, ou.BANK_CODE, ou.ACCOUNT_NUMBER,
       (
         select pen.ACCOUNT_NAME from pensioners pen
         where pen.ID = (select p.PENSIONER_ID from payroll p where p.ACCOUNT_NO = ou.ACCOUNT_NUMBER and rownum = 1) and rownum = 1
       ) ACCOUNT_NAME, ou.BANKBRANCH_ID, ou.BRANCH_CODE as TRANSFER_CODE, ou.BRANCH_CODE, ou.PAYROLL_DATE,
       case when mod(to_number(coalesce(SUBSTR(to_char(net), INSTR(to_char(net),'.') + 1), '0')), 5) = 0 then net
       when to_number(coalesce(SUBSTR(to_char(net), INSTR(to_char(net),'.') + 1), '0')) < 10 then net
       else net end net, pensioner_id
     from
       (
         select MEMBER_NO, BANK_CODE, BANKBRANCH_ID, ACCOUNT_NUMBER, bank, BRANCH_CODE, PAYROLL_DATE, round((sum(net))*20)/20 net, pensioner_id
         from (select (select bk.NAME from BANKS bk INNER JOIN BANK_BRANCHES bb on bk.ID = bb.BANK_ID where bb.ID=pay.BANKBRANCH_ID ) bank,
                      (select bk.CODE from BANKS bk INNER JOIN BANK_BRANCHES bb on bk.ID = bb.BANK_ID where bb.ID=pay.BANKBRANCH_ID ) BANK_CODE,
                      pay.BANKBRANCH_ID BANKBRANCH_ID, to_char(coalesce(pay.DATE_PREPARED, last_day(to_date('01-'||pay.month||'-'||pay.year))), 'dd/MM/yyyy') PAYROLL_DATE,
                      pay.ACCOUNT_NO ACCOUNT_NUMBER, (coalesce(pay.GROSS, 0) + coalesce(pay.ARREAS, 0) - coalesce(pay.DEDS, 0) - coalesce(pay.TAX, 0)) net,
                      (select MEMBER_NO from members where id = (case when pen.member_id is not null then pen.member_id else (select member_id from beneficiaries where id = pen.BENEFICIARY_ID)  end)) MEMBER_NO,
                      (case when pen.member_id is null then (select beneficiaries.FIRSTNAME||' '||beneficiaries.OTHERNAMES||' '||beneficiaries.surname from beneficiaries  where id = pen.BENEFICIARY_ID) else (select members.FIRSTNAME||' '||members.OTHER_NAMES||' '||members.SURNAME from members where id = pen.member_id) end) ACCOUNT_NAME,
                      (pay.PENSIONER_ID) pensioner_id,
                      (select substr(bb.CODE, 3, 3) from BANK_BRANCHES bb where id = pay.BANKBRANCH_ID) BRANCH_CODE
               from thispayroll pay inner join pensioners pen on pay.PENSIONER_ID = pen.ID
               where (pay.pension_status = 'ACTIVE' or pay.pensioner_id in ( select lp.pensioner_id from lastpayroll lp where lp.pension_status = 'ACTIVE' and pay.pension_status = 'STOPPED')
                     ) and pay.BANKBRANCH_ID in (select id from BANK_BRANCHES where BANK_BRANCHES.BANK_ID in (2692613,2823096,7303))
         ) GROUP BY bank, PAYROLL_DATE, BANK_CODE, BANKBRANCH_ID, ACCOUNT_NUMBER, MEMBER_NO, BRANCH_CODE,net,pensioner_id) ou
    )
  select
    MEMBER_NO, BANK_CODE, ACCOUNT_NUMBER, ACCOUNT_NAME, BANKBRANCH_ID, TRANSFER_CODE, BRANCH_CODE, PAYROLL_DATE, sum(net) PENSION,
                                                                                                                 (select (select grp.MONTH from V_GENERAL_REPORTS_PARAMS grp) ||'/'||(select grp.YEAR from V_GENERAL_REPORTS_PARAMS grp)||' PAYROLL' from dual) COMMENTS, pensioner_id
  from list
  group by MEMBER_NO, BANK_CODE, ACCOUNT_NUMBER, BANKBRANCH_ID, PAYROLL_DATE, BRANCH_CODE, TRANSFER_CODE, ACCOUNT_NAME, pensioner_id order by ACCOUNT_NUMBER asc
/

