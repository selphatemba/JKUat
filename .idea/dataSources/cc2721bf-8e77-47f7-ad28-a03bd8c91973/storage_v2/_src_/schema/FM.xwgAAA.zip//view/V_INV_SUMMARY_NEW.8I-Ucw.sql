create view V_INV_SUMMARY_NEW as
  with params as(
    select
      (select case when TOTAL_HOLDING=0 then 1 else TOTAL_HOLDING end from V_INV_SUM_TOTALHOLD)total_holding
    from dual
)
SELECT cls.SCHEME_ID, cls.CLASS, hold.ACQUISITIONS, hold.SALES, hold.VALUATION, hold.HOLDING,
  p.total_holding totalHolding,
  (100*hold.HOLDING/p.total_holding)actual,
  ((100*hold.HOLDING/p.total_holding) - coalesce(tact.TARGET, 0))variance,
  ((coalesce(tact.TARGET, 0)/(100*hold.HOLDING/p.total_holding))*hold.HOLDING) target_amount,
  hold.HOLDING - ((coalesce(tact.TARGET, 0)/(100*hold.HOLDING/p.total_holding))*hold.HOLDING) variance_amount,
  coalesce(tact.TARGET, 0)target, coalesce(tact.STRATEGIC, 0)strategic, tact.EFFECTIVE_DATE, tact.MAX
FROM params p, V_INVESTMENT_CLASSES cls
  LEFT JOIN V_INV_SUM_HOLDINGS hold ON cls.CLASS=hold.CLASS
  LEFT JOIN V_INV_SUM_TACTICAL tact ON cls.CLASS=tact.CATEGORY
/

