create view V_AR_NORMAL_RET_LIST_DB as
  with quarter as (
    select (select QUARTER from V_AR_PARAMS) q, (select SCHEME_ID from V_AR_PARAMS) scheme_id, (select YEAR FROM V_AR_PARAMS) yr from dual
  ),quarterdef as (
      select case
      when q = 1 then '01-JAN-'||''||qt.yr
                                   when q = 2 then '01-APR-'||''||qt.yr
                                                            when q = 3 then '01-JUL-'||''||qt.yr
                                                                       when q = 4 then '01-OCT-'||''||qt.yr
      else ''
      end as from_date_qt,
      case
      when q = 1 then '31-MAR-'||''||qt.yr
               when q = 2 then '30-JUN-'||''||qt.yr
                                                 when q = 3 then '30-SEP-'||''||qt.yr
                                                                                when q = 4 then '31-DEC-'||''||qt.yr
                                                                                                           else ''
                                                                                                           end as to_date_qt
      from quarter qt
                                      ), tabo as(
      select from_date_qt, to_date_qt, mem.SCHEME_ID AS scheme_id, DATE_OF_EXIT, member_no, mem.surname||', '||mem.firstname||' '||other_names member_name,
                                              to_char(mem.DATE_JOINED_SCHEME,  'dd/MM/yyyy') join_date,(select name from sponsors where id = (select sponsor_id from companies where id = mem.company_id)) sponsor,
      (select reason from REASONS_FOR_EXIT where id = ben.reasonforexit_id) reason,
                                                                            decode(mem.MBSHIP_STATUS, 'NOTIFIED', 'Notified','RETIRED' , 'Retired', 'RETIRED_ILL_HEALTH', 'Ill-health', 'DEATH_IN_SERVICE', 'Death in Service', mem.MBSHIP_STATUS) MBSHIP_STATUS
                                                                                                                                                                                                                                                   from members mem, quarterdef pe,  quarter qtr, benefits ben where  mem.exit_id = ben.id and mem.scheme_id=qtr.scheme_id and ben.reasonforexit_id in (select id from REASONS_FOR_EXIT where reason = 'Normal Retirement')  and mem.scheme_id=qtr.scheme_id and date_of_exit between from_date_qt and to_date_qt
                                                )select tabo."FROM_DATE_QT",tabo."TO_DATE_QT",tabo."SCHEME_ID",tabo."DATE_OF_EXIT",tabo."MEMBER_NO",tabo."MEMBER_NAME",tabo."JOIN_DATE",tabo."SPONSOR",tabo."REASON",tabo."MBSHIP_STATUS", (select count(*) from tabo where mbship_status = 'Retired') cnt from tabo
/

