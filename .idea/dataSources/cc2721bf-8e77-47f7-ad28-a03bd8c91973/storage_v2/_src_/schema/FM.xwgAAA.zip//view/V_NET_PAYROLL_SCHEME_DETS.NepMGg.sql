create view V_NET_PAYROLL_SCHEME_DETS as
  select sc.ID scheme_id, scheme_name, fax, email, building, fixed_phone ,postal_address||', '||TOWN||', '||COUNTRY postal_address, road, country, website  from schemes sc where id = (select npp.SCHEME_ID from NET_PAYROLL_PB_PARAMS npp)
/

