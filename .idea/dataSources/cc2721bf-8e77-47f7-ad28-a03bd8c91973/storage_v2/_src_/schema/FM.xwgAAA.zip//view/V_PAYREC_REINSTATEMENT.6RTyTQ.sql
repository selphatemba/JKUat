create view V_PAYREC_REINSTATEMENT as
  with params as (
      select (SELECT MONTH FROM V_PAYREC_PARAMS) monthpar, (SELECT YEAR FROM V_PAYREC_PARAMS) yearpar from dual
  ), addparams as(
      select to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM')-1, 'MON') prevmonth,
             to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM')-1, 'YYYY') prevyear,
             to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM'), 'Month') monthlong,
        par.*
      from params par
  ), cachetab as(
      select * from payroll pay, addparams adp
      where (pay.year = adp.yearpar and pay.month = adp.monthpar) or (pay.month = adp.prevmonth and pay.year = adp.prevyear )
  ) , thispayroll as(
      select ct.* from cachetab ct, addparams adp where month = adp.monthpar and year = adp.yearpar
  )
  select (select PAYROLL_RECON_PARAMS.SCHEME_ID from PAYROLL_RECON_PARAMS) scheme_id,
         'Reinstatement' label,
         case when pe.member_id is null then (select member_no from beneficiaries ben, members mem where ben.member_id=mem.id and ben.id = pe.BENEFICIARY_ID) else (select member_no from  members where id= pe.member_id) end member_no,
    pe.pension_no,
         case when pe.member_id is null then (select surname||', '||firstname||' '||othernames from beneficiaries where id = pe.BENEFICIARY_ID) else (select surname||', '||firstname||' '||other_names from  members where id= pe.member_id) end names,
         (coalesce(0,0)+coalesce(0,0))-(coalesce(0,0)+coalesce(0,0)) last_pension,
         (coalesce(tp.gross,0)+coalesce(tp.arreas,0)-coalesce(tp.tax,0)) this_pension,
    pe.account_no,
         (select bb.name from bank_branches bb where bb.id = pe.branch_id) current_branch,
         (select b.name from banks b where b.id = (select bb.bank_id from bank_branches bb where bb.id = pe.branch_id)) current_bank
  from thispayroll tp , pensioners pe  where pe.id = tp.pensioner_id and ( tp.recont_type = 'NEW_ENTRANT') AND pe.ID in (select ps.PENSIONER_ID from PENSION_SUSPENSION ps)
  order by pe.pension_no DESC
/

