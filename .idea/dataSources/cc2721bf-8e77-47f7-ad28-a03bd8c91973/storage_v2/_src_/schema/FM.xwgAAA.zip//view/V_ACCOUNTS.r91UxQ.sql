create view V_ACCOUNTS as
  SELECT ac.id account_id,
          ac.SCHEME_ID,
          ac.CODE,
          ac.LFT,
          ac.NAME,
          ac.RGT,
          ac.ACCOUNT_TYPE,
          ac.CATEGORY,
          ac.FRHD_ID,
          ac.CF_HEADER,
          DECODE (ac.CF_HEADER,
                  'NET_CASH', 'Net Cash and Cash Equivalents',
                  'OPERTNG_ACTIVITIES', 'Operating Activities',
                  'INVESTING', 'Investing Activities',
                  'FINANCING', 'Financing Activities',
                  ac.CF_HEADER)
             CF_HEADER_DET,
          fhd.DESCR fin_header_dets_desc,
          fhd.NAME fin_header_dets_name,
          fhd.POSITION fin_header_dets_pos,
          fhd.header_id,
          fh.CATEGORY fin_header_CATEGORY,
          fh.DESCR fin_header_DESCR,
          fh.HEADER_TYPE fin_header_TYPE,
          fh.NAME fin_header_NAME,
          fh.POSITION fin_header_POSITION,
          fhd.STATEMENTGROUP_ID,
          isg.DESCR INC_STMT_GRP_DESCR,
          isg.NAME INC_STMT_GRP_NAME,
          isg.SCHEME_ID INC_STMT_GRP_SCHEME_ID,
          CASE
             WHEN CODE IN ('001-100-101',
                           '001-100-102',
                           '001-100-103',
                           '001-100-105')
             THEN
                'PPE'
             WHEN CODE IN ('001-100-104')
             THEN
                'Intangible assets'
             WHEN CODE IN ('001-200-201', '001-200-202', '001-200-203')
             THEN
                'Investment Property'
             WHEN CODE IN ('001-200-229')
             THEN
                'Work In Progress-Karen DB'
             WHEN CODE IN ('001-200-205')
             THEN
                'WIP -Loresho'
             WHEN CODE IN ('001-200-206')
             THEN
                'WIP- Stima Expansion'
             WHEN CODE IN ('001-200-233')
             THEN
                'WIP-Umeme Plaza development'
             WHEN CODE IN ('001-200-207')
             THEN
                'Government securities-Stanlib'
             WHEN CODE IN ('001-200-208')
             THEN
                'Government securities-Co-optrust'
             WHEN CODE IN ('001-200-210')
             THEN
                'Treasury Bills-Co-optrust'
             WHEN CODE IN ('001-200-209')
             THEN
                'Treasury Bills-Stanlib'
             WHEN CODE IN ('001-200-212')
             THEN
                'Corporate bonds Co-optrust'
             WHEN CODE IN ('001-200-211')
             THEN
                'Corporate bonds Stanlib'
             WHEN CODE IN ('001-200-230')
             THEN
                'Private Equity-Ascent Riftvalley'
             WHEN CODE IN ('001-200-232')
             THEN
                'Unquoted Equity-Gulf power'
             WHEN CODE IN ('001-200-216')
             THEN
                'Quoted Equities-Co-optrust'
             WHEN CODE IN ('001-200-219')
             THEN
                'Quoted Equities-Stanlib'
             WHEN CODE IN ('001-200-221')
             THEN
                'Commercial paper Co-optrust'
             WHEN CODE IN ('001-200-220')
             THEN
                'Commercial paper -Stanlib'
             WHEN CODE IN ('001-200-214')
             THEN
                'Short term deposits-Co-optrust'
             WHEN CODE IN ('001-200-213')
             THEN
                'Short term deposits-Stanlib'
             WHEN CODE IN ('001-200-223')
             THEN
                'Offshore-Co-optrust'
             WHEN CODE IN ('001-200-222')
             THEN
                'Offshore-Stanlib'
             --
             --
             WHEN CODE IN ('001-300-301')
             THEN
                'Cashbook-Co-op bank Current'
             WHEN CODE IN ('001-200-215')
             THEN
                'Cashbook-Co-op bank Call a/c'
             WHEN CODE IN ('001-300-302')
             THEN
                'Stanchart Custody'
             WHEN CODE IN ('001-300-303')
             THEN
                'CFC Stanbic Bank'
             WHEN CODE IN ('001-300-304')
             THEN
                'Imprest'
             --
             --
             WHEN CODE IN ('001-300-306')
             THEN
                'Due from Defined Contribution'
             WHEN CODE IN ('001-300-305')
             THEN
                'Due from KPLC'
             WHEN CODE IN ('001-300-310')
             THEN
                'Propery sales receivable - Runda'
             WHEN CODE IN ('001-300-311')
             THEN
                'Propery sales receivable - Loresho'
             WHEN CODE IN ('001-300-309')
             THEN
                'Other receivables'
             WHEN CODE IN ('001-300-312')
             THEN
                'Loresho Stocks'
             --
             --
             WHEN CODE IN ('003-200-201')
             THEN
                'Rental income'
             WHEN CODE IN ('003-200-202')
             THEN
                'Gain/Loss on fair value of properties'
             WHEN CODE IN ('003-200-203')
             THEN
                'Gain/Loss on sale of properties'
             WHEN CODE IN ('003-200-246')
             THEN
                'Contributions Received'
             WHEN CODE IN ('003-200-205')
             THEN
                'Interest on Govert  Bonds Co-optrust'
             WHEN CODE IN ('003-200-204')
             THEN
                'Interest on Govert Bonds Stanlib'
             WHEN CODE IN ('003-200-207')
             THEN
                'Gain/Loss on valuation  Govert Bonds Co-optrust'
             WHEN CODE IN ('003-200-206')
             THEN
                'Gain/Loss on valuation  Govert Bonds Stanlib'
             WHEN CODE IN ('003-200-209')
             THEN
                'Gain/Loss on Disposal  Govert Bonds Co-op'
             WHEN CODE IN ('003-200-208')
             THEN
                'Gain/Loss on Disposal  Govert Bonds Stanlib'
             WHEN CODE IN ('003-200-209')
             THEN
                'Gain on valuation Treasury Bills Co-optrust'
             WHEN CODE IN ('003-200-208')
             THEN
                'Gain/Loss on Disposal  Treasury Bill Stanlib'
             WHEN CODE IN ('003-200-248')
             THEN
                'Gain on valuation Treasury Bills co-optrust'
             WHEN CODE IN ('003-200-247')
             THEN
                'Gain on valuation Treasury Bills Stanlib'
             WHEN CODE IN ('003-200-213')
             THEN
                'Commssion Co-optrust'
             WHEN CODE IN ('003-200-212')
             THEN
                'Commssion Stanlib'
             WHEN CODE IN ('003-200-211')
             THEN
                'Rebates on Bonds Co-optrust'
             WHEN CODE IN ('003-200-210')
             THEN
                'Rebates on Bonds Stanlib'
             --
             --
             WHEN CODE IN ('003-200-215')
             THEN
                'Interest on corporate bonds-Co-optrust'
             WHEN CODE IN ('003-200-214')
             THEN
                'Interest on corporate bonds-Stanlib'
             WHEN CODE IN ('003-200-217')
             THEN
                'Gain/Loss on valuation Corporate bonds Co-optrust'
             WHEN CODE IN ('003-200-216')
             THEN
                'Gain/Loss on valuation corporate bonds-Stanlib'
             WHEN CODE IN ('003-200-219')
             THEN
                'Gain/Loss on Disposal Corporate bonds Co-optrust'
             WHEN CODE IN ('003-200-218')
             THEN
                'Gain/Loss on Disposal Corporate bonds Stanlib'
             --
             --
             WHEN CODE IN ('003-200-220')
             THEN
                'Dividends receivable-Stanlib'
             WHEN CODE IN ('003-200-221')
             THEN
                'Dividends receivable-Co-optrust'
             WHEN CODE IN ('003-200-223')
             THEN
                'Gain/loss on Valuation of quoted investments-Co-optrust'
             WHEN CODE IN ('003-200-222')
             THEN
                'Gain/loss on Valuation of quoted investments-Stanlib'
             WHEN CODE IN ('003-200-225')
             THEN
                'Gain/Loss on Disposal Equities-Co-optrust'
             WHEN CODE IN ('003-200-224')
             THEN
                'Gain/Loss on Disposal Equities-Stanlib'
             --
             --
             WHEN CODE IN ('003-200-249')
             THEN
                'Income from Private Equity-Ascent Rift Valley'
             WHEN CODE IN ('003-200-250')
             THEN
                'Income from private equity noora power ltd'
             WHEN CODE IN ('003-200-251')
             THEN
                'Income from Private Equity Gulf Power'
             --
             --
             WHEN CODE IN ('003-200-234')
             THEN
                'Income from Commercial paper co-op'
             WHEN CODE IN ('003-200-233')
             THEN
                'Income from Commercial paper Stanlib'
             --
             --
             WHEN CODE IN ('003-200-231')
             THEN
                'Interest on Deposits -Co-optrust'
             WHEN CODE IN ('003-200-230')
             THEN
                'Interest on Deposits-Stanlib'
             --
             --
             WHEN CODE IN ('003-200-237')
             THEN
                'Gain/loss on offshore investment -Co-optrust'
             WHEN CODE IN ('003-200-236')
             THEN
                'Gain/loss on offshore investment-Stanlib'
             WHEN CODE IN ('003-200-238', '003-200-239')
             THEN
                'Exchange gain'
             --
             --
             WHEN CODE IN ('003-200-240')
             THEN
                'Other income'
             WHEN CODE IN ('003-200-240')
             THEN
                'Writeback provisions'
             WHEN CODE IN ('003-200-240')
             THEN
                'Admin reimbursements from DC'
             --
             --
             WHEN CODE IN ('004-100-102')
             THEN
                'Withdrawals'
             WHEN CODE IN ('004-100-101')
             THEN
                'Pension'
             --
             --
             WHEN CODE IN ('004-200-202')
             THEN
                'Investment Management expense Cop'
             WHEN CODE IN ('004-200-201')
             THEN
                'Investment Management expense SIMS'
             WHEN CODE IN ('004-200-204')
             THEN
                'Custodial fees -Co-optrust'
             WHEN CODE IN ('004-200-203')
             THEN
                'Custodial fees -Stanlib'
             WHEN CODE IN ('004-200-207')
             THEN
                'Brokarage/Commission fees-Co-optrust'
             WHEN CODE IN ('004-200-207')
             THEN
                'Brokarage/Commission fees-Stanlib'
             --
             --
             WHEN CODE IN ('004-300-313')
             THEN
                'Staff Salaries'
             WHEN CODE IN ('004-300-311')
             THEN
                'Staff Training'
             WHEN CODE IN ('004-300-328')
             THEN
                'Staff Welfare'
             --
             --
             WHEN CODE IN ('004-300-309')
             THEN
                'Trustees allowances'
             WHEN CODE IN ('004-300-312')
             THEN
                'Trustee Training'
             --
             --
             WHEN CODE IN ('004-300-301')
             THEN
                'Office Expenses'
             WHEN CODE IN ('004-300-305')
             THEN
                'Bank charges'
             WHEN CODE IN ('004-300-314')
             THEN
                'Internal Audit fees'
             WHEN CODE IN ('004-300-315')
             THEN
                'External Audit fees'
             WHEN CODE IN ('004-300-302')
             THEN
                'Stationery'
             WHEN CODE IN ('004-300-332')
             THEN
                'Printing'
             WHEN CODE IN ('004-300-325')
             THEN
                'Legal and professional fees'
             WHEN CODE IN ('004-300-328')
             THEN
                'Acturial Services'
             WHEN CODE IN ('004-300-306')
             THEN
                'Repairs and maintenance'
             WHEN CODE IN ('004-300-303')
             THEN
                'Insurance expenses'
             WHEN CODE IN ('004-300-304')
             THEN
                'Land rates'
             WHEN CODE IN ('004-300-321')
             THEN
                'Service Charge'
             WHEN CODE IN ('004-300-317')
             THEN
                'ICT Expenses'
             WHEN CODE IN ('004-300-319')
             THEN
                'CSR Expenses'
             WHEN CODE IN ('004-300-318')
             THEN
                'Subscriptions'
             WHEN CODE IN ('004-300-307')
             THEN
                'RBA Levies'
             WHEN CODE IN ('004-300-320')
             THEN
                'ISO'
             WHEN CODE IN ('004-300-331')
             THEN
                'Corporate Events'
             --
             --
             WHEN CODE IN ('004-300-327')
             THEN
                'Amortisation'
             WHEN CODE IN ('004-300-326')
             THEN
                'Depreciation'
             WHEN CODE IN ('004-300-333')
             THEN
                'Provision for Bad Debts'
             WHEN CODE IN ('004-300-334')
             THEN
                'Other expenses'
             --
             --
             WHEN CODE IN ('002-100-101')
             THEN
                'Benefits payable'
             WHEN CODE IN ('002-100-103')
             THEN
                'Pension Payable'
             WHEN CODE IN ('002-100-102')
             THEN
                'Deathclaims payable'
             WHEN CODE IN ('002-100-106',
                           '002-100-109',
                           '002-100-111',
                           '002-100-110',
                           '002-100-112',
                           '002-100-113',
                           '002-100-114',
                           '002-100-115',
                           '002-100-117',
                           '002-100-116',
                           '002-100-118',
                           '002-100-119',
                           '002-100-120',
                           '002-100-121',
                           '002-100-122',
                           '002-100-123',
                           '002-100-124',
                           '002-100-125',
                           '002-100-126',
                           '002-100-127',
                           '002-100-128',
                           '002-100-129',
                           '002-100-130',
                           '002-100-131',
                           '002-100-132',
                           '002-100-133',
                           '002-100-136',
                           '002-100-137',
                           '002-100-138',
                           '002-100-139',
                           '002-100-140',
                           '002-100-141',
                           '002-100-142',
                           '002-100-143',
                           '002-100-145',
                           '002-100-146',
                           '002-100-147',
                           '002-100-148',
                           '002-100-149')
             THEN
                'Expense for the year Accrued'
             WHEN CODE IN ('002-100-108')
             THEN
                'Tax Payable'
             WHEN CODE IN ('002-100-107')
             THEN
                'Loresho Service Charge Payable'
             WHEN CODE IN ('002-100-104')
             THEN
                'Due to KPLC'
             WHEN CODE IN ('002-100-105')
             THEN
                'Due to DC'
             WHEN CODE IN ('005-100-101')
             THEN
                'Trust Fund'
             ELSE
                ''
          END
             tb_header,
          CASE
             WHEN CODE IN ('001-100-101',
                           '001-100-102',
                           '001-100-103',
                           '001-100-105')
             THEN
                'ASSETS'
             WHEN CODE IN ('001-100-104')
             THEN
                'ASSETS'
             --
             WHEN CODE IN ('001-200-201', '001-200-202', '001-200-203')
             THEN
                'ASSETS'
             WHEN CODE IN ('001-200-229')
             THEN
                'ASSETS'
             WHEN CODE IN ('001-200-205')
             THEN
                'ASSETS'
             WHEN CODE IN ('001-200-206')
             THEN
                'ASSETS'
             WHEN CODE IN ('001-200-233')
             THEN
                'ASSETS'
             WHEN CODE IN ('001-200-207')
             THEN
                'ASSETS'
             WHEN CODE IN ('001-200-208')
             THEN
                'ASSETS'
             WHEN CODE IN ('001-200-210')
             THEN
                'ASSETS'
             WHEN CODE IN ('001-200-209')
             THEN
                'ASSETS'
             WHEN CODE IN ('001-200-212')
             THEN
                'ASSETS'
             WHEN CODE IN ('001-200-211')
             THEN
                'ASSETS'
             WHEN CODE IN ('001-200-230')
             THEN
                'ASSETS'
             WHEN CODE IN ('001-200-232')
             THEN
                'ASSETS'
             WHEN CODE IN ('001-200-216')
             THEN
                'ASSETS'
             WHEN CODE IN ('001-200-219')
             THEN
                'ASSETS'
             WHEN CODE IN ('001-200-221')
             THEN
                'ASSETS'
             WHEN CODE IN ('001-200-220')
             THEN
                'ASSETS'
             WHEN CODE IN ('001-200-214')
             THEN
                'ASSETS'
             WHEN CODE IN ('001-200-213')
             THEN
                'ASSETS'
             WHEN CODE IN ('001-200-223')
             THEN
                'ASSETS'
             WHEN CODE IN ('001-200-222')
             THEN
                'ASSETS'
             --
             --
             WHEN CODE IN ('001-300-301')
             THEN
                'INCOMES'
             WHEN CODE IN ('001-200-215')
             THEN
                'INCOMES'
             WHEN CODE IN ('001-300-302')
             THEN
                'INCOMES'
             WHEN CODE IN ('001-300-303')
             THEN
                'INCOMES'
             WHEN CODE IN ('001-300-304')
             THEN
                'INCOMES'
             --
             --
             WHEN CODE IN ('001-300-306')
             THEN
                'INCOMES'
             WHEN CODE IN ('001-300-305')
             THEN
                'INCOMES'
             WHEN CODE IN ('001-300-310')
             THEN
                'INCOMES'
             WHEN CODE IN ('001-300-311')
             THEN
                'INCOMES'
             WHEN CODE IN ('001-300-309')
             THEN
                'INCOMES'
             WHEN CODE IN ('001-300-312')
             THEN
                'INCOMES'
             --
             --
             WHEN CODE IN ('003-200-201')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-202')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-203')
             THEN
                'INCOMES'
             --
             WHEN CODE IN ('003-200-246')
             THEN
                'INCOMES'
             --
             WHEN CODE IN ('003-200-205')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-204')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-207')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-206')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-209')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-208')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-209')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-208')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-248')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-247')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-213')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-212')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-211')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-210')
             THEN
                'INCOMES'
             --
             --
             WHEN CODE IN ('003-200-215')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-214')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-217')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-216')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-219')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-218')
             THEN
                'INCOMES'
             --
             --
             WHEN CODE IN ('003-200-220')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-221')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-223')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-222')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-225')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-224')
             THEN
                'INCOMES'
             --
             --
             WHEN CODE IN ('003-200-249')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-250')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-251')
             THEN
                'INCOMES'
             --
             --
             WHEN CODE IN ('003-200-234')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-233')
             THEN
                'INCOMES'
             --
             --
             WHEN CODE IN ('003-200-231')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-230')
             THEN
                'INCOMES'
             --
             --
             WHEN CODE IN ('003-200-237')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-236')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-238', '003-200-239')
             THEN
                'INCOMES'
             --
             --
             WHEN CODE IN ('003-200-240')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-240')
             THEN
                'INCOMES'
             WHEN CODE IN ('003-200-240')
             THEN
                'INCOMES'
             --
             --
             WHEN CODE IN ('004-100-102')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-100-101')
             THEN
                'EXPENSES'
             --
             --
             WHEN CODE IN ('004-200-202')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-200-201')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-200-204')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-200-203')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-200-207')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-200-207')
             THEN
                'EXPENSES'
             --
             --
             WHEN CODE IN ('004-300-313')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-300-311')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-300-328')
             THEN
                'EXPENSES'
             --
             --
             WHEN CODE IN ('004-300-309')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-300-312')
             THEN
                'EXPENSES'
             --
             --
             WHEN CODE IN ('004-300-301')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-300-305')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-300-314')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-300-315')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-300-302')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-300-332')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-300-325')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-300-328')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-300-306')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-300-303')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-300-304')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-300-321')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-300-317')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-300-319')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-300-318')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-300-307')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-300-320')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-300-331')
             THEN
                'EXPENSES'
             --
             --
             WHEN CODE IN ('004-300-327')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-300-326')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-300-333')
             THEN
                'EXPENSES'
             WHEN CODE IN ('004-300-334')
             THEN
                'EXPENSES'
             --
             --
             WHEN CODE IN ('002-100-101')
             THEN
                'LIABILITIES'
             WHEN CODE IN ('002-100-103')
             THEN
                'LIABILITIES'
             WHEN CODE IN ('002-100-102')
             THEN
                'LIABILITIES'
             WHEN CODE IN ('002-100-106',
                           '002-100-109',
                           '002-100-111',
                           '002-100-110',
                           '002-100-112',
                           '002-100-113',
                           '002-100-114',
                           '002-100-115',
                           '002-100-117',
                           '002-100-116',
                           '002-100-118',
                           '002-100-119',
                           '002-100-120',
                           '002-100-121',
                           '002-100-122',
                           '002-100-123',
                           '002-100-124',
                           '002-100-125',
                           '002-100-126',
                           '002-100-127',
                           '002-100-128',
                           '002-100-129',
                           '002-100-130',
                           '002-100-131',
                           '002-100-132',
                           '002-100-133',
                           '002-100-136',
                           '002-100-137',
                           '002-100-138',
                           '002-100-139',
                           '002-100-140',
                           '002-100-141',
                           '002-100-142',
                           '002-100-143',
                           '002-100-145',
                           '002-100-146',
                           '002-100-147',
                           '002-100-148',
                           '002-100-149')
             THEN
                'LIABILITIES'
             WHEN CODE IN ('002-100-108')
             THEN
                'LIABILITIES'
             WHEN CODE IN ('002-100-107')
             THEN
                'LIABILITIES'
             WHEN CODE IN ('002-100-104')
             THEN
                'LIABILITIES'
             WHEN CODE IN ('002-100-105')
             THEN
                'LIABILITIES'
             WHEN CODE IN ('005-100-101')
             THEN
                'LIABILITIES'
             ELSE
                ''
          END
             tb_category,
          CASE
             WHEN CODE IN ('001-100-101',
                           '001-100-102',
                           '001-100-103',
                           '001-100-105')
             THEN
                'Non-Current Asset'
             WHEN CODE IN ('001-100-104')
             THEN
                'Non-Current Asset'
             --
             WHEN CODE IN ('001-200-201', '001-200-202', '001-200-203')
             THEN
                'Investment Assets'
             WHEN CODE IN ('001-200-229')
             THEN
                'Investment Assets'
             WHEN CODE IN ('001-200-205')
             THEN
                'Investment Assets'
             WHEN CODE IN ('001-200-206')
             THEN
                'Investment Assets'
             WHEN CODE IN ('001-200-233')
             THEN
                'Investment Assets'
             WHEN CODE IN ('001-200-207')
             THEN
                'Investment Assets'
             WHEN CODE IN ('001-200-208')
             THEN
                'Investment Assets'
             WHEN CODE IN ('001-200-210')
             THEN
                'Investment Assets'
             WHEN CODE IN ('001-200-209')
             THEN
                'Investment Assets'
             WHEN CODE IN ('001-200-212')
             THEN
                'Investment Assets'
             WHEN CODE IN ('001-200-211')
             THEN
                'Investment Assets'
             WHEN CODE IN ('001-200-230')
             THEN
                'Investment Assets'
             WHEN CODE IN ('001-200-232')
             THEN
                'Investment Assets'
             WHEN CODE IN ('001-200-216')
             THEN
                'Investment Assets'
             WHEN CODE IN ('001-200-219')
             THEN
                'Investment Assets'
             WHEN CODE IN ('001-200-221')
             THEN
                'Investment Assets'
             WHEN CODE IN ('001-200-220')
             THEN
                'Investment Assets'
             WHEN CODE IN ('001-200-214')
             THEN
                'Investment Assets'
             WHEN CODE IN ('001-200-213')
             THEN
                'Investment Assets'
             WHEN CODE IN ('001-200-223')
             THEN
                'Investment Assets'
             WHEN CODE IN ('001-200-222')
             THEN
                'Investment Assets'
             --
             --
             WHEN CODE IN ('001-300-301')
             THEN
                'Bank and cash balances'
             WHEN CODE IN ('001-200-215')
             THEN
                'Bank and cash balances'
             WHEN CODE IN ('001-300-302')
             THEN
                'Bank and cash balances'
             WHEN CODE IN ('001-300-303')
             THEN
                'Bank and cash balances'
             WHEN CODE IN ('001-300-304')
             THEN
                'Bank and cash balances'
             --
             --
             WHEN CODE IN ('001-300-306')
             THEN
                'Other Assets'
             WHEN CODE IN ('001-300-305')
             THEN
                'Other Assets'
             WHEN CODE IN ('001-300-310')
             THEN
                'Other Assets'
             WHEN CODE IN ('001-300-311')
             THEN
                'Other Assets'
             WHEN CODE IN ('001-300-309')
             THEN
                'Other Assets'
             WHEN CODE IN ('001-300-312')
             THEN
                'Other Assets'
             --
             --
             WHEN CODE IN ('003-200-201')
             THEN
                'Investment properties'
             WHEN CODE IN ('003-200-202')
             THEN
                'Investment properties'
             WHEN CODE IN ('003-200-203')
             THEN
                'Investment properties'
             --
             WHEN CODE IN ('003-200-246')
             THEN
                'Contributions'
             --
             WHEN CODE IN ('003-200-205')
             THEN
                'Government Bonds'
             WHEN CODE IN ('003-200-204')
             THEN
                'Government Bonds'
             WHEN CODE IN ('003-200-207')
             THEN
                'Government Bonds'
             WHEN CODE IN ('003-200-206')
             THEN
                'Government Bonds'
             WHEN CODE IN ('003-200-209')
             THEN
                'Government Bonds'
             WHEN CODE IN ('003-200-208')
             THEN
                'Government Bonds'
             WHEN CODE IN ('003-200-209')
             THEN
                'Government Bonds'
             WHEN CODE IN ('003-200-208')
             THEN
                'Government Bonds'
             WHEN CODE IN ('003-200-248')
             THEN
                'Government Bonds'
             WHEN CODE IN ('003-200-247')
             THEN
                'Government Bonds'
             WHEN CODE IN ('003-200-213')
             THEN
                'Government Bonds'
             WHEN CODE IN ('003-200-212')
             THEN
                'Government Bonds'
             WHEN CODE IN ('003-200-211')
             THEN
                'Government Bonds'
             WHEN CODE IN ('003-200-210')
             THEN
                'Government Bonds'
             --
             --
             WHEN CODE IN ('003-200-215')
             THEN
                'Corporate Bonds'
             WHEN CODE IN ('003-200-214')
             THEN
                'Corporate Bonds'
             WHEN CODE IN ('003-200-217')
             THEN
                'Corporate Bonds'
             WHEN CODE IN ('003-200-216')
             THEN
                'Corporate Bonds'
             WHEN CODE IN ('003-200-219')
             THEN
                'Corporate Bonds'
             WHEN CODE IN ('003-200-218')
             THEN
                'Corporate Bonds'
             --
             --
             WHEN CODE IN ('003-200-220')
             THEN
                'Quoted Equities'
             WHEN CODE IN ('003-200-221')
             THEN
                'Quoted Equities'
             WHEN CODE IN ('003-200-223')
             THEN
                'Quoted Equities'
             WHEN CODE IN ('003-200-222')
             THEN
                'Quoted Equities'
             WHEN CODE IN ('003-200-225')
             THEN
                'Quoted Equities'
             WHEN CODE IN ('003-200-224')
             THEN
                'Quoted Equities'
             --
             --
             WHEN CODE IN ('003-200-249')
             THEN
                'Private Equity'
             WHEN CODE IN ('003-200-250')
             THEN
                'Private Equity'
             WHEN CODE IN ('003-200-251')
             THEN
                'Private Equity'
             --
             --
             WHEN CODE IN ('003-200-234')
             THEN
                'Commercial Paper'
             WHEN CODE IN ('003-200-233')
             THEN
                'Commercial Paper'
             --
             --
             WHEN CODE IN ('003-200-231')
             THEN
                'Term Depositis'
             WHEN CODE IN ('003-200-230')
             THEN
                'Term Depositis'
             --
             --
             WHEN CODE IN ('003-200-237')
             THEN
                'Offshore'
             WHEN CODE IN ('003-200-236')
             THEN
                'Offshore'
             WHEN CODE IN ('003-200-238', '003-200-239')
             THEN
                'Offshore'
             --
             --
             WHEN CODE IN ('003-200-240')
             THEN
                'Other Income'
             WHEN CODE IN ('003-200-240')
             THEN
                'Other Income'
             WHEN CODE IN ('003-200-240')
             THEN
                'Other Income'
             --
             --
             WHEN CODE IN ('004-100-102')
             THEN
                'Member Expenses'
             WHEN CODE IN ('004-100-101')
             THEN
                'Member Expenses'
             --
             --
             WHEN CODE IN ('004-200-202')
             THEN
                'Investment Management fees'
             WHEN CODE IN ('004-200-201')
             THEN
                'Investment Management fees'
             WHEN CODE IN ('004-200-204')
             THEN
                'Investment Management fees'
             WHEN CODE IN ('004-200-203')
             THEN
                'Investment Management fees'
             WHEN CODE IN ('004-200-207')
             THEN
                'Investment Management fees'
             WHEN CODE IN ('004-200-207')
             THEN
                'Investment Management fees'
             --
             --
             WHEN CODE IN ('004-300-313')
             THEN
                'Staff Expenses'
             WHEN CODE IN ('004-300-311')
             THEN
                'Staff Expenses'
             WHEN CODE IN ('004-300-328')
             THEN
                'Staff Expenses'
             --
             --
             WHEN CODE IN ('004-300-309')
             THEN
                'Trustee Expenses'
             WHEN CODE IN ('004-300-312')
             THEN
                'Trustee Expenses'
             --
             --
             WHEN CODE IN ('004-300-301')
             THEN
                'Administration Expenses'
             WHEN CODE IN ('004-300-305')
             THEN
                'Administration Expenses'
             WHEN CODE IN ('004-300-314')
             THEN
                'Administration Expenses'
             WHEN CODE IN ('004-300-315')
             THEN
                'Administration Expenses'
             WHEN CODE IN ('004-300-302')
             THEN
                'Administration Expenses'
             WHEN CODE IN ('004-300-332')
             THEN
                'Administration Expenses'
             WHEN CODE IN ('004-300-325')
             THEN
                'Administration Expenses'
             WHEN CODE IN ('004-300-328')
             THEN
                'Administration Expenses'
             WHEN CODE IN ('004-300-306')
             THEN
                'Administration Expenses'
             WHEN CODE IN ('004-300-303')
             THEN
                'Administration Expenses'
             WHEN CODE IN ('004-300-304')
             THEN
                'Administration Expenses'
             WHEN CODE IN ('004-300-321')
             THEN
                'Administration Expenses'
             WHEN CODE IN ('004-300-317')
             THEN
                'Administration Expenses'
             WHEN CODE IN ('004-300-319')
             THEN
                'Administration Expenses'
             WHEN CODE IN ('004-300-318')
             THEN
                'Administration Expenses'
             WHEN CODE IN ('004-300-307')
             THEN
                'Administration Expenses'
             WHEN CODE IN ('004-300-320')
             THEN
                'Administration Expenses'
             WHEN CODE IN ('004-300-331')
             THEN
                'Administration Expenses'
             --
             --
             WHEN CODE IN ('004-300-327')
             THEN
                'Other Expenses'
             WHEN CODE IN ('004-300-326')
             THEN
                'Other Expenses'
             WHEN CODE IN ('004-300-333')
             THEN
                'Other Expenses'
             WHEN CODE IN ('004-300-334')
             THEN
                'Other expenses'
             --
             --
             WHEN CODE IN ('002-100-101')
             THEN
                'Liabilities'
             WHEN CODE IN ('002-100-103')
             THEN
                'Liabilities'
             WHEN CODE IN ('002-100-102')
             THEN
                'Liabilities'
             WHEN CODE IN ('002-100-106',
                           '002-100-109',
                           '002-100-111',
                           '002-100-110',
                           '002-100-112',
                           '002-100-113',
                           '002-100-114',
                           '002-100-115',
                           '002-100-117',
                           '002-100-116',
                           '002-100-118',
                           '002-100-119',
                           '002-100-120',
                           '002-100-121',
                           '002-100-122',
                           '002-100-123',
                           '002-100-124',
                           '002-100-125',
                           '002-100-126',
                           '002-100-127',
                           '002-100-128',
                           '002-100-129',
                           '002-100-130',
                           '002-100-131',
                           '002-100-132',
                           '002-100-133',
                           '002-100-136',
                           '002-100-137',
                           '002-100-138',
                           '002-100-139',
                           '002-100-140',
                           '002-100-141',
                           '002-100-142',
                           '002-100-143',
                           '002-100-145',
                           '002-100-146',
                           '002-100-147',
                           '002-100-148',
                           '002-100-149')
             THEN
                'Liabilities'
             WHEN CODE IN ('002-100-108')
             THEN
                'Liabilities'
             WHEN CODE IN ('002-100-107')
             THEN
                'Liabilities'
             WHEN CODE IN ('002-100-104')
             THEN
                'Liabilities'
             WHEN CODE IN ('002-100-105')
             THEN
                'Liabilities'
             WHEN CODE IN ('005-100-101')
             THEN
                'Liabilities'
             ELSE
                ''
          END
             tb_sub_category,
          CASE
             WHEN CODE IN ('001-100-101',
                           '001-100-102',
                           '001-100-103',
                           '001-100-105')
             THEN
                '1'
             WHEN CODE IN ('001-100-104')
             THEN
                '2'
             --
             WHEN CODE IN ('001-200-201', '001-200-202', '001-200-203')
             THEN
                '3'
             WHEN CODE IN ('001-200-229')
             THEN
                '4'
             WHEN CODE IN ('001-200-205')
             THEN
                '5'
             WHEN CODE IN ('001-200-206')
             THEN
                '6'
             WHEN CODE IN ('001-200-233')
             THEN
                '7'
             WHEN CODE IN ('001-200-207')
             THEN
                '8'
             WHEN CODE IN ('001-200-208')
             THEN
                '9'
             WHEN CODE IN ('001-200-210')
             THEN
                '10'
             WHEN CODE IN ('001-200-209')
             THEN
                '11'
             WHEN CODE IN ('001-200-212')
             THEN
                '12'
             WHEN CODE IN ('001-200-211')
             THEN
                '13'
             WHEN CODE IN ('001-200-230')
             THEN
                '14'
             WHEN CODE IN ('001-200-232')
             THEN
                '15'
             WHEN CODE IN ('001-200-216')
             THEN
                '16'
             WHEN CODE IN ('001-200-219')
             THEN
                '17'
             WHEN CODE IN ('001-200-221')
             THEN
                '18'
             WHEN CODE IN ('001-200-220')
             THEN
                '19'
             WHEN CODE IN ('001-200-214')
             THEN
                '20'
             WHEN CODE IN ('001-200-213')
             THEN
                '21'
             WHEN CODE IN ('001-200-223')
             THEN
                '22'
             WHEN CODE IN ('001-200-222')
             THEN
                '23'
             --
             --
             WHEN CODE IN ('001-300-301')
             THEN
                '24'
             WHEN CODE IN ('001-200-215')
             THEN
                '25'
             WHEN CODE IN ('001-300-302')
             THEN
                '26'
             WHEN CODE IN ('001-300-303')
             THEN
                '27'
             WHEN CODE IN ('001-300-304')
             THEN
                '28'
             --
             --
             WHEN CODE IN ('001-300-306')
             THEN
                '29'
             WHEN CODE IN ('001-300-305')
             THEN
                '30'
             WHEN CODE IN ('001-300-310')
             THEN
                '31'
             WHEN CODE IN ('001-300-311')
             THEN
                '32'
             WHEN CODE IN ('001-300-309')
             THEN
                '33'
             WHEN CODE IN ('001-300-312')
             THEN
                '34'
             --
             --
             WHEN CODE IN ('003-200-201')
             THEN
                '35'
             WHEN CODE IN ('003-200-202')
             THEN
                '36'
             WHEN CODE IN ('003-200-203')
             THEN
                '37'
             --
             WHEN CODE IN ('003-200-246')
             THEN
                '38'
             --
             WHEN CODE IN ('003-200-205')
             THEN
                '39'
             WHEN CODE IN ('003-200-204')
             THEN
                '40'
             WHEN CODE IN ('003-200-207')
             THEN
                '41'
             WHEN CODE IN ('003-200-206')
             THEN
                '42'
             WHEN CODE IN ('003-200-209')
             THEN
                '43'
             WHEN CODE IN ('003-200-208')
             THEN
                '44'
             WHEN CODE IN ('003-200-209')
             THEN
                '45'
             WHEN CODE IN ('003-200-208')
             THEN
                '46'
             WHEN CODE IN ('003-200-248')
             THEN
                '47'
             WHEN CODE IN ('003-200-247')
             THEN
                '48'
             WHEN CODE IN ('003-200-213')
             THEN
                '49'
             WHEN CODE IN ('003-200-212')
             THEN
                '50'
             WHEN CODE IN ('003-200-211')
             THEN
                '51'
             WHEN CODE IN ('003-200-210')
             THEN
                '52'
             --
             --
             WHEN CODE IN ('003-200-215')
             THEN
                '53'
             WHEN CODE IN ('003-200-214')
             THEN
                '54'
             WHEN CODE IN ('003-200-217')
             THEN
                '55'
             WHEN CODE IN ('003-200-216')
             THEN
                '56'
             WHEN CODE IN ('003-200-219')
             THEN
                '57'
             WHEN CODE IN ('003-200-218')
             THEN
                '58'
             --
             --
             WHEN CODE IN ('003-200-220')
             THEN
                '59'
             WHEN CODE IN ('003-200-221')
             THEN
                '60'
             WHEN CODE IN ('003-200-223')
             THEN
                '61'
             WHEN CODE IN ('003-200-222')
             THEN
                '62'
             WHEN CODE IN ('003-200-225')
             THEN
                '63'
             WHEN CODE IN ('003-200-224')
             THEN
                '64'
             --
             --
             WHEN CODE IN ('003-200-249')
             THEN
                '65'
             WHEN CODE IN ('003-200-250')
             THEN
                '66'
             WHEN CODE IN ('003-200-251')
             THEN
                '67'
             --
             --
             WHEN CODE IN ('003-200-234')
             THEN
                '68'
             WHEN CODE IN ('003-200-233')
             THEN
                '69'
             --
             --
             WHEN CODE IN ('003-200-231')
             THEN
                '70'
             WHEN CODE IN ('003-200-230')
             THEN
                '71'
             --
             --
             WHEN CODE IN ('003-200-237')
             THEN
                '72'
             WHEN CODE IN ('003-200-236')
             THEN
                '73'
             WHEN CODE IN ('003-200-238', '003-200-239')
             THEN
                '74'
             --
             --
             WHEN CODE IN ('003-200-240')
             THEN
                '75'
             WHEN CODE IN ('003-200-240')
             THEN
                '76'
             WHEN CODE IN ('003-200-240')
             THEN
                '77'
             --
             --
             WHEN CODE IN ('004-100-102')
             THEN
                '78'
             WHEN CODE IN ('004-100-101')
             THEN
                '79'
             --
             --
             WHEN CODE IN ('004-200-202')
             THEN
                '80'
             WHEN CODE IN ('004-200-201')
             THEN
                '81'
             WHEN CODE IN ('004-200-204')
             THEN
                '82'
             WHEN CODE IN ('004-200-203')
             THEN
                '83'
             WHEN CODE IN ('004-200-207')
             THEN
                '84'
             WHEN CODE IN ('004-200-207')
             THEN
                '85'
             --
             --
             WHEN CODE IN ('004-300-313')
             THEN
                '86'
             WHEN CODE IN ('004-300-311')
             THEN
                '87'
             WHEN CODE IN ('004-300-328')
             THEN
                '88'
             --
             --
             WHEN CODE IN ('004-300-309')
             THEN
                '89'
             WHEN CODE IN ('004-300-312')
             THEN
                '90'
             --
             --
             WHEN CODE IN ('004-300-301')
             THEN
                '91'
             WHEN CODE IN ('004-300-305')
             THEN
                '92'
             WHEN CODE IN ('004-300-314')
             THEN
                '93'
             WHEN CODE IN ('004-300-315')
             THEN
                '94'
             WHEN CODE IN ('004-300-302')
             THEN
                '95'
             WHEN CODE IN ('004-300-332')
             THEN
                '96'
             WHEN CODE IN ('004-300-325')
             THEN
                '97'
             WHEN CODE IN ('004-300-328')
             THEN
                '98'
             WHEN CODE IN ('004-300-306')
             THEN
                '99'
             WHEN CODE IN ('004-300-303')
             THEN
                '100'
             WHEN CODE IN ('004-300-304')
             THEN
                '101'
             WHEN CODE IN ('004-300-321')
             THEN
                '102'
             WHEN CODE IN ('004-300-317')
             THEN
                '103'
             WHEN CODE IN ('004-300-319')
             THEN
                '104'
             WHEN CODE IN ('004-300-318')
             THEN
                '105'
             WHEN CODE IN ('004-300-307')
             THEN
                '106'
             WHEN CODE IN ('004-300-320')
             THEN
                '107'
             WHEN CODE IN ('004-300-331')
             THEN
                '108'
             --
             --
             WHEN CODE IN ('004-300-327')
             THEN
                '109'
             WHEN CODE IN ('004-300-326')
             THEN
                '110'
             WHEN CODE IN ('004-300-333')
             THEN
                '111'
             WHEN CODE IN ('004-300-334')
             THEN
                '112'
             --
             --
             WHEN CODE IN ('002-100-101')
             THEN
                '113'
             WHEN CODE IN ('002-100-103')
             THEN
                '114'
             WHEN CODE IN ('002-100-102')
             THEN
                '115'
             WHEN CODE IN ('002-100-106',
                           '002-100-109',
                           '002-100-111',
                           '002-100-110',
                           '002-100-112',
                           '002-100-113',
                           '002-100-114',
                           '002-100-115',
                           '002-100-117',
                           '002-100-116',
                           '002-100-118',
                           '002-100-119',
                           '002-100-120',
                           '002-100-121',
                           '002-100-122',
                           '002-100-123',
                           '002-100-124',
                           '002-100-125',
                           '002-100-126',
                           '002-100-127',
                           '002-100-128',
                           '002-100-129',
                           '002-100-130',
                           '002-100-131',
                           '002-100-132',
                           '002-100-133',
                           '002-100-136',
                           '002-100-137',
                           '002-100-138',
                           '002-100-139',
                           '002-100-140',
                           '002-100-141',
                           '002-100-142',
                           '002-100-143',
                           '002-100-145',
                           '002-100-146',
                           '002-100-147',
                           '002-100-148',
                           '002-100-149')
             THEN
                '116'
             WHEN CODE IN ('002-100-108')
             THEN
                '117'
             WHEN CODE IN ('002-100-107')
             THEN
                '118'
             WHEN CODE IN ('002-100-104')
             THEN
                '119'
             WHEN CODE IN ('002-100-105')
             THEN
                '120'
             WHEN CODE IN ('005-100-101')
             THEN
                '121'
             ELSE
                ''
          END
             tb_order
     FROM accounts ac
	LEFT JOIN fin_reporting_header_dets fhd ON ac.FRHD_ID = fhd.id
	LEFT JOIN FINANCIAL_REPORTING_HEADERS fh ON fhd.header_id = fh.id
	LEFT JOIN INCOME_STMT_GROUPS isg ON fhd.STATEMENTGROUP_ID = isg.ID
/

