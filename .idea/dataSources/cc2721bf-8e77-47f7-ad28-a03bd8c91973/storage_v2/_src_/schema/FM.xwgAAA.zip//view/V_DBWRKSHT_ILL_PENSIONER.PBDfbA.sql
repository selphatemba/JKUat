create view V_DBWRKSHT_ILL_PENSIONER as
  select p.*
  from pensioners p where member_id = (select MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS)
/

