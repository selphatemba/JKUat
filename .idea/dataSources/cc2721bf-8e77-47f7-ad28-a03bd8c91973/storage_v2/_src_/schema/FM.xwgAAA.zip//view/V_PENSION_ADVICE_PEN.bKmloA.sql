create view V_PENSION_ADVICE_PEN as
  select p.SCHEME_ID, ID,
    (select (select to_char(pa.MONTH||'/'||pa.YEAR) from V_PENSION_ADVICE pa where DATED=(select min(pa.DATED) from V_PENSION_ADVICE pa))||' to '||(select to_char(pa.MONTH||'/'||pa.YEAR) from V_PENSION_ADVICE pa where DATED=(select max(pa.DATED) from V_PENSION_ADVICE pa)) from dual) period,
    p.account_no pensioner_account,
    (case when p.beneficiary_id is null then (select DECODE(m.TITLE,'MR','Mr.', 'MRS', 'Mrs.', 'DR', 'Dr.', 'PROF', 'Prof.', 'REV', 'Rev.', 'ENG', 'Eng.', 'MISS', 'Ms.', '')||' '||M.FIRSTNAME||' '||M.OTHER_NAMES||' '||M.SURNAME from members m where m.id = p.member_id)
     when p.member_id is null then (select firstname||' '||othernames from beneficiaries where id = p.beneficiary_id)
     else ''
     end
    )pensioner_name ,p.ACCOUNT_NAME,
    (case
     when p.beneficiary_id is null then (select TOWN from members m where m.id=p.member_id)
     when p.member_id is null then (select '' from beneficiaries where id = p.beneficiary_id)
     else ''
     end
    )TOWN,
    (case
     when p.beneficiary_id is null then (select POSTAL_ADDRESS from members m where m.id=p.member_id)
     when p.member_id is null then (select '' from beneficiaries where id = p.beneficiary_id)
     else ''
     end
    )POSTAL_ADDRESS,
    p.PENSION_FREQ, p.PENSION_STATUS, p.PENSIONER_TYPE,
    p.ACCOUNT_NO,
    PENSION_START_DATE,
    (case
     when p.beneficiary_id is null then (select ID_NO from members m where m.id=p.member_id)
     when p.member_id is null then (select '' from beneficiaries where id = p.beneficiary_id)
     else ''
     end
    )ID_NO,
    (case
     when p.beneficiary_id is null then (select pin from members m where m.id=p.member_id)
     when p.member_id is null then (select '' from beneficiaries where id = p.beneficiary_id)
     else ''
     end
    ) pin,
    (select distinct name from bank_branches where id = p.branch_id and rownum=1) branch_name,
    (select name from banks where id = (select distinct bank_id from bank_branches where id = p.branch_id and rownum=1)) bank_name
    ,pension_no
  from pensioners p where id = (select pensioner_id from V_GENERAL_REPORTS_PARAMS grp)
/

