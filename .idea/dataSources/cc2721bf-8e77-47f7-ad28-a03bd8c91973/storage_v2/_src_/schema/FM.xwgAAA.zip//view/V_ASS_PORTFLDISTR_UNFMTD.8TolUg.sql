create view V_ASS_PORTFLDISTR_UNFMTD as
  with cache as(
      SELECT decode(inv.INVESTMENT_CATEGORY ,'GOVERNMENT_SECURITIES', 'GOVERNMENT SECURITIES' ,
                    'CORPORATE_BONDS' , 'CORPORATE BONDS', 'PROPERTY' , 'PROPERTY', 'EQUITY',
                    'EQUITY', 'FIXED_TERM_DEPOSIT','FIXED TERM DEPOSITS', 'COLLECTIVE_INVESTMENTS',
                    'COLLECTIVE INVESTMENTS', 'CASH_CALL_DEPOSITS','CASH AND CALL DEPOSITS',
                    'LOAN_TO_GOVERNMENT','LOAN TO GOVERNMENT', 'LOAN_TO_CORPORATE', 'LOAN TO CORPORATES',
                    inv.INVESTMENT_CATEGORY) INVESTMENT_CATEGORY,INV.FUNDMANAGER_ID, ex.rate, curr.name,inv.SCHEME_ID,
             sum((case when inv.INVESTMENT_CATEGORY = 'CORPORATE_BONDS' then  coalesce(txn.AMOUNT, 0)
                  when inv.INVESTMENT_CATEGORY = 'FIXED_TERM_DEPOSIT' then coalesce(inv.INITIAL_VALUE, 0)
                  when inv.INVESTMENT_CATEGORY = 'LOAN_TO_GOVERNMENT' then coalesce(inv.INITIAL_VALUE, 0)
                  when inv.INVESTMENT_CATEGORY = 'LOAN_TO_CORPORATE' then coalesce(inv.INITIAL_VALUE, 0)
                  when inv.INVESTMENT_CATEGORY = 'LOAN_TO_CORPORATIVE' then coalesce(inv.INITIAL_VALUE, 0)
                  when inv.INVESTMENT_CATEGORY = 'CASH_CALL_DEPOSITS' then coalesce(txn.AMOUNT, 0)
                  when inv.INVESTMENT_CATEGORY = 'PROPERTY' then coalesce(inv.INITIAL_VALUE, 0)
                  when inv.INVESTMENT_CATEGORY = 'GOVERNMENT_SECURITIES' then coalesce(txn.AMOUNT, 0)
                  when inv.INVESTMENT_CATEGORY = 'COLLECTIVE_INVESTMENTS' and txn.equit_type = 'CIS' then coalesce(txn.AMOUNT, 0)
                  when inv.INVESTMENT_CATEGORY = 'EQUITY' and txn.transaction_type = 'EQUITY_ACQUISITION' then coalesce(txn.AMOUNT, 0)
                  when inv.INVESTMENT_CATEGORY = 'OFFSHORE' and inv.INVESTMENT_TYPE = 'SECURITY_BOND' then coalesce(txn.AMOUNT, 0)
                  when inv.INVESTMENT_CATEGORY = 'OFFSHORE' and inv.INVESTMENT_TYPE = 'FIXED_TERM_DEPOSIT' then coalesce(inv.INITIAL_VALUE, 0)
                  when inv.INVESTMENT_CATEGORY = 'OFFSHORE' and inv.INVESTMENT_TYPE = 'LOAN' then coalesce(inv.INITIAL_VALUE, 0)
                  when inv.INVESTMENT_CATEGORY = 'OFFSHORE' and inv.INVESTMENT_TYPE = 'CASH_AND_CALL_DEPOSIT' then coalesce(inv.INITIAL_VALUE, 0)
                  when inv.INVESTMENT_CATEGORY = 'OFFSHORE' and inv.INVESTMENT_TYPE = 'PROPERTY' then coalesce(inv.INITIAL_VALUE, 0)
                  when inv.INVESTMENT_CATEGORY = 'OFFSHORE' and inv.INVESTMENT_TYPE = 'EQUITY' and txn.transaction_type = 'EQUITY_ACQUISITION' then coalesce(txn.AMOUNT, 0)
                  else 0 end)+(SELECT sum(coalesce(xnz.amount, 0)*(coalesce((SELECT e.RATE from EXCHANGE_RATES e WHERE e.TARGET_ID = (SELECT i.currency_id from investments i where id = xnz.investment_id) AND e.RATE_DATE = (SELECT max(ex.RATE_DATE) from EXCHANGE_RATES ex WHERE ex.TARGET_ID = (SELECT i.currency_id from investments i where id = xnz.investment_id))),1))) from INVESTMENT_TXNS xnz where xnz.INVESTMENT_ID = inv.id
                                                                                                                                                                                                                                                                                                                                                                                                                 and xnz.PARTICULARS NOT LIKE '%Acquisition%' and xnz.PARTICULARS NOT LIKE '%Redemption%'
                                                                                                                                                                                                                                                                                                                                                                                                                 and xnz.PARTICULARS NOT LIKE '%Sale for%' and xnz.PARTICULARS NOT LIKE '%Installment%' and xnz.TRANS_DATE <= (select grp.DATE_TO from V_GENERAL_REPORTS_PARAMS grp)
                                                                                                                                                                                                                                                                                                                                                                                                                 and xnz.transaction_type not in ('CSH_CLL_DEP_ACQN','EQUITY_ACQUISITION', 'CSH_CLL_DEP_TRANS','RENT_RECEIPT_TXN') )) as holding,
             (SELECT max(t.TARGET) from TACTICAL_SETTINGS t where t.CATEGORY = inv.INVESTMENT_CATEGORY) as target
      from INVESTMENTS inv
        left join investment_txns txn on inv.id = txn.INVESTMENT_ID
        left join CURRENCIES curr on inv.CURRENCY_ID = curr.id
        left join EXCHANGE_RATES ex on inv.CURRENCY_ID = ex.TARGET_ID
      where /*inv.fundmanager_id= NVL((select grp.fund_manager_id from V_GENERAL_REPORTS_PARAMS grp),inv.fundmanager_id)
          AND */inv.DEAL_DATE BETWEEN (select grp.DATE_FROM from V_GENERAL_REPORTS_PARAMS grp) AND (select grp.DATE_TO from V_GENERAL_REPORTS_PARAMS grp)
                AND inv.SCHEME_ID = (select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp)
      GROUP BY inv.INVESTMENT_CATEGORY,inv.FUNDMANAGER_ID, ex.RATE, curr.name, inv.SCHEME_ID
  ) select INVESTMENT_CATEGORY, rate, NAME,FUNDMANAGER_ID,SCHEME_ID,
      case when  name  is NULL THEN (select c.name from CURRENCIES c, Schemes s where  c.id =s.BASECURRENCY_ID and s.id=(select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) )
      ELSE
        name
      END currencyName,
      (select sum(holding) from cache) grand,
      sum(holding)  holding,
      sum(holding)/(select sum(holding) from cache) * 100 actual,
      target,
      target - (sum(holding)/(select sum(holding) from cache) * 100)  variance,
      (case when sum(holding) = 0
        then 0
       else
         coalesce((holding*target)/(sum(holding)/(select sum(holding) from cache) * 100), 0)
       end) target_amount,
      (case when sum(holding) = 0
        then 0
       else
         coalesce((holding*(target - (sum(holding)/(select sum(holding) from cache) * 100)))/(sum(holding)/(select sum(holding) from cache) * 100), 0)
       end) variance_amount
    from cache group by INVESTMENT_CATEGORY, target,holding, rate, NAME, FUNDMANAGER_ID, SCHEME_ID
/

