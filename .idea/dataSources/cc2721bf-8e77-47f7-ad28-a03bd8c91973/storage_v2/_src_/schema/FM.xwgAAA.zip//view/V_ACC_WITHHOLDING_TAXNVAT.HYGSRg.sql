create view V_ACC_WITHHOLDING_TAXNVAT as
  SELECT
    ln.ID,
    p.SCHEME_ID,
    case when tps.CATEGORY='WITH_HOLDING' then 'Withholding Tax' else 'Withholding VAT' end category,
    p.PMT_DATE,
    case when cd.TAX_PIN is NULL then '-' else cd.TAX_PIN END pin,
    cd.NAME,
    ln.PARTICULARS,
    ln.INVOICENO,
    ln.INVOICE_DATE,
    ln.AMT_BOOKED_GROSS,
    ln.AMT_VAT,
    ln.AMT_LESS_VAT,
    ln.AMT_WITHHOLDING_VAT,
    ln.AMT_LESS_WHVAT,
    ln.AMT_WITHHOLDING_TAX,
    ln.AMT_LESS_WHTAX,
    ln.AMT_TOTAL_WITHHELD,
    ln.AMT_LESS_TOTAL_WH,
    tps.AMOUNT_DUE total_schedule_amt,
    tps.DATE_FROM,
    tps.DATE_TO,
    tps.DATE_GENERATED,
    case when tps.POSTED=0 then 'Yes' else 'No' END posted,
    ln.TAX_RATE,
    ln.CONTROL_AMOUNT
  from TAX_PMT_LINES ln INNER JOIN TAX_PMT_SCHEDULE tps ON ln.SCHEDULE_ID = tps.ID
    INNER JOIN PAYMENTS p ON ln.payment_id=p.ID
    INNER JOIN CREDITOR_DEBTOR cd ON p.CREDITORDEBTOR_ID = cd.ID
  where tps.ID=(select grp.tax_schedule_id from V_GENERAL_REPORTS_PARAMS grp) ORDER BY p.PMT_DATE ASC
/

