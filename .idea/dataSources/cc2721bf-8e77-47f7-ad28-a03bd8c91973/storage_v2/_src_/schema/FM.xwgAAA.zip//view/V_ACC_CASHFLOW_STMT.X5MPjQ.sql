create view V_ACC_CASHFLOW_STMT as
  SELECT
    replace(replace(replace(replace(st.CATEGORY, '<b>', ''), '</b>', ''), '<i>', ''), '</i>', '') CATEGORY,
    st.POSITION,
    replace(replace(replace(replace(st.HEADER, '<b>', ''), '</b>', ''), '<i>', ''), '</i>', '') HEADER,
    replace(replace(replace(replace(st.DETAIL, '<b>', ''), '</b>', ''), '<i>', ''), '</i>', '') DETAIL,
    st.BALANCE,
    st.BALPREV,
    st.SCHEME_ID,
    st.DIFFERENCE
  FROM CASHFLOW_STATEMENT st ORDER BY POSITION ASC
/

