create view V_NET_PAYROLL_SCHEDULE_PB as
  with params as (
      select (SELECT pr.MONTH FROM NET_PAYROLL_PB_PARAMS pr) month_p, (SELECT pr.YEAR FROM NET_PAYROLL_PB_PARAMS pr) year_p , (SELECT pr.SCHEME_ID FROM NET_PAYROLL_PB_PARAMS pr) scheme from dual
  ), tabo as(
      select
        (to_char(trunc(to_date('01-'||par.month_p||'-'||par.year_p),'MM')-1, 'MON') ) prevmonth,
        to_char(trunc(to_date('01-'||par.month_p||'-'||par.year_p),'MM')-1, 'YYYY') prevyear
      from params par
  )
  select (SELECT npp.SCHEME_ID FROM NET_PAYROLL_PB_PARAMS npp) SCHEME_ID, bank_name,
         case when mod(to_number(coalesce(SUBSTR(to_char(amount), INSTR(to_char(amount),'.') + 1), '0')), 5) = 0 then amount
         when to_number(coalesce(SUBSTR(to_char(amount), INSTR(to_char(amount),'.') + 1), '0')) < 10 then amount
         else amount end amount,
    active, suspended, (case when BANK_NAME='STIMA SACCO SOCIETY LIMITED' then 'Second Schedule' else 'First Schedule' END)schedule from (select  bank_name, round((sum(amount))*20)/20 amount, sum(active) active, (select COALESCE(sum(coalesce(net, 0)), 0) from payroll pi, params po where pi.month = po.month_p and pi.year = po.year_p and pi.pensioner_id in (select id from pensioners where scheme_id=po.scheme  and PENSION_STATUS ='SUSPENDED'))suspended
                                                                                                                                          from(select pa.pensioner_id, (select name from banks where id = (select bank_id from bank_branches where id = pa.bankbranch_id)) bank_name,
                                                                                                                                                                       (case when pa.pension_status='ACTIVE' then coalesce(pa.net ,0) else 0 end)active, coalesce(pa.net ,0)+coalesce(pa.arreas ,0) amount from payroll pa, params pr where month = pr.month_p and year = pr.year_p
                                                                                                                                                                                                                                                                                                                                            --- eliminating suspended in previous month and stopped in current month
                                                                                                                                                                                                                                                                                                                                            and (pa.pension_status <> 'SUSPENDED' and pa.PENSIONER_ID not in (select PENSIONER_ID from payroll pi, tabo where month = prevmonth and year = prevyear and pension_status = 'SUSPENDED' and pi.PENSIONER_ID in (select PENSIONER_ID from payroll pii where pii.month = pa.month and pii.year = pa.year and pension_status = 'STOPPED' )))
                                                                                                                                          ) group by bank_name
  )order by bank_name
/

