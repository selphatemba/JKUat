create view V_PROV_BALANCES_UNREG as
  with pa1 as (
      select (SELECT MEMBER_ID_FROM FROM V_GENERAL_REPORTS_PARAMS) member_id_p, (SELECT AP_ID FROM V_GENERAL_REPORTS_PARAMS) ap_id_p from dual
  ), pa0 as (
      select id from accounting_periods, pa1  p where  scheme_id=(select scheme_id from members where id = p.member_id_p) and from_date<(select from_date from accounting_periods where id = p.ap_id_p)  and period_type=(select period_type from accounting_periods where id = p.ap_id_p ) order by from_date desc
  ),pa2 as(
      select id prev_ap from pa0 where rownum=1
  )
  SELECT ID, (SELECT SCHEME_ID FROM V_GENERAL_REPORTS_PARAMS) SCHEME_ID,
             (select prev_ap from  pa2 ) prev_acc,
             (select scheme_name from schemes where id = (select scheme_id from members where id = co.MEMBER_ID)) scheme,
             coalesce((select AVCER_BAL+avcer_contr+avcer_intr+avcer_balintr from closing_balances ci, pa2 where status=co.status and member_id=co.member_id and ap_id=pa2.prev_ap) ,0) AVCER_BAL,
             coalesce((select ER_BAL+er_contr+er_intr+er_balintr from closing_balances ci, pa2 where status=co.status and member_id=co.member_id and ap_id=pa2.prev_ap),0) ER_BAL,
             coalesce((select PRE_EMPLOYER_BAL from closing_balances ci, pa2 where status=co.status and member_id=co.member_id and ap_id=pa2.prev_ap),0) PRE_EMPLOYER_BAL,
             coalesce(co.ER_BALINTR,0) ER_BALINTR,
             coalesce(co.AVCER_BALINTR,0) AVCER_BALINTR,
             coalesce(co.PRE_EMPLOYEE_BAL,0) PRE_EMPLOYEE_BAL,
             coalesce((select DEFICIT_BAL from closing_balances ci, pa2 where status=co.status and member_id=co.member_id and ap_id=pa2.prev_ap),0) DEFICIT_BAL,
             coalesce((select EE_BAL+ee_contr+ee_intr+ee_balintr  from closing_balances ci, pa2 where status=co.status and member_id=co.member_id and ap_id=pa2.prev_ap),0) EE_BAL,
             coalesce(co.EE_BALINTR,0) EE_BALINTR,
             coalesce(co.AVC_BALINTR,0) AVC_BALINTR,
             coalesce((select AVC_BAL+avc_contr+avc_intr+avc_balintr from closing_balances ci, pa2 where status=co.status and member_id=co.member_id and ap_id=pa2.prev_ap),0) AVC_BAL,
             coalesce(co.ER_INTR,0) ER_INTR,
             coalesce(co.ER_CONTR,0) ER_CONTR,
             coalesce(co.ER_WITHDR_INTR,0) ER_WITHDR_INTR,
             coalesce(co.ER_WITHDR,0) ER_WITHDR,
             coalesce(co.AVCER_INTR,0) AVCER_INTR,
             coalesce(co.AVCER_CONTR,0) AVCER_CONTR,
             coalesce(co.AVCER_WITHDR_INTR,0) AVCER_WITHDR_INTR,
             coalesce(co.AVCER_WITHDR,0) AVCER_WITHDR,
             coalesce(co.PRE_ADD_VOL_CONT,0) PRE_ADD_VOL_CONT,
             coalesce(co.DEFFERED,0) DEFFERED,
             coalesce(co.TRANSFER,0) TRANSFER,
             coalesce(co.EE_INTR,0) EE_INTR,
             coalesce(co.EE_CONTR,0) EE_CONTR,
             coalesce(co.EE_WITHDR_INTR,0) EE_WITHDR_INTR,
             coalesce(co.EE_WITHDR,0) EE_WITHDR,
             coalesce(co.AVC_WITHDR,0) AVC_WITHDR,
             coalesce(co.AVC_INTR,0) AVC_INTR,
             coalesce(co.AVC_CONTR,0) AVC_CONTR,
             coalesce(co.AVC_WITHDR_INTR,0) AVC_WITHDR_INTR,
    co.LOCKED_IN,
    co.UNLOCK_DATE,
    co.MEMBER_ID,
    co.AP_ID,
    co.STATUS,
    co.RUN_DATE,
    co.RATE,
    co.USER_ID,
             coalesce(co.RESERVE_INCOME,0) RESERVE_INCOME,
             coalesce(co.TAX,0) TAX,
    co.ASAT,
             (select max(to_date) from accounting_periods where id = co.AP_ID) to_date
  FROM CLOSING_BALANCES co, pa1 where status='UNREGISTERED' and member_id = pa1.member_id_p and ap_id = case when pa1.ap_id_p is null then (select prev_ap from pa2) else (select prev_ap from pa2) end
/

