create view V_PROV_COMPUTE_BALANCES as
  select (SELECT SCHEME_ID FROM V_GENERAL_REPORTS_PARAMS) SCHEME_ID, status,
         coalesce(ee_bal, 0) + coalesce(pre_employee_bal, 0)-coalesce(ee_withdr, 0) ee_bal,
         coalesce(avc_bal, 0)-coalesce(avc_withdr, 0) avc_bal,
         coalesce(ee_contr, 0)+coalesce((select sum(coalesce(ee,0)) from contributions where member_id = cl.member_id and type!='BENEFIT_PAYMENT' and status=cl.status and date_paid>cl.asat),0) ee_contr,
         coalesce(avc_contr, 0) avc_contr,
         coalesce(avc_intr, 0)+coalesce(avc_withdr_intr, 0) avc_intr,
         coalesce(avc_balintr, 0) avc_balintr,
         coalesce(ee_balintr, 0) ee_balintr,
         coalesce(ee_intr, 0)+coalesce(ee_withdr_intr, 0) ee_intr,
         (coalesce(er_bal,0)+ coalesce(pre_employer_bal, 0)- coalesce(er_withdr, 0)) er_bal,
         (coalesce(avcer_bal, 0)- coalesce(avcer_withdr, 0)) avcer_bal,
         coalesce(avcer_contr, 0) avcer_contr,
         coalesce(er_contr, 0)+coalesce((select sum(coalesce(er,0)) from contributions where member_id = cl.member_id and type!='BENEFIT_PAYMENT' and status=cl.status and date_paid>cl.asat),0) er_contr,
         (coalesce(avcer_intr, 0)+coalesce(avcer_withdr_intr, 0)) avcer_intr,
         coalesce(avcer_balintr, 0) avcer_balintr,
         coalesce(er_balintr, 0) er_balintr,
         (coalesce(er_intr, 0)+coalesce(er_withdr_intr, 0)) er_intr,
         coalesce( deffered,0) deferred_, transfer
  from closing_balances cl where member_id = (SELECT MEMBER_ID_FROM FROM V_GENERAL_REPORTS_PARAMS) and ap_id=(SELECT AP_ID FROM V_GENERAL_REPORTS_PARAMS)
/

