create view V_DBWRKSHT_WTDR_FOOTER as
  select
    (select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) SCHEME_ID,
    (select firstname||' '||othernames as name from users where id = be.preparedby_id) prepare_user,
    preparedby_id,
    coalesce(to_char(date_prepared, 'dd/MM/yyyy mm:hh:ss'), '--') date_prepared,
    (select firstname||' '||othernames as name from users where id = be.preparedby_id) approve_user,
    approvedby_id,
    coalesce(to_char(date_approved, 'dd/MM/yyyy mm:hh:ss'), '--') date_approved,
    (select firstname||' '||othernames as name from users where id = be.certifiedby_id) certified_user,
    coalesce(to_char(date_certified, 'dd/MM/yyyy mm:hh:ss'), '--') date_certified,certifiedby_id,
    (select firstname||' '||othernames as name from users where id = be.authorizedby_id) authorize_user,
    date_authorized, authorizedby_id from benefits be where id = (select grp.BENEFITS_ID from V_GENERAL_REPORTS_PARAMS grp)
/

