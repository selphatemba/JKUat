create view V_ADD_PAY_BEN_PAY as
  SELECT bp.ID, (SELECT grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) scheme_id,
                coalesce(CASH_EQUIV, 0) CASH_EQUIV,
    rfe.REASON,
    bp.DATE_OF_CALC,
    DATE_PROCESSED,
    IS_FIRST_PAYMENT,
                coalesce(GROSS,0) GROSS,
    bp.IS_TRUST_FUND,
                coalesce(LUMPSUM,0)LUMPSUM,
                coalesce(LUMPSUM_TAX_FREE,0)LUMPSUM_TAX_FREE,
                coalesce(NET_PAYMENT,0)NET_PAYMENT,
    PAYMENT_DATE,
    bp.PAYMENT_MODE,
    POSTED,
                coalesce(REG_EE,0)REG_EE,
                coalesce(REG_ER,0)REG_ER,
                coalesce(REG_NET,0)REG_NET,
                coalesce(REG_TAX,0)REG_TAX,
                coalesce(REG_TOT,0)REG_TOT,
                coalesce(REG_AVC,0)REG_AVC,
                coalesce(REG_AVCER,0)REG_AVCER,
    SERVICE_PERIOD,
    TAX_FREE_APPLIED,
                coalesce(TAXABLE_AMNT,0)TAXABLE_AMNT,
    TXN_REF,
    TYPE,
                coalesce(UN_REG_EE,0)UN_REG_EE,
                coalesce(UN_REG_ER,0)UN_REG_ER,
                coalesce(bp.UNREG_TAX,0)UNREG_TAX,
                coalesce(UNREG_TOT,0)UNREG_TOT,
                coalesce(UN_REG_AVC,0)UN_REG_AVC,
                coalesce(UN_REG_AVCER,0)UN_REG_AVCER,
                coalesce(UNREG_NET,0)UNREG_NET,
                coalesce(UNREG_TAXABLE,0)UNREG_TAXABLE,
                coalesce(WITHOLDING_TAX,0)WITHOLDING_TAX,
    BENEFIT_ID,
    bp.DATE_AUTHORIZED,
    bp.DATE_CERTIFIED,
                auth.FIRSTNAME||' '||auth.OTHERNAMES AUTHORIZEDBY_ID,
                cert.FIRSTNAME||' '||cert.OTHERNAMES CERTIFIEDBY_ID,
                proc.FIRSTNAME||' '||proc.OTHERNAMES PROCESSEDBY_ID,
                auth.FIRSTNAME||' '||auth.OTHERNAMES AUTHORIZED_USER,
                cert.FIRSTNAME||' '||cert.OTHERNAMES CERTIFY_USER,
                prep.FIRSTNAME||' '||prep.OTHERNAMES PREPARE_USER,
    PAYMENT_ID,
    ARREAS_PERIOD,
                coalesce(NET_ARREAS,0)NET_ARREAS,
    SVCPERIOD,
    REGCONTR_ID,
    UNREGCONTR_ID
  FROM BENEFIT_PAYMENTS bp
    INNER JOIN BENEFITS b ON bp.BENEFIT_ID = b.ID
    INNER JOIN REASONS_FOR_EXIT rfe ON b.REASONFOREXIT_ID = rfe.ID
    LEFT JOIN users auth ON bp.AUTHORIZEDBY_ID = auth.ID
    LEFT JOIN users cert ON bp.CERTIFIEDBY_ID = cert.ID
    LEFT JOIN users proc ON bp.PROCESSEDBY_ID = proc.ID
    LEFT JOIN users prep ON bp.preparedBy_id = prep.ID
  where BENEFIT_ID = (select grp.BENEFITS_ID from V_GENERAL_REPORTS_PARAMS grp) AND bp.TYPE!='PENSION_PURCHASE' AND IS_FIRST_PAYMENT=0
/

