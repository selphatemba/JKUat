create view V_ASS_INSUM_COMB as
  SELECT
    DISTINCT c.CATEGORY,
    c.SCHEME_ID,
    coalesce(ob.OPENING_BAL, 0) OPENING_BAL,
    coalesce(p.PURCHASES, 0)PURCHASES,
    coalesce(s.SALE, 0)SALES,
    coalesce(v.VALUATION, 0)VALUATION,
    coalesce((
               coalesce(ob.OPENING_BAL, 0)+
               (coalesce(p.PURCHASES, 0)-coalesce(s.SALE, 0))+
               coalesce(v.VALUATION, 0)),
             0
    )CLOSING_BAL,
    COALESCE((coalesce((
                         coalesce(ob.OPENING_BAL, 0)+
                         (coalesce(p.PURCHASES, 0)-coalesce(s.SALE, 0))+
                         coalesce(v.VALUATION, 0)),
                       0
              )-coalesce(ob.OPENING_BAL, 0)),0)MOVEMENT
  FROM V_ASS_INV_CATEGORIES c
    LEFT JOIN V_ASS_INSUM_OBAL ob ON c.CATEGORY=ob.CATEGORY
    LEFT JOIN V_ASS_INSUM_PURCHASE p ON c.CATEGORY=p.CATEGORY
    LEFT JOIN V_ASS_INSUM_SALE s ON c.CATEGORY=s.CATEGORY
    LEFT JOIN V_ASS_INSUM_VALUATION v ON c.CATEGORY=v.CATEGORY
/

