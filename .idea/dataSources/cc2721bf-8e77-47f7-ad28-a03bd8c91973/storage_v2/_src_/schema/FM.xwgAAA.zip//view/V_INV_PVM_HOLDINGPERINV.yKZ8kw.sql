create view V_INV_PVM_HOLDINGPERINV as
  SELECT
    ids.ID,
    coalesce(obacq.TOTAL_ACQUISITIONS, 0) OB_ACQ,
    coalesce(acq.TOTAL_ACQUISITIONS, 0) ACQUISITIONS,
    coalesce(obsale.TOTAL_SALES, 0) OB_SALES,
    coalesce(sale.TOTAL_SALES, 0) SALES,
    coalesce(obvalu.TOTAL_VALUATION, 0) OB_VALUATION,
    coalesce(valu.TOTAL_VALUATION, 0) VALUATION,
    (case when inv.INVESTMENT_CATEGORY='EQUITY' then coalesce(inv.VALUE_PER_SHARE, 0)*coalesce(fvhold.FV_CLOSING_BAL, 0)
     WHEN (inv.INVESTMENT_CATEGORY='GOVERNMENT_SECURITIES' or inv.INVESTMENT_CATEGORY='CORPORATE_BONDS')
       THEN coalesce((select max(sv.VALUATION_INDEX) from SECURITY_VALUATION sv where sv.INVESTS_ID=inv.ID and sv.VALUATION_DATE=(select max(VALUATION_DATE) from SECURITY_VALUATION s where s.INVESTS_ID=inv.ID and s.VALUATION_DATE<=(select date_to from V_GENERAL_REPORTS_PARAMS))), 0)*coalesce(fvhold.FV_CLOSING_BAL, 0)
     else
       (
         (coalesce(obacq.TOTAL_ACQUISITIONS, 0)+
          coalesce(acq.TOTAL_ACQUISITIONS, 0))-
         (coalesce(obsale.TOTAL_SALES, 0)+
          coalesce(sale.TOTAL_SALES, 0))+
         (coalesce(obvalu.TOTAL_VALUATION, 0)+
          coalesce(valu.TOTAL_VALUATION, 0))
       )
     end
    )market_value
  FROM V_INV_PVM_LISTALLIDS ids
    INNER JOIN INVESTMENTS inv ON ids.ID=inv.ID
    left JOIN V_INV_PVM_OB_ACQS_PER_INV obacq ON ids.ID=obacq.INVESTMENT_ID
    left JOIN V_INV_PVM_OB_SALES_PER_INV obsale ON ids.ID=obsale.INVESTMENT_ID
    left JOIN V_INV_PVM_OB_VALU_PER_INV obvalu ON ids.ID=obvalu.INVESTMENT_ID
    left JOIN V_INV_PVM_ACQS_PER_INV acq ON ids.ID=acq.INVESTMENT_ID
    left JOIN V_INV_PVM_SALES_PER_INV sale ON ids.ID=sale.INVESTMENT_ID
    left JOIN V_INV_PVM_VALU_PER_INV valu ON ids.ID=valu.INVESTMENT_ID
LEFT JOIN V_INV_PVM_FV_HOLDINGPERINV fvhold ON ids.ID=fvhold.ID
/

