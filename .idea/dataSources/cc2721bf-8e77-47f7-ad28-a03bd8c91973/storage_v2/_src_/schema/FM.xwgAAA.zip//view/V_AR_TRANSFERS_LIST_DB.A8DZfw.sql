create view V_AR_TRANSFERS_LIST_DB as
  with quarter as (
  select (select QUARTER from V_AR_PARAMS) q, (select SCHEME_ID from V_AR_PARAMS) scheme_id, (select YEAR FROM V_AR_PARAMS) yr from dual
  ),quarterdef as (
      select case
      when q = 1 then '01-JAN-'||''||qt.yr
                                   when q = 2 then '01-APR-'||''||qt.yr
                                                            when q = 3 then '01-JUL-'||''||qt.yr
                                                                       when q = 4 then '01-OCT-'||''||qt.yr
      else ''
      end as from_date_qt,
      case
      when q = 1 then '31-MAR-'||''||qt.yr
               when q = 2 then '30-JUN-'||''||qt.yr
                                                 when q = 3 then '30-SEP-'||''||qt.yr
                                                                                when q = 4 then '31-DEC-'||''||qt.yr
                                                                                                           else ''
                                                                                                           end as to_date_qt
      from quarter qt
                                      ), tabo as(
      select mem.SCHEME_ID as scheme_id, member_no, mem.surname||', '||mem.firstname||' '||other_names member_name,
                                              to_char(mem.DATE_JOINED_SCHEME,  'dd/MM/yyyy') join_date,(select name from sponsors where id = (select sponsor_id from companies where id = mem.company_id)) sponsor,
                                                                                                                                                                                                           'Transfers' reason,sum(coalesce(con.EE, 0) + coalesce(con.ER, 0) + coalesce( con.AVC, 0) + coalesce(con.AVCER, 0)) transfer,
                                                                                                                                                                                                                                                                                                                              decode(mem.MBSHIP_STATUS, 'NOTIFIED', 'Notified','RETIRED' , 'Retired', 'RETIRED_ILL_HEALTH', 'Ill-health', 'DEATH_IN_SERVICE', 'Death in Service', mem.MBSHIP_STATUS) MBSHIP_STATUS, to_char(con.date_paid, 'Month') month_paid
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    from members mem, quarterdef pe,  quarter qtr, contributions con where con.STATUS = 'TRANSFERS' and   mem.scheme_id=qtr.scheme_id and con.member_id = mem.id  and mem.scheme_id=qtr.scheme_id and date_paid between from_date_qt and to_date_qt
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    group by mem.id, member_no, mem.surname||', '||mem.firstname||' '||other_names,to_char(mem.DATE_JOINED_SCHEME,  'dd/MM/yyyy'),mem.company_id,mem.MBSHIP_STATUS, to_char(con.date_paid, 'Month'), mem.SCHEME_ID
                                                )select tabo."SCHEME_ID",tabo."MEMBER_NO",tabo."MEMBER_NAME",tabo."JOIN_DATE",tabo."SPONSOR",tabo."REASON",tabo."TRANSFER",tabo."MBSHIP_STATUS",tabo."MONTH_PAID" from tabo
/

