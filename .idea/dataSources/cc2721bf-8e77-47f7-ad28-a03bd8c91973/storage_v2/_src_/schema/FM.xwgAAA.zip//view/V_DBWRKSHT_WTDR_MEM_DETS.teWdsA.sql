create view V_DBWRKSHT_WTDR_MEM_DETS as
  select
    SCHEME_ID,
      (select reason from reasons_for_exit where id=(select reasonforexit_id from benefits where id = exit_id)) reasonforexit,
      (select name from sponsors where id = (select sponsor_id from companies where id = me.company_id and rownum=1)) sponsor,
    department_no,
      (select date_of_exit from benefits where id = me.exit_id) date_of_exit,
    mb.id_no,date_of_empl, mb.depot, mb.sub_region, mb.region_addr
    , (select age_at_exit from benefits where id = me.exit_id and rownum=1) age_at_exit,
    designation,
      (select normal from retirement_ages re where memberclass_id = me.mclass_id and re.gender = mb.gender and rownum=1) retire_age_normal,
      add_months(mb.dob, 12*(select normal from retirement_ages re where memberclass_id = me.mclass_id and re.gender = mb.gender and rownum=1)) retire,
      DECODE(mb.TITLE,'MR','Mr.', 'MRS', 'Mrs.', 'DR', 'Dr.', 'PROF', 'Prof.', 'REV', 'Rev.', 'ENG', 'Eng.', 'MISS', 'Ms.', '')||' '||mb.FIRSTNAME||' '||mb.SURNAME||' '||mb.OTHER_NAMES name,
      me.MEMBER_NO member_no, mb.DOB, me.DATE_JOINED_SCHEME,
      case when ben.AGE_AT_EXIT is null then (to_char(current_date, 'yyyy')-to_char(mb.dob,'yyyy')) else ben.AGE_AT_EXIT end age
  from members me
    LEFT JOIN BENEFITS ben on me.EXIT_ID = ben.ID
    INNER JOIN MEMBERS_BIOS mb ON me.MEMBERBIO_ID = mb.ID where me.id = (select grp.MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS grp)
/

