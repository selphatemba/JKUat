create view V_GUARANTEED_PENSION_WRKSHT as
  select
    bp.ID,
    bp.DATE_OF_CALC,
    bp.DATE_PROCESSED,
    bp.GROSS,
    bp.LUMPSUM_TAX_FREE,
    bp.NET_PAYMENT,
    bp.REG_EE,
    bp.REG_NET,
    bp.REG_TAX,
    bp.REG_TOT,
    bp.TAX_FREE_APPLIED,
    bp.TAXABLE_AMNT,
    replace(bp.TYPE, '_', ' ') type,
    bp.DATE_AUTHORIZED,
    bp.DATE_CERTIFIED,
    bp.DATE_PREPARED,
    rfe.REASON,
    prep.FIRSTNAME||' '||prep.OTHERNAMES preparer,
    cert.FIRSTNAME||' '||cert.OTHERNAMES certifier,
    auth.FIRSTNAME||' '||auth.OTHERNAMES authorizer,
    proc.FIRSTNAME||' '||proc.OTHERNAMES processor,
    COALESCE(b.ANNUAL_SALARY, 0) pensinable_emol,
    COALESCE(b.TARGET_PRE, 0),
    COALESCE(b.TARGET_POST, 0),
    COALESCE(b.TARGET_PRE, 0)+COALESCE(b.TARGET_POST, 0) target_pension,
    COALESCE(b.ANNUAL_PENSION, 0),
    COALESCE(b.MONTHLY_PENS, 0)*12 annual_pen_pre,
    COALESCE(b.MONTHLY_PENS2, 0)*12 annual_pen_post,
    COALESCE(b.MONTHLY_PENS, 0),
    COALESCE(b.MONTHLY_PENS2, 0),
    COALESCE(b.MONTHLY_PENS2, 0)+COALESCE(b.MONTHLY_PENS, 0) monthly_pension,
    COALESCE(b.NET_ARREARS,0),
    (select coalesce(grp.PENSION_TAX, 0) from V_GENERAL_REPORTS_PARAMS grp) as pension_tax,
    COALESCE(b.MONTHLY_PENS2, 0)+COALESCE(b.MONTHLY_PENS, 0)-(select coalesce(grp.PENSION_TAX, 0) from V_GENERAL_REPORTS_PARAMS grp) net_monthly_pen
  from BENEFIT_PAYMENTS bp
    INNER JOIN BENEFITS b on bp.BENEFIT_ID = b.ID
    LEFT JOIN REASONS_FOR_EXIT rfe on bp.REASONFOREXIT_ID = rfe.ID
    LEFT JOIN USERS prep on bp.PREPAREDBY_ID = prep.ID
    LEFT JOIN USERS cert on bp.CERTIFIEDBY_ID = cert.ID
    LEFT JOIN USERS auth on bp.AUTHORIZEDBY_ID = auth.ID
    LEFT JOIN USERS proc on bp.PROCESSEDBY_ID = proc.ID
  where bp.ID=(select grp.BENEFITPAYMENTID from V_GENERAL_REPORTS_PARAMS grp)
        and bp.TYPE='DEATH_IN_RETIREMENT_BENEFITS'
/

