create view V_PAYREC_PREV_PENSION_ARRS as
  with params as (
      select (SELECT MONTH FROM V_PAYREC_PARAMS) monthpar, (SELECT YEAR FROM V_PAYREC_PARAMS) yearpar from dual
  ), addparams as(
      select to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM')-1, 'MON') prevmonth,
             to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM')-1, 'YYYY') prevyear,
             to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM'), 'Month') monthlong,
        par.*
      from params par
  ), cachetab as(
      select * from payroll pay, addparams adp
      where (pay.year = adp.yearpar and pay.month = adp.monthpar) or (pay.month = adp.prevmonth and pay.year = adp.prevyear )
  ) , thispayroll as(
      select ct.* from cachetab ct, addparams adp where month = adp.monthpar and year = adp.yearpar
  ), lastpayroll as(
      select ct.* from cachetab ct, addparams adp where month = adp.prevmonth and year = adp.prevyear
  ), lastnet as(
      select lp.pensioner_id,sum((coalesce(lp.gross,0)+coalesce(lp.arreas,0))-(coalesce(lp.deds,0)+coalesce(lp.tax,0)+ coalesce(lp.tax_on_arreas,0))) lnet from lastpayroll lp group by lp.pensioner_id
  ), thisnet as (
      select tp.pensioner_id,(sum((coalesce(tp.gross,0)+coalesce(tp.arreas,0))-(coalesce(tp.deds,0)+coalesce(tp.tax,0)+ coalesce(tp.tax_on_arreas,0)))) tnet from thispayroll tp group by tp.pensioner_id
  )
  select (select PAYROLL_RECON_PARAMS.SCHEME_ID from PAYROLL_RECON_PARAMS) scheme_id, 'Current pension arrears of ' label,
         case when pe.member_id is null then (select member_no from beneficiaries ben, members mem where ben.member_id=mem.id and ben.id = pe.BENEFICIARY_ID) else (select member_no from  members where id= pe.member_id) end member_no,
    pe.pension_no,
         case when pe.member_id is null  then (select surname||', '||firstname||' '||othernames from beneficiaries where id = pe.BENEFICIARY_ID) else (select surname||', '||firstname||' '||other_names from  members where id= pe.member_id) end names,
         (coalesce(lp.net,0)+coalesce(lp.arreas,0)) last_pension,
         (coalesce(tp.net,0)+coalesce(tp.arreas,0)) this_pension,
    pe.account_no,
         (select bb.name from bank_branches bb where bb.id = pe.branch_id) current_branch,
         (select b.name from banks b where b.id = (select bb.bank_id from bank_branches bb where bb.id = pe.branch_id)) current_bank
  from thispayroll tp inner join lastpayroll lp on lp.pensioner_id = tp.pensioner_id
    inner join pensioners pe on pe.id = tp.pensioner_id
    inner join thisnet tn on tn.pensioner_id = tp.pensioner_id
    inner join lastnet ln on ln.pensioner_id = tp.pensioner_id
  where
    ln.lnet > tn.tnet
    and (tp.pension_status = 'ACTIVE')
    and lp.ACCOUNT_NO not in(select d.ACCOUNT_NO from deductions d inner join lastpayroll lp on d.account_no = lp.account_no and d.PENSIONER_ID=lp.PENSIONER_ID)
    and tp.ACCOUNT_NO not in(select d.ACCOUNT_NO from deductions d inner join thispayroll tp on d.account_no = tp.account_no and d.PENSIONER_ID=tp.PENSIONER_ID)
    and tp.pensioner_id not in
        (select t.pensioner_id from thispayroll t inner join lastpayroll l on l.pensioner_id = t.pensioner_id where l.pension_status='SUSPENDED' and (t.pension_status = 'ACTIVE'))
  order by pe.pension_no DESC
/

