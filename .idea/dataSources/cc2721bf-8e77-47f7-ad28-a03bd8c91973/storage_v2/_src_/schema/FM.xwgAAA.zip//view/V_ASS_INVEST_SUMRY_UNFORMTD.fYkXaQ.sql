create view V_ASS_INVEST_SUMRY_UNFORMTD as
  with cache as(
      SELECT inv.INVESTMENT_CATEGORY, inv.SCHEME_ID,
        sum(case
            when inv.INVESTMENT_CATEGORY = 'CORPORATE_BONDS' then  coalesce(txn.AMOUNT , 0)
            when inv.INVESTMENT_CATEGORY = 'CORPORATE_BONDS'  and (txn.TRANSACTION_TYPE = 'CORPEC_VALUATION' or txn.TRANSACTION_TYPE= 'CORPSEC_ACCRUED_INCOME' or TRANSACTION_TYPE ='CORPSEC_DISCOUNT') then  coalesce(txn.AMOUNT, 0)
            when inv.INVESTMENT_CATEGORY = 'FIXED_TERM_DEPOSIT' then coalesce(inv.INITIAL_VALUE, 0)
            when inv.INVESTMENT_CATEGORY = 'FIXED_TERM_DEPOSIT' and  txn.TRANSACTION_TYPE= 'FXDTRMDEP_ACCRUEDINCOME_RECEIVABLE'then coalesce(txn.AMOUNT,0)
            when inv.INVESTMENT_CATEGORY = 'LOAN_TO_GOVERNMENT' then coalesce(inv.INITIAL_VALUE, 0)
            when inv.INVESTMENT_CATEGORY = 'LOAN_TO_GOVERNMENT' and (txn.TRANSACTION_TYPE = 'GOV_LOAN_VALUATION' or txn.TRANSACTION_TYPE= 'GOV_INTEREST_RECEIVABLE') then coalesce(txn.AMOUNT,0)
            when inv.INVESTMENT_CATEGORY = 'LOAN_TO_CORPORATE' then coalesce(inv.INITIAL_VALUE, 0)
            when inv.INVESTMENT_CATEGORY = 'LOAN_TO_CORPORATE'  and (txn.TRANSACTION_TYPE = 'COOPARATE_LOAN_VALUATION' or txn.TRANSACTION_TYPE= 'COOPARATE_INTEREST_RECEIVABLE') then coalesce(txn.AMOUNT, 0)
            when inv.INVESTMENT_CATEGORY = 'LOAN_TO_CORPORATIVE' then coalesce(inv.INITIAL_VALUE, 0)
            when inv.INVESTMENT_CATEGORY = 'LOAN_TO_CORPORATIVE' and (txn.TRANSACTION_TYPE = 'COOPORATIVE_LOAN_VALUATION' or txn.TRANSACTION_TYPE= 'COOPORATIVE_INTEREST_RECEIVABLE') then coalesce(txn.AMOUNT, 0)
            when inv.INVESTMENT_CATEGORY = 'CASH_CALL_DEPOSITS' then coalesce(txn.AMOUNT, 0)
            when inv.INVESTMENT_CATEGORY = 'CASH_CALL_DEPOSITS' and (txn.TRANSACTION_TYPE = 'CALL_DEP_INTEREST' ) then coalesce(txn.AMOUNT,0)
            when inv.INVESTMENT_CATEGORY = 'PROPERTY' then coalesce(inv.INITIAL_VALUE, 0)
            when inv.INVESTMENT_CATEGORY = 'PROPERTY' and  (txn.TRANSACTION_TYPE = 'PROPERTY_VALUATION' or txn.TRANSACTION_TYPE= 'GAIN_ON_SALE' or TRANSACTION_TYPE ='RENT_SECURITY_DEPOSIT_RECEIVABLE') then coalesce(txn.AMOUNT, 0)
            when inv.INVESTMENT_CATEGORY = 'GOVERNMENT_SECURITIES' then coalesce(txn.AMOUNT, 0)
            when inv.INVESTMENT_CATEGORY = 'GOVERNMENT_SECURITIES' and (txn.TRANSACTION_TYPE = 'GOVTSEC_VALUATION' or txn.TRANSACTION_TYPE= 'GOVTSEC_ACCRUED_INCOME') then coalesce(txn.AMOUNT, 0)
            when inv.INVESTMENT_CATEGORY = 'COLLECTIVE_INVESTMENTS' and (txn.equit_type = 'CIS' or TRANSACTION_TYPE='CI_VALUATION' OR TRANSACTION_TYPE= 'CI_DIVIDENDS') then coalesce(txn.AMOUNT, 0)
            when inv.INVESTMENT_CATEGORY = 'EQUITY' and (txn.transaction_type = 'EQUITY_ACQUISITION' or txn.transaction_type = 'EQUITY_VALUATION' OR TRANSACTION_TYPE = 'EQUITY_DIVIDENDS') then coalesce(txn.AMOUNT, 0)
            when inv.LOCALITY = 'OFFSHORE' and inv.INVESTMENT_TYPE = 'SECURITY_BOND' then coalesce(txn.AMOUNT, 0)
            when inv.LOCALITY = 'OFFSHORE' and inv.INVESTMENT_TYPE = 'FIXED_TERM_DEPOSIT' then coalesce(inv.INITIAL_VALUE, 0)
            when inv.LOCALITY = 'OFFSHORE' and inv.INVESTMENT_TYPE = 'LOAN' then coalesce(inv.INITIAL_VALUE, 0)
            when inv.LOCALITY = 'OFFSHORE' and inv.INVESTMENT_TYPE = 'CASH_AND_CALL_DEPOSIT' then coalesce(txn.AMOUNT, 0)
            when inv.LOCALITY = 'OFFSHORE' and inv.INVESTMENT_TYPE = 'PROPERTY' then coalesce(inv.INITIAL_VALUE, 0)
            when inv.INVESTMENT_CATEGORY = 'OFFSHORE' and inv.INVESTMENT_TYPE = 'EQUITY' and (txn.transaction_type = 'EQUITY_ACQUISITION'  or txn.transaction_type = 'EQUITY_VALUATION' OR TRANSACTION_TYPE = 'EQUITY_DIVIDENDS') then coalesce(txn.AMOUNT, 0)
            else 0 end) as holding,
        (SELECT max(t.TARGET) from TACTICAL_SETTINGS t where t.CATEGORY = inv.INVESTMENT_CATEGORY) as target
      from INVESTMENTS inv
        left join investment_txns txn on inv.id = txn.INVESTMENT_ID
      where
        (txn.TRANS_DATE BETWEEN (select grp.DATE_FROM from V_GENERAL_REPORTS_PARAMS grp) AND (select grp.DATE_TO from V_GENERAL_REPORTS_PARAMS grp)) AND txn.SCHEME_ID = (select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp)
      GROUP BY inv.INVESTMENT_CATEGORY, inv.SCHEME_ID
  ) select
      (DECODE(INVESTMENT_CATEGORY, 'EQUITY', 'Equity', 'CORPORATE_BONDS' , 'Corporate Bonds', 'GOVERNMENT_SECURITIES', 'Government Securities', 'FIXED_TERM_DEPOSIT', 'Fixed Term Deposits',  'COLLECTIVE_INVESTMENTS', 'Collective Investment',   'OFFSHORE', 'Offshore Investment',   'LOAN_TO_GOVERNMENT', 'Loans To Government',   'LOAN_TO_CORPORATE', 'Loans To Corporates',   'LOAN_TO_CORPORATIVE', 'Loans To Co-oporative Societies',    'PROPERTY', 'Property', 'CASH_CALL_DEPOSITS', 'Cash and Call Deposits', INVESTMENT_CATEGORY)) category,
      SCHEME_ID,
      INVESTMENT_CATEGORY,
      (select sum(holding) from cache) grand,
      sum(holding) holding,
      CAST((sum(holding)/(select sum(holding) from cache) * 100) AS DECIMAL(38,2)) AS actual,
      target,
      cast(target - (sum(holding)/(select sum(holding) from cache) * 100) as DECIMAL (38,2))  variance,
      CAST(cast((case when sum(holding) = 0
        then 0
                 else
                   coalesce((holding*target)/(sum(holding)/(select sum(holding) from cache) * 100), 0)
                 end) as DECIMAL (38,2)) AS DECIMAL (38,2)) as target_amount,
      cast (case when sum(holding) = 0
        then 0
            else
              coalesce((holding*(target - (sum(holding)/(select sum(holding) from cache) * 100)))/(sum(holding)/(select sum(holding) from cache) * 100), 0)
            end as DECIMAL (38,2)) as variance_amount
    from cache group by INVESTMENT_CATEGORY, SCHEME_ID, target,holding
/

