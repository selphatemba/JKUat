create view V_ACC_GLREPORT_COMP as
  select
    (select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) scheme_id,
    (select coalesce(op.debitBal, 0) from V_ACC_GLREPORT_OPENING op) open_debitbal,
    (select coalesce(op.creditBal, 0) from V_ACC_GLREPORT_OPENING op) open_creditbal,
    (select coalesce(sum(coalesce(ent.debit, 0)), 0) from V_ACC_GLREPORT_ENTRIES ent) sumDebitEntries,
    (select coalesce(sum(coalesce(ent.credit, 0)), 0) from V_ACC_GLREPORT_ENTRIES ent) sumCreditEntries,
    ((select coalesce(sum(coalesce(ent.debit, 0)), 0) from V_ACC_GLREPORT_ENTRIES ent))totalDebitBalClose,
    ((select coalesce(sum(coalesce(ent.credit, 0)), 0) from V_ACC_GLREPORT_ENTRIES ent))totalCreditBalClose,
    (
      ((select coalesce(sum(coalesce(ent.debit, 0)), 0) from V_ACC_GLREPORT_ENTRIES ent))
      -
      ((select coalesce(sum(coalesce(ent.credit, 0)), 0) from V_ACC_GLREPORT_ENTRIES ent))

    )netDebitMinusCredit,
    case when (
                ((select coalesce(op.debitBal, 0) from V_ACC_GLREPORT_OPENING op)+(select coalesce(sum(coalesce(ent.debit, 0)), 0) from V_ACC_GLREPORT_ENTRIES ent))
                -
                ((select coalesce(op.creditBal, 0) from V_ACC_GLREPORT_OPENING op)+(select coalesce(sum(coalesce(ent.credit, 0)), 0) from V_ACC_GLREPORT_ENTRIES ent))

              )>=0 THEN
      (
        ((select coalesce(sum(coalesce(ent.debit, 0)), 0) from V_ACC_GLREPORT_ENTRIES ent))
        -
        ((select coalesce(sum(coalesce(ent.credit, 0)), 0) from V_ACC_GLREPORT_ENTRIES ent))

      ) ELSE 0 END debitClosingBalNetChange,
    case when (
                ((select coalesce(sum(coalesce(ent.debit, 0)), 0) from V_ACC_GLREPORT_ENTRIES ent))
                -
                ((select coalesce(sum(coalesce(ent.credit, 0)), 0) from V_ACC_GLREPORT_ENTRIES ent))

              )<0 THEN
      (
        ((select coalesce(sum(coalesce(ent.debit, 0)), 0) from V_ACC_GLREPORT_ENTRIES ent))
        -
        ((select coalesce(sum(coalesce(ent.credit, 0)), 0) from V_ACC_GLREPORT_ENTRIES ent))

      )*-1 ELSE 0 END creditClosingBalNetChange

  from dual
/

