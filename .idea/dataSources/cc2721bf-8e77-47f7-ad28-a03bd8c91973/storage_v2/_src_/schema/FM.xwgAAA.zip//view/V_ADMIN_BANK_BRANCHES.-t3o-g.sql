create view V_ADMIN_BANK_BRANCHES as
  select bb.CODE, bb.NAME, bb.PHYSICAL_LOCATION, bb.STATUS, b.code bankcode, b.NAME bankname from BANK_BRANCHES bb INNER JOIN BANKS b on bb.BANK_ID = b.ID ORDER BY b.code ASC
/

