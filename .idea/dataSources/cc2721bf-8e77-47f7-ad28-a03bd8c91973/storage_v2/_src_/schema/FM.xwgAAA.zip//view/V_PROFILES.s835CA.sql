create view V_PROFILES as
  SELECT ID,
    DESCR,
    EDIT_DAYS,
    NAME
 FROM PROFILES
/

