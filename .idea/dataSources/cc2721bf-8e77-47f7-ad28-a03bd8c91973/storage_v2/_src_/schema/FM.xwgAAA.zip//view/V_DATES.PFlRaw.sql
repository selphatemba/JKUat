create view V_DATES as
  SELECT start_date + LEVEL ds_date,
         TO_CHAR (start_date + LEVEL, 'YYYY') ds_year,
         TO_CHAR (start_date + LEVEL, 'YYYY')
         || 'S'
         || DECODE (TO_CHAR (start_date + LEVEL, 'Q'),
                    1, 1,
                    2, 1,
                    3, 2,
                    4, 2)
           ds_sem,
         TO_CHAR (start_date + LEVEL, 'YYYY')
         || 'Q'
         || TO_CHAR (start_date + LEVEL, 'Q')
           ds_qrtr,
         TO_CHAR (start_date + LEVEL, 'mm/YYYY') ds_month,
         TO_CHAR (start_date + LEVEL, 'YYYY')
         || 'W'
         || TO_CHAR (start_date + LEVEL, 'WW')
           ds_week,
         TO_CHAR (start_date + LEVEL, 'DAY') ds_week_day
  FROM (SELECT TO_DATE ('01/01/1960', 'dd/mm/yyyy') start_date,
               TO_DATE ('31/12/2020', 'dd/mm/yyyy') end_date
        FROM DUAL) PARAM
  CONNECT BY PARAM.start_date + LEVEL <= PARAM.end_date
/

