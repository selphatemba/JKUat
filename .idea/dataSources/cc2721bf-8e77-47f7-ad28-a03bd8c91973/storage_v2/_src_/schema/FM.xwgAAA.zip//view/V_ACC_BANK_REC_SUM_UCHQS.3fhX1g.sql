create view V_ACC_BANK_REC_SUM_UCHQS as
  select coalesce((coalesce(sum(uc.CREDIT), 0)-coalesce(sum(uc.DEBIT), 0)), 0) uc_amount, case when uc.CB_BALCR is NULL then NULL else uc.CB_BALCR+coalesce((coalesce(sum(uc.CREDIT), 0)-coalesce(sum(uc.DEBIT), 0)), 0) END bank_bal_cr, case when uc.CB_BALDR is NULL then NULL else uc.CB_BALDR+coalesce((coalesce(sum(uc.CREDIT), 0)-coalesce(sum(uc.DEBIT), 0)), 0) END bank_bal_dr, SCHEME_ID from V_ACC_BANK_RECON_FINAL uc GROUP BY SCHEME_ID, UC.BANK_BALCR, UC.BANK_BALDR, uc.CB_BALDR, uc.CB_BALCR
/

