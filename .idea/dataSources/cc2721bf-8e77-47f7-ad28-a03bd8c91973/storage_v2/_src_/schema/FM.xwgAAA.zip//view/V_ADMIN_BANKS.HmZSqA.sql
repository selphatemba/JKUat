create view V_ADMIN_BANKS as
  select b.CODE, b.NAME, b.PAYPOINT_TYPE, b.STATUS from BANKS b ORDER BY b.code ASC
/

