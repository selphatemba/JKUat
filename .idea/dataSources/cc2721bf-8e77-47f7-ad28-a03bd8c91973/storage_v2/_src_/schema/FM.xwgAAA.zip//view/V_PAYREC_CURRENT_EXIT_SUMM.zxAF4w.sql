create view V_PAYREC_CURRENT_EXIT_SUMM as
  with params as (
      select (SELECT MONTH FROM V_PAYREC_PARAMS) monthpar, (SELECT YEAR FROM V_PAYREC_PARAMS) yearpar from dual
  ), addparams as(
      select to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM')-1, 'MON') prevmonth,
             to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM')-1, 'YYYY') prevyear,
             to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM'), 'Month') monthlong
      from params par
  ) , thispayroll as(
      select pay.* from payroll pay, params p where pay.month = p.monthpar and pay.year = p.yearpar
  ), lastpayroll as(
      select pay.* from payroll pay, addparams adp where month = adp.prevmonth and year = adp.prevyear
  )
  select (select PAYROLL_RECON_PARAMS.SCHEME_ID from PAYROLL_RECON_PARAMS) scheme_id,
         (select  sum((coalesce(lp.gross,0)+coalesce(lp.arreas,0))-(coalesce(lp.deds,0)+coalesce(lp.tax,0))+coalesce(lp.tax_on_arreas,0)) from lastpayroll lp where lp.pension_status != 'SUSPENDED' and lp.pensioner_id not in (select pensioner_id from thispayroll tp , pensioners p where tp.pensioner_id = p.id and p.pension_status = 'STOPPED' or p.pension_status = 'DECEASED')) currentexitsamt
    ,
         (select count(*) from lastpayroll lp where lp.pension_status = 'ACTIVE' and lp.pensioner_id not in (select pensioner_id from thispayroll tp , pensioners p where tp.pensioner_id = p.id and p.pension_status = 'STOPPED' or p.pension_status = 'DECEASED')) currentexitscount
    --exits that were on suspension
    ,
         (select count(*) from lastpayroll lp where lp.pension_status = 'SUSPENDED' and lp.pensioner_id not in (select tp.pensioner_id from thispayroll tp , pensioners p where tp.pensioner_id = p.id and tp.pension_status = 'SUSPENDED' and p.pension_status = 'STOPPED' or p.pension_status = 'DECEASED')) susexitscount
    ,
         (select  COALESCE(sum((coalesce(lp.gross,0)+coalesce(lp.arreas,0))-(coalesce(lp.deds,0)+coalesce(lp.tax,0))+coalesce(lp.tax_on_arreas,0)), 0) from lastpayroll lp where lp.pension_status = 'SUSPENDED' and lp.pensioner_id not in (select tp.pensioner_id from thispayroll tp , pensioners p where tp.pensioner_id = p.id and tp.pension_status = 'SUSPENDED' and p.pension_status = 'STOPPED' or p.pension_status = 'DECEASED')) susexitsamt from dual
/

