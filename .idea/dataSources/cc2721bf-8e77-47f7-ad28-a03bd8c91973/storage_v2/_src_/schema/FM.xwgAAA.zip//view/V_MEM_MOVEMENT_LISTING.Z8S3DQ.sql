create view V_MEM_MOVEMENT_LISTING as
  with params as (
      select (select grp.DATE_FROM_STR from V_GENERAL_REPORTS_PARAMS grp) as fdate, (select grp.DATE_TO_STR from V_GENERAL_REPORTS_PARAMS grp) as tdate, (select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) schemep from dual
  )
  SELECT distinct to_char(TO_DATE(par.fdate), 'dd/MM/yyyy') from_date,
                  to_char(TO_DATE(par.tdate), 'dd/MM/yyyy') to_date,
    me.exit_id,
                  MEMBER_NO  "M/NO", "ID_NO",
                  (SELECT SCHEMES.SCHEME_NAME FROM SCHEMES WHERE ID = par.schemep) SCHEME,
    SCHEME_ID,
                  FIRSTNAME||' '||OTHER_NAMES||' '||SURNAME  "NAME",b.ID, b.DATE_OF_EXIT, REASONFOREXIT_ID,(CASE WHEN PROCESSED=1 THEN 'Yes' ELSE 'No' END)PROCESSED,
                  (SELECT REASON FROM REASONS_FOR_EXIT WHERE ID = B.REASONFOREXIT_ID  and rownum=1) REASON,
    DATE_OF_CALCULATION,(SELECT NET_PAYMENT FROM BENEFIT_PAYMENTS WHERE benefit_ID = B.ID and rownum=1) AMOUNT_TO_PAY
  FROM BENEFITS B , members me, params par
  WHERE DATE_OF_EXIT BETWEEN TO_DATE(par.fdate) AND TO_DATE(par.tdate) and me.exit_id =b.id
        AND me.SCHEME_ID = par.schemep order by me.MEMBER_NO
/

