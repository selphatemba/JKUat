create view V_INV_PVS_HOLDINGPERINV as
  SELECT
    ids.ID,
    coalesce(acq.TOTAL_ACQUISITIONS, 0),
    coalesce(sales.TOTAL_SALES, 0),
    coalesce(valu.TOTAL_VALUATION, 0),
    (case when inv.INVESTMENT_CATEGORY='EQUITY' then coalesce(inv.VALUE_PER_SHARE, 0)*coalesce(fvhold.HOLDING, 0)
     WHEN (inv.INVESTMENT_CATEGORY='GOVERNMENT_SECURITIES' or inv.INVESTMENT_CATEGORY='CORPORATE_BONDS')
       THEN coalesce((select max(sv.VALUATION_INDEX) from SECURITY_VALUATION sv where sv.INVESTS_ID=inv.ID and sv.VALUATION_DATE=(select max(VALUATION_DATE) from SECURITY_VALUATION s where s.INVESTS_ID=inv.ID and s.VALUATION_DATE<=(select date_to from V_GENERAL_REPORTS_PARAMS))), 0)*coalesce(fvhold.HOLDING, 0)
     else (coalesce(acq.TOTAL_ACQUISITIONS, 0)-coalesce(sales.TOTAL_SALES, 0)+coalesce(valu.TOTAL_VALUATION, 0)) end)holding
  FROM V_INV_PVS_LISTALLIDS ids
    INNER JOIN INVESTMENTS inv on ids.ID=inv.ID
    left JOIN V_INV_PVS_ACQS_PER_INV acq ON ids.ID=acq.INVESTMENT_ID
    left JOIN V_INV_PVS_SALES_PER_INV sales ON ids.ID=sales.INVESTMENT_ID
    left JOIN V_INV_PVS_VALU_PER_INV valu ON ids.ID=valu.INVESTMENT_ID
    LEFT JOIN V_INV_PVS_FV_HOLDINGPERINV fvhold ON fvhold.ID=ids.ID
/

