create view V_DBAR_RETIREES_AGE_AN as
  with quarter_period as (
      select (SELECT QUARTER FROM V_AR_PARAMS) q, (SELECT YEAR FROM V_AR_PARAMS) yr from dual
  ),
      quarterdef as (
        select case
               when q = 1 then '01-JAN-'||''||qt.yr
               when q = 2 then '01-APR-'||''||qt.yr
               when q = 3 then '01-JUL-'||''||qt.yr
               when q = 4 then '01-OCT-'||''||qt.yr
               else ''
               end as from_date_qt,
               case
               when q = 1 then '31-MAR-'||''||qt.yr
               when q = 2 then '30-JUN-'||''||qt.yr
               when q = 3 then '30-SEP-'||''||qt.yr
               when q = 4 then '31-DEC-'||''||qt.yr
               else ''
               end as to_date_qt
        from quarter_period qt
    ),
      GAP AS (
        SELECT 10 AS GAP, (SELECT scheme_id from V_AR_PARAMS) SCHEME_ID,40 MIN_AGE,100 MAX_AGE,'ALL' GENDER, 'ACTIVE' STATUS, 'SELF' PENSIONER_TYPE FROM DUAL
    ),
      DETS AS (
        SELECT SUM(GAP.GAP) OVER(PARTITION BY GAP.GAP ORDER BY ID) CUM_AGE FROM PENSIONERS P, GAP WHERE P.SCHEME_ID = GAP.SCHEME_ID AND P.PENSIONER_TYPE = GAP.PENSIONER_TYPE AND P.PENSION_STATUS = GAP.STATUS GROUP BY ID, GAP.GAP
    ),quarter_months as(
      SELECT to_char(ADD_MONTHS(TRUNC(TO_DATE(pe.from_date_qt, 'DD-MON-YYYY'), 'MON'), ROWNUM - 1),'MON') date_out FROM   DUAL, quarterdef pe CONNECT BY ADD_MONTHS(TRUNC(TO_DATE(pe.from_date_qt, 'DD-MON-YYYY'), 'MON'), ROWNUM - 1)<= TRUNC(TO_DATE(pe.to_date_qt, 'DD-MON-YYYY'), 'MON')),
      tabo as (
        SELECT SCHEME_ID, CUM_AGE-gap s_age, (CUM_AGE-GAP.GAP+1)||'-'||CUM_AGE AS RANGE,
          (SELECT to_char(to_date(to_date_qt),'dd/MM/yyyy') FROM quarterdef) to_date,
          (SELECT to_char(to_date(from_date_qt),'dd/MM/yyyy') FROM quarterdef) from_date,
          (
            (select count(*) from payroll pay join pensioners p on pay.pensioner_id = p.id  where (pay.PENSION_STATUS = 'ACTIVE' OR pay.PENSION_STATUS = 'SUSPENDED') and pay.month  =(select date_out from (select date_out,rownum as rn from (select date_out from quarter_months)) where rn = 3) and pay.year = qr.yr and pay.account_no not in (select account_no from deductions where pensioner_id = pay.pensioner_id) and (pay.PENSION_STATUS = GAP.STATUS OR pay.PENSION_STATUS = 'SUSPENDED') AND P.PENSIONER_TYPE = GAP.PENSIONER_TYPE AND EXTRACT(YEAR FROM CURRENT_DATE)-EXTRACT(YEAR FROM (SELECT M.DOB FROM MEMBERS M WHERE M.ID = P.MEMBER_ID AND M.SCHEME_ID = P.SCHEME_ID)) BETWEEN (CUM_AGE+1-GAP.GAP) AND CUM_AGE AND SCHEME_ID = (SELECT SCHEME_ID FROM GAP))
          ) COUNT FROM DETS,GAP,quarterdef,quarter_period qr WHERE CUM_AGE BETWEEN MIN_AGE+GAP.GAP AND MAX_AGE
    ),
      tabo2 as(
        select t.*, (select sum(coalesce(count,0)) from tabo) smt, round((count/(select sum(coalesce(count,0)) from tabo)) * 100, 2) perc  from tabo t
    )
  select t2."SCHEME_ID",t2."S_AGE",t2."RANGE",t2."TO_DATE",t2."FROM_DATE",t2."COUNT",t2."SMT",t2."PERC", (select max(perc) from tabo2) highestperc, (select range from tabo2 where perc = (select max(perc) from tabo2)) rng, (select sum(perc) from tabo2 where s_age<=50) earlyrt from tabo2 t2
/

