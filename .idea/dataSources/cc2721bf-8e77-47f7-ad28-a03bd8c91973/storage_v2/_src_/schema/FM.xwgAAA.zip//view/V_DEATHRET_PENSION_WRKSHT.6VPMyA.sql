create view V_DEATHRET_PENSION_WRKSHT as
  select
    p.ID,
    p.MONTHLY_PENSION,
    p.MONTHLY_PENSION2,
    p.PENSION,
    p.TARGET_PENSION_POST,
    p.TARGET_PENSION_PRE,
    p.pension_tax,
    p.PENSION-p.PENSION_TAX netpension,
    p.PENSION_NO,
    b.PCT_MONTHLY,
    b.PCT_LUMP,
    b.FIRSTNAME ||' '|| b.SURNAME ||' '|| b.OTHERNAMES name,
    b.ACCOUNT_NO,
    b.ACCOUNT_NAME,
    bk.BANKCODE,
    bk.NAME bank_name,
    bb.CODE branchcode,
    bb.NAME branchname,
    b.RELATIONSHIP,
    COALESCE(p.computed_pen_arrears, 0),
    p.FREQ_EFFECTIVE_DATE
  from PENSIONERS p
    INNER JOIN BENEFICIARIES b on p.BENEFICIARY_ID = b.ID
    LEFT JOIN BANK_BRANCHES bb on b.BRANCH_ID=bb.ID
    LEFT JOIN banks bk on bb.BANK_ID=bk.ID
  where p.BENEFIT_ID=(select grp.BENEFITS_ID from V_GENERAL_REPORTS_PARAMS grp)
/

