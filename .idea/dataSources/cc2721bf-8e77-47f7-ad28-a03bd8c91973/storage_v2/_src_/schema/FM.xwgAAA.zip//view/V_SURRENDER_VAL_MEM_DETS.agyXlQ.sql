create view V_SURRENDER_VAL_MEM_DETS as
  select
    SCHEME_ID,
      (select reason from surrender_value_rpt) reasonforexit,
      (select name from sponsors where id = (select sponsor_id from companies where id = me.company_id and rownum=1)) sponsor,
    department_no,
      (select date_of_exit from surrender_value_rpt) date_of_exit,
    id_no,date_of_empl,  depot, sub_region, region_addr
    , (select surr.EXITAGE from surrender_value_rpt surr) age_at_exit,
    designation,
      (select normal from retirement_ages re where memberclass_id = me.mclass_id and re.gender = me.gender and rownum=1) retire_age_normal,
      add_months(dob, 12*(select normal from retirement_ages re where memberclass_id = me.mclass_id and re.gender = me.gender and rownum=1)) retire,
      DECODE(TITLE,'MR','Mr.', 'MRS', 'Mrs.', 'DR', 'Dr.', 'PROF', 'Prof.', 'REV', 'Rev.', 'ENG', 'Eng.', 'MISS', 'Ms.', '')||' '||me.FIRSTNAME||' '||me.SURNAME||' '||me.OTHER_NAMES name,
      me.MEMBER_NO member_no, me.DOB, me.DATE_JOINED_SCHEME, (to_char(current_date, 'yyyy')-to_char(dob,'yyyy'))age
  from members me where id = (select grp.MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS grp)
/

