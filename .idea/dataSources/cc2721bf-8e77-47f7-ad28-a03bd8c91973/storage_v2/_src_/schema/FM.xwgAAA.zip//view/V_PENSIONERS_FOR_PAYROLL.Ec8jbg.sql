create view V_PENSIONERS_FOR_PAYROLL as
  select p.ID,
    (case when p.BENEFICIARY_ID is not null then (select mem.MEMBER_NO from MEMBERS mem where mem.id=(select benf.member_id from beneficiaries benf where benf.ID=p.BENEFICIARY_ID)) else m.MEMBER_NO end)memberNo,
    (case when p.BENEFICIARY_ID is not null then ben.FIRSTNAME||' '||ben.OTHERNAMES ELSE mb.FIRSTNAME||' '||mb.SURNAME||' '||mb.OTHER_NAMES END) name,
    (case when p.BENEFICIARY_ID is not null then ben.DOB ELSE mb.DOB END) dob,
    p.PENSION_NO,p.ACCOUNT_NAME,p.PENSION_START_DATE,p.BRANCH_ID,p.ACCOUNT_NO,
    (case when p.BENEFICIARY_ID is not null and p.PIN_NUMBER is NULL then ben.TAX_PIN when p.MEMBER_ID is not null and p.PIN_NUMBER is NULL and mb.PIN is not null then mb.PIN when p.MEMBER_ID is not null and p.PIN_NUMBER is NULL and mb.PIN is null then m.PIN else p.PIN_NUMBER end) tax_pin, coalesce(p.MONTHLY_PENSION, 0), coalesce(p.MONTHLY_PENSION2, 0), p.PENSION_STATUS, p.PENSIONER_TYPE from pensioners p
    LEFT JOIN MEMBERS m on p.MEMBER_ID=m.ID left JOIN MEMBERS_BIOS mb on m.MEMBERBIO_ID = mb.ID
    LEFT JOIN beneficiaries ben on p.BENEFICIARY_ID=ben.ID where p.SCHEME_ID=(select SCHEME_ID from V_GENERAL_REPORTS_PARAMS)
                                                                 and p.DELETED=0 and p.APPROVED='YES' and p.PENSION_STATUS in ('ACTIVE', 'SUSPENDED')
  ORDER BY PENSION_START_DATE ASC
/

