create view V_MEMBER_DETAILS as
  SELECT m.ID,
    m.MEMBER_NO,
    mb.FIRSTNAME,
    mb.SURNAME,
    mb.OTHER_NAMES,
    mb.SURNAME || ' ' || mb.FIRSTNAME || ' ' || mb.OTHER_NAMES full_names,
    mb.GENDER,
    m.MBSHIP_STATUS,
    NVL (m.ID_NO, mb.ID_NO) ID_NO,
    mb.MARTL_STATUS,
    m.APPROVED,
    m.MEMBERBIO_ID,
    m.PARTYREF_NO,
    m.MCLASS_ID,
    m.SCHEME_ID,
    m.CELL_PHONE,
    m.EMAIL,
    m.POSTAL_ADDRESS,
    NVL (mb.dob, mb.dob) dob,
    m.DATE_JOINED_SCHEME,
    m.DATE_OF_EMPL,
    m.DATES_CONFIRMED,
    m.DEPARTMENT_NO,
    m.DESIGNATION,
    m.GRADE,
    m.PAYROLL_NO,
    m.PIN,
    m.COMPANY_ID,
    m.JOBGRADE_ID,
    m.EXIT_ID,
    m.DEPOT,
    NVL (m.REGION_ADDR, mb.REGION_ADDR) REGION_ADDR,
    m.SUB_REGION,
    m.RESIDENTIAL_ADDRESS,
    FLOOR ( (SYSDATE - NVL (mb.dob, mb.dob)) / 365) current_age,
    (  FLOOR (
           DECODE (
               MOD (
                   FLOOR ( (SYSDATE - NVL (mb.dob, mb.dob)) / 365),
                   10),
               0,   FLOOR ( (SYSDATE - NVL (mb.dob, mb.dob)) / 365)
                    - 1,
               FLOOR ( (SYSDATE - NVL (mb.dob, mb.dob)) / 365))
           / 10)
       * 10)
    + 1
    || '-'
    || CEIL (FLOOR ( (SYSDATE - NVL (mb.dob, mb.dob)) / 365) / 10) * 10
                                                               CURRENT_AGE_band,
    mc.name member_class_name,
    ra.EARLY EARLY_ret_ages,
    NVL (mb.dob, mb.dob) + (ra.EARLY * 365) EARLY_ret_date,
    ra.EARLY_UNEMPLOYED EARLY_UNEMPLOYED_ret_ages,
    NVL (mb.dob, mb.dob) + (ra.EARLY_UNEMPLOYED * 365)
                                                               EARLY_UNEMPLOYED_ret_date,
    ra.NORMAL NORMAL_ret_ages,
    NVL (mb.dob, mb.dob) + (ra.NORMAL * 365) NORMAL_ret_date,
    ra.LATE LATE_ret_ages,
    NVL (mb.dob, mb.dob) + (ra.LATE * 365) LATE_ret_date,
    co.NAME company_name,
    sp.NAME sponsor_name,
    m.POLICY_NO
  FROM members m
    LEFT JOIN MEMBERS_BIOS mb ON m.MEMBERBIO_ID = mb.ID
    LEFT JOIN MEMBER_CLASSES mc ON m.MCLASS_ID = mc.ID
    LEFT JOIN RETIREMENT_AGES ra ON m.MCLASS_ID = ra.MEMBERCLASS_ID AND m.GENDER = ra.GENDER
    LEFT JOIN COMPANIES co ON m.COMPANY_ID = co.ID
    LEFT JOIN SPONSORS sp ON co.SPONSOR_ID = sp.ID
/

