create view V_INV_PVS_TOTALHOLDING as
  select sum(holding)total from V_INV_PVS_HOLDINGPERINV
/

