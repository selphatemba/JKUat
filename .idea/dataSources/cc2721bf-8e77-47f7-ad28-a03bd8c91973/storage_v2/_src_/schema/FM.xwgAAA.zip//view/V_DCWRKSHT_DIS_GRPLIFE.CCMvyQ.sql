create view V_DCWRKSHT_DIS_GRPLIFE as
  SELECT
    b.ID,
    m.SCHEME_ID,
    b.GROUP_LIFE_DATE,
    b.GRP_LIFE_AMOUNT,
    b.TOT_GLLIAB as tax,
    b.NET_GROUPLIFE_AMOUNT,
    b.group_life_processed is_processed,
    b.grp_life_payment_process date_processed,
    prep.FIRSTNAME||' '||prep.OTHERNAMES preparer,
    cert.FIRSTNAME||' '||cert.OTHERNAMES certifier,
    app.FIRSTNAME||' '||app.OTHERNAMES approver,
    b.DATE_PREPARED_GRPLF,
    b.DATE_CERTIFIED_GRPLF,
    b.DATE_APPROVED_GRPLF
  FROM BENEFITS b INNER JOIN MEMBERS m ON b.ID = m.EXIT_ID
    LEFT JOIN USERS prep on b.PREPAREDBYGRPLF_ID = prep.ID
    LEFT JOIN USERS cert on b.CERTIFIEDBYGRPLF_ID = cert.ID
    LEFT JOIN USERS app on b.APPROVEDBYGRPLF_ID= app.ID
  where m.ID=(select grp.MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS grp) and b.ID=(select grp.BENEFITS_ID from V_GENERAL_REPORTS_PARAMS grp) and b.GRP_LIFE_AMOUNT>0 and ROWNUM=1 and m.SCHEME_ID=(select SCHEME_ID from V_GENERAL_REPORTS_PARAMS)
/

