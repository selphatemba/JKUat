create view V_PAYVOUCH_APP_ACCOUNTS as
  SELECT scheme_id, code, name, id, particulars, debit, credit from payment_voucher_accounts ORDER BY id ASC
/

