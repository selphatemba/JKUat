create view V_GENERAL_SCHEME_DETAILS as
  select sc.ID scheme_id, scheme_name, fax, email, building, fixed_phone ,postal_address||', '||TOWN||', '||COUNTRY postal_address, road, country, website, SCHEMEPIN  from schemes sc where id = (select grp.SCHEME_ID from GENERAL_REPORTS_PARAMS grp)
/

