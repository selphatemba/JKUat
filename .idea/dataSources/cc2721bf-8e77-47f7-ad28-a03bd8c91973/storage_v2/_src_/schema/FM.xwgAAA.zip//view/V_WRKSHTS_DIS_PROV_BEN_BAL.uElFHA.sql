create view V_WRKSHTS_DIS_PROV_BEN_BAL as
  with params as (
      select (select grp.MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS grp) member_id from dual
  )
  SELECT
    (select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) SCHEME_ID,
    (select date_of_exit from benefits where id = (select exit_id from members where to_char(id)= par.member_id)) asat,
    (select coalesce(DEFFERED_EE,0) + coalesce(DEFFERED_REG,0)+ coalesce(DEFERED_UNREG,0) from benefits where id = (select exit_id from members where to_char(id) = par.member_id)) deferred_,
    ID,
    0 transfer,
    coalesce(AVC, 0) AVC_CONTR,
    coalesce(AVC_BAL, 0)AVC_BAL,
    coalesce(AVC_BAL_INTR, 0)AVC_BALINTR,
    coalesce(AVC_INTR, 0)AVC_INTR,
    coalesce(AVCER, 0) AVCER_CONTR,
    coalesce(AVCER_BAL, 0)AVCER_BAL,
    coalesce(AVCER_BAL_INTR, 0)AVCER_BALINTR,
    coalesce(AVCER_INTR, 0)AVCER_INTR,
    coalesce(EE, 0) EE_CONTR,
    coalesce(EE_BAL, 0)EE_BAL,
    coalesce(EE_BAL_INTR, 0) EE_BALINTR,
    coalesce(EE_INTR, 0)EE_INTR,
    coalesce(ER, 0) ER_CONTR,
    coalesce(ER_BAL, 0)ER_BAL,
    coalesce(ER_BAL_INTR, 0)ER_BALINTR,
    coalesce(ER_INTR, 0)ER_INTR
  FROM PROV_BEN_BAL pro, params par
  where id = (select REGBAL_ID from benefits where id = (select exit_id from members m, params p where to_char(m.id) = p.member_id))
/

