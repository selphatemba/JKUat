create view V_WRKSHTS_DIS_MEMBER_BALS as
  with params as (
    select  (SELECT grp.MEMBER_ID_FROM FROM V_GENERAL_REPORTS_PARAMS grp) member_id from dual
)
SELECT
  (SELECT grp.SCHEME_ID FROM V_GENERAL_REPORTS_PARAMS grp) SCHEME_ID,
  sum(coalesce(0, 0)) transfer,
  sum(coalesce(AVC, 0)) AVC_CONTR,
  sum(coalesce(AVC_BAL, 0))AVC_BAL,
  sum(coalesce(AVC_BAL_INTR, 0))AVC_BALINTR,
  sum(coalesce(AVC_INTR, 0))AVC_INTR,
  sum(coalesce(AVCER, 0)) AVCER_CONTR,
  sum(coalesce(AVCER_BAL, 0))AVCER_BAL,
  sum(coalesce(AVCER_BAL_INTR, 0))AVCER_BALINTR,
  sum(coalesce(AVCER_INTR, 0))AVCER_INTR,
  sum(coalesce(EE, 0)) EE_CONTR,
  sum(coalesce(EE_BAL, 0))EE_BAL,
  sum(coalesce(EE_BAL_INTR, 0)) EE_BALINTR,
  sum(coalesce(EE_INTR, 0))EE_INTR,
  sum(coalesce(ER, 0)) ER_CONTR,
  sum(coalesce(ER_BAL, 0))ER_BAL,
  sum(coalesce(ER_BAL_INTR, 0))ER_BALINTR,
  sum(coalesce(ER_INTR, 0))ER_INTR,
  ( select PAY_MONTHLY_PENS_TOBEN from benefits where id = (select exit_id from members m, params p where to_char(m.id) = p.member_id)) payben,
  sum(coalesce(er_bal,0) + coalesce(ee_bal,0)) combined_bals
FROM PROV_BEN_BAL pro, params par
where id = (select REGBAL_ID from benefits where id = (select exit_id from members m, params p where to_char(m.id) = p.member_id))
      or
      id = (select UNREGBAL_ID from benefits where id = (select exit_id from members m, params p where to_char(m.id)= p.member_id))
group by par.member_id
/

