create view V_PROV_CONTRIBUTIONS as
  select (select SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) scheme_id, (select max(date_paid) from contributions where member_id=co.member_id) to_date,to_date(to_char(date_paid, 'Mon/yyyy'), 'Mon/yyyy') dated, to_char(date_paid, 'Mon/yyyy') month,
         max(salary) salary,
         sum(case when (co.status = 'UNREGISTERED' and co.type='TRANSFERS') then (co.ee)
             else (case when (co.status = 'UNREGISTERED' and co.type='NORMAL') then (co.ee)
                   else (case when (co.status = 'UNREGISTERED' and co.type='ARREARS') then (co.ee)
                         else 0 end) end)
             end) ee_unreg,
         sum(case when (co.status = 'REGISTERED' and co.type='TRANSFERS') then (co.ee)
             else (case when (co.status = 'REGISTERED' and co.type='NORMAL') then (co.ee)
                   else (case when (co.status = 'REGISTERED' and co.type='ARREARS') then (co.ee)
                         else 0 end)
                   end)
             end) ee_reg,
         sum(case when (co.status = 'UNREGISTERED' and co.type='ARREARS') then (0)
             else 0 end) ee_unreg_arrears,
         sum(case when (co.type='ARREARS') then (co.ee)
             else 0 end) ee_reg_arrears,
         sum(case when (co.status = 'UNREGISTERED' and co.type='TRANSFERS') then co.ee
             else 0 end) ee_unreg_trans,
         sum(case when (co.status = 'REGISTERED' and co.type='TRANSFERS') then (co.ee)
             else 0 end) ee_reg_trans,
         sum(case when (co.status = 'UNREGISTERED' and co.type='NORMAL') then co.er
             else (case when (co.status = 'UNREGISTERED' and co.type='TRANSFERS') then (co.er)
                   else (case when (co.status = 'UNREGISTERED' and co.type='ARREARS') then (co.er)
                         else 0 end)
                   end)
             end) er_unreg,
         sum(case when (co.status = 'REGISTERED' and co.type='NORMAL') then co.er
             else (case when (co.status = 'REGISTERED' and co.type='TRANSFERS') then (co.er)
                   else (case when (co.status = 'REGISTERED' and co.type='ARREARS') then (co.er)
                         else 0 end)
                   end)
             end) er_reg,
         sum(case when (co.status = 'UNREGISTERED' and type='ARREARS') then (co.er)
             else 0 end) er_unreg_arrears,
         sum(case when (co.type='ARREARS') then (co.er)
             else 0 end) er_reg_arrears,
         sum( case when (co.status = 'UNREGISTERED' and type='TRANSFERS') then (co.er)
              else 0 end) er_unreg_trans,
         sum(case when (co.status = 'REGISTERED' and co.type='TRANSFERS') then (co.er)
             else 0 end) er_reg_trans,
         sum(case when (co.status='REGISTERED' and co.type='TRANSFERS') then (co.avc)
             else 0 end) avc_reg_trans,
         sum(case when (co.status='UNREGISTERED' and co.type='TRANSFERS') then (co.avc)
             else 0 end) avc_unreg_trans,
         sum(case when (co.status = 'UNREGISTERED' and co.type='NORMAL') then co.avc
             else (case when (co.status = 'UNREGISTERED' and co.type='TRANSFERS') then (co.avc)
                   else (case when (co.status = 'UNREGISTERED' and co.type='ARREARS') then (co.avc)
                         else 0 end)
                   end)
             end) avc_unreg,
         sum(case when (co.status = 'REGISTERED' and co.type='NORMAL') then (co.avc)
             else (case when (co.status = 'REGISTERED' and co.type='TRANSFERS') then (co.avc)
                   else (case when (co.status = 'REGISTERED' and co.type='ARREARS') then (co.avc)
                         else 0 end)
                   end)
             end) avc_reg,
         sum(case when (co.status = 'UNREGISTERED' and co.type='NORMAL') then co.avcer
             else (case when (co.status = 'UREGISTERED' and co.type='TRANSFERS') then (co.avcer)
                   else (case when (co.status = 'UREGISTERED' and co.type='ARREARS') then (co.avcer)
                         else 0 end)
                   end)
             end) avcer_unreg,
         sum(case when (co.status = 'REGISTERED' and co.type='NORMAL') then (co.avcer)
             else (case when (co.status = 'REGISTERED' and co.type='TRANSFERS') then (co.avcer)
                   else (case when (co.status = 'REGISTERED' and co.type='ARREARS') then (co.avcer)
                         else 0 end)
                   end)
             end) avcer_reg,
         (select sum(coalesce(ee_intr,0)+coalesce(ee_balintr,0)+coalesce(ee_withdr_intr,0)) from closing_balances ci where member_id=(select MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS grp)  and ap_id=(select AP_ID from V_GENERAL_REPORTS_PARAMS grp) ) ee_intr,
         (select sum(coalesce(er_intr,0)+coalesce(er_balintr,0)+coalesce(er_withdr_intr,0)) from closing_balances ci where member_id=(select MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS grp) and ap_id=(select AP_ID from V_GENERAL_REPORTS_PARAMS grp) ) er_intr,
         (select sum(coalesce(avcer_intr,0)+coalesce(avcer_balintr,0)+coalesce(avc_intr,0)+coalesce(avc_balintr,0)+coalesce(avc_withdr_intr,0)+coalesce(avcer_withdr_intr,0)) from closing_balances ci where member_id=(select MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS grp) and ap_id=(select AP_ID from V_GENERAL_REPORTS_PARAMS grp) ) avc_intr,
         (select count(*) from contributions ci where member_id= (select MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS grp)  and ci.date_paid between (select from_date from accounting_periods where id = (select AP_ID from V_GENERAL_REPORTS_PARAMS grp) ) and (select to_date from accounting_periods where id = (select AP_ID from V_GENERAL_REPORTS_PARAMS grp) )) counter
  from contributions co where member_id= (select MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS grp) and co.date_paid between (select from_date from accounting_periods where id = (select AP_ID from V_GENERAL_REPORTS_PARAMS grp) ) and (select to_date from accounting_periods where id = (select AP_ID from V_GENERAL_REPORTS_PARAMS grp))
  group by member_id,to_date(to_char(date_paid, 'Mon/yyyy'), 'Mon/yyyy'), to_char(date_paid, 'Mon/yyyy') order by to_date(to_char(date_paid, 'Mon/yyyy'), 'Mon/yyyy') desc
/

