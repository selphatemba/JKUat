create view V_AR_MEMBERS_AGE_PROFILE as
  WITH GAP AS (
    SELECT 10 AS GAP, (SELECT DATE_TO FROM V_AR_PARAMS)DATE_TO, (SELECT SCHEME_ID FROM V_AR_PARAMS) SCHEME_ID,18 MIN_AGE,100 MAX_AGE,'ALL' GENDER, 'ACTIVE' STATUS FROM DUAL
),
    DETS AS (
      SELECT SUM(GAP.GAP) OVER(PARTITION BY GAP.GAP ORDER BY ID) CUM_AGE FROM MEMBERS M, GAP WHERE M.SCHEME_ID = GAP.SCHEME_ID  GROUP BY ID, GAP.GAP
  ), acpd as(
    select max(ap_id) apid from  closing_balances where ap_id in (select id from ACCOUNTING_PERIODS ap, gap where ap.scheme_id = gap.SCHEME_ID)
), tabo as (
    SELECT DATE_TO, SCHEME_ID, CUM_AGE-gap s_age, (CUM_AGE-GAP.GAP+1)||'-'||CUM_AGE AS RANGE,
            (select count(distinct(mhs.member_id)) from members_status_history mhs
              inner join members M on M.id = mhs.member_id
            where
              mhs.status_change_date <= DATE_TO
              and
              status_change_date = (select max(status_change_date) from members_status_history where member_id = M.id and rownum = 1)
              and
              mhs.status_after = GAP.STATUS  and M.approved = 'YES' AND EXTRACT(YEAR FROM CURRENT_DATE)-EXTRACT(YEAR FROM M.DOB) BETWEEN (CUM_AGE+1-GAP.GAP) AND CUM_AGE AND M.SCHEME_ID = (SELECT SCHEME_ID FROM GAP)) COUNT,
            (SELECT SUM(NVL(CUR_PENS_SAL,0)) FROM MEMBERS M WHERE  (M.MBSHIP_STATUS = GAP.STATUS ) AND EXTRACT(YEAR FROM CURRENT_DATE)-EXTRACT(YEAR FROM M.DOB) BETWEEN (CUM_AGE+1-GAP.GAP) AND CUM_AGE AND SCHEME_ID = (SELECT SCHEME_ID FROM GAP)) SALARY_TOTAL,
            ((SELECT SUM(NVL(CUR_PENS_SAL,0)) FROM MEMBERS M WHERE (M.MBSHIP_STATUS = GAP.STATUS ) AND EXTRACT(YEAR FROM CURRENT_DATE)-EXTRACT(YEAR FROM M.DOB) BETWEEN (CUM_AGE+1-GAP.GAP) AND CUM_AGE AND SCHEME_ID = (SELECT SCHEME_ID FROM GAP))/(SELECT COUNT(*) FROM MEMBERS M WHERE EXTRACT(YEAR FROM CURRENT_DATE)-EXTRACT(YEAR FROM M.DOB) BETWEEN (CUM_AGE+1-GAP.GAP) AND CUM_AGE AND SCHEME_ID = (SELECT SCHEME_ID FROM GAP))) AVG_ANNUAL_PEN_SAL,
            (SELECT
               SUM(coalesce(EE_BAL,0))+SUM(coalesce(EE_BALINTR,0)) +SUM(coalesce(EE_INTR,0))+SUM(coalesce(EE_CONTR,0))+SUM(coalesce(EE_WITHDR_INTR,0))-SUM(coalesce(EE_WITHDR,0))
               +
               SUM(coalesce(ER_BAL,0))+SUM(coalesce(ER_BALINTR,0)) +SUM(coalesce(ER_INTR,0))+SUM(coalesce(ER_CONTR,0))+SUM(coalesce(ER_WITHDR_INTR,0))-SUM(coalesce(ER_WITHDR,0))
               +
               SUM(NVL(AVC_BAL,0))+SUM(coalesce(AVC_BALINTR,0)) +SUM(coalesce(AVC_INTR,0))+SUM(coalesce(AVC_CONTR,0))+SUM(coalesce(AVC_WITHDR_INTR,0))-SUM(coalesce(AVC_WITHDR,0))
               +
               SUM(NVL(AVCER_BAL,0))+SUM(coalesce(AVCER_BALINTR,0)) +SUM(coalesce(AVCER_INTR,0))+SUM(coalesce(AVCER_CONTR,0))+SUM(coalesce(AVCER_WITHDR_INTR,0))-SUM(coalesce(AVCER_WITHDR,0))
             FROM CLOSING_BALANCES, acpd WHERE ap_id = acpd.apid and MEMBER_ID IN (SELECT ID FROM MEMBERS M WHERE (M.MBSHIP_STATUS = GAP.STATUS) AND EXTRACT(YEAR FROM CURRENT_DATE)-EXTRACT(YEAR FROM M.DOB) BETWEEN (CUM_AGE+1-GAP.GAP) AND CUM_AGE AND SCHEME_ID = (SELECT SCHEME_ID FROM GAP))) RET_BALS FROM DETS,GAP WHERE CUM_AGE BETWEEN MIN_AGE+GAP.GAP AND MAX_AGE), tabo2 as(select t.*, (select sum(coalesce(count,0)) from tabo) smt, round((count/(select sum(coalesce(count,0)) from tabo)) * 100, 2) perc  from tabo t
) select t2."DATE_TO",t2."SCHEME_ID",t2."S_AGE",t2."RANGE",t2."COUNT",t2."SALARY_TOTAL",t2."AVG_ANNUAL_PEN_SAL",t2."RET_BALS",t2."SMT",t2."PERC", (select max(perc) from tabo2) highestperc, (select range from tabo2 where perc = (select max(perc) from tabo2)) rng, (select sum(perc) from tabo2 where s_age>=50) earlyrt from tabo2 t2
/

