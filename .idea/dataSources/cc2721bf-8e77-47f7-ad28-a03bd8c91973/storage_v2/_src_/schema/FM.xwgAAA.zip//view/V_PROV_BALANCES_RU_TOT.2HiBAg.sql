create view V_PROV_BALANCES_RU_TOT as
  with pa1 as (
      select (SELECT MEMBER_ID_FROM FROM V_GENERAL_REPORTS_PARAMS) member_id_p, (SELECT AP_ID FROM V_GENERAL_REPORTS_PARAMS) ap_id_p from dual
  ), pa0 as (
      select id from accounting_periods, pa1  p where  scheme_id=(select scheme_id from members where id = p.member_id_p) and from_date<(select from_date from accounting_periods where id = p.ap_id_p)  and period_type=(select period_type from accounting_periods where id = p.ap_id_p ) order by from_date desc
  ),pa2 as(
      select id prev_ap from pa0 where rownum=1
  )
  SELECT
    sum(coalesce( (select AVCER_BAL+avcer_contr+avcer_intr+avcer_balintr from closing_balances ci, pa2 where status=co.status and member_id=co.member_id and ap_id=pa2.prev_ap),0)) AVCER_BAL,
    sum(coalesce((select ER_BAL+er_contr+er_intr+er_balintr from closing_balances ci, pa2 where status=co.status and member_id=co.member_id and ap_id=pa2.prev_ap),0)) ER_BAL,
    sum(coalesce(co.PRE_EMPLOYER_BAL,0)) PRE_EMPLOYER_BAL,
    sum(coalesce(co.ER_BALINTR,0)) ER_BALINTR,
    sum(coalesce(co.AVCER_BALINTR,0)) AVCER_BALINTR,
    sum(coalesce((select PRE_EMPLOYER_BAL from closing_balances ci, pa2 where status=co.status and member_id=co.member_id and ap_id=pa2.prev_ap and rownum=1),0) ) PRE_EMPLOYEE_BAL,
    sum(coalesce((select DEFICIT_BAL from closing_balances ci, pa2 where status=co.status and member_id=co.member_id and ap_id=pa2.prev_ap and rownum=1),0) ) DEFICIT_BAL,
    sum(coalesce((select EE_BAL+ee_contr+ee_intr+ee_balintr from closing_balances ci, pa2 where status=co.status and member_id=co.member_id and ap_id=pa2.prev_ap),0)) EE_BAL,
    sum(coalesce(co.EE_BALINTR,0)) EE_BALINTR,
    sum(coalesce(co.AVC_BALINTR,0)) AVC_BALINTR,
    sum(coalesce((select AVC_BAL+avc_contr+avc_intr+avc_balintr from closing_balances ci, pa2 where status=co.status and member_id=co.member_id and ap_id=pa2.prev_ap),0)) AVC_BAL,
    sum(coalesce(co.ER_INTR,0)) ER_INTR,
    sum(coalesce(co.ER_CONTR,0)) ER_CONTR,
    sum(coalesce(co.ER_WITHDR_INTR,0)) ER_WITHDR_INTR,
    sum(coalesce(co.ER_WITHDR,0)) ER_WITHDR,
    sum(coalesce(co.AVCER_INTR,0)) AVCER_INTR,
    sum(coalesce(co.AVCER_CONTR,0)) AVCER_CONTR,
    sum(coalesce(co.AVCER_WITHDR_INTR,0)) AVCER_WITHDR_INTR,
    sum(coalesce(co.AVCER_WITHDR,0)) AVCER_WITHDR,
    sum(coalesce(co.PRE_ADD_VOL_CONT,0)) PRE_ADD_VOL_CONT,
    sum(coalesce(co.DEFFERED,0)) DEFFERED,
    sum(coalesce(co.TRANSFER,0)) TRANSFER,
    sum(coalesce(co.EE_INTR,0)) EE_INTR,
    sum(coalesce(co.EE_CONTR,0)) EE_CONTR,
    sum(coalesce(co.EE_WITHDR_INTR,0)) EE_WITHDR_INTR,
    sum(coalesce(co.EE_WITHDR,0)) EE_WITHDR,
    sum(coalesce(co.AVC_WITHDR,0)) AVC_WITHDR,
    sum(coalesce(co.AVC_INTR,0)) AVC_INTR,
    sum(coalesce(co.AVC_CONTR,0)) AVC_CONTR,
    sum(coalesce(co.AVC_WITHDR_INTR,0)) AVC_WITHDR_INTR,
    sum(coalesce(co.RESERVE_INCOME,0)) RESERVE_INCOME,
    sum(coalesce(co.TAX,0)) TAX, SUM((SELECT SCHEME_ID FROM V_GENERAL_REPORTS_PARAMS)/2) SCHEME_ID
  FROM CLOSING_BALANCES co, pa1 po where member_id = po.member_id_p and ap_id = case when po.ap_id_p is null then (select prev_ap from pa2) else (select prev_ap from pa2) end
/

