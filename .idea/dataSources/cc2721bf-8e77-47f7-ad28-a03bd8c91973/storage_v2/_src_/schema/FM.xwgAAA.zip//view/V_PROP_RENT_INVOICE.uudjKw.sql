create view V_PROP_RENT_INVOICE as
  select
    DISTINCT ri.ID as ag_id,
             invest.SCHEME_ID AS SCHEME_ID,
             coalesce(ri.AMOUNT_BOOKED, 0)AMOUNT_BOOKED,
             coalesce(ri.BALANCE, 0)BALANCE,
    ri.DATE_BOOKED,
    ri.MONTH,
    ri.YEAR,
    ri.PROPERTY_ID,
    ri.PREPARED_DATE,
    ri.PREPAREDBY_ID,
    ri.PENALTY,
             COALESCE(tax.RATE, 0) as vat_rate,
    ag.END_DATE,
    ag.FREQUENCY,
    ag.MONTHLY_RENT,
             coalesce(ag.RENTPAYABLE, 0)RENTPAYABLE,
             coalesce(ag.SERVICE_CHARGE, 0)SERVICE_CHARGE,
    ag.START_DATE,
    ag.STATUS,
    ag.TENANT_TYPE,
    ag.TENANT_ID,
    ag.ESCALATION_RATE,
             coalesce(ag.PARKING_FEE, 0)PARKING_FEE,
    ag.SERVICE_CHARGE_DETS,
    invest.NAME,
    un.UNIT_NO,
    un.DESCRIPTION,
    tn.BUILDING,
    tn.CELL_PHONE,
    tn.POSTAL_ADDRESS,
    tn.COUNTRY,
    tn.EMAIL,
    tn.TOWN,
             tn.NAME as tenant_name,
             prep.FIRSTNAME||' '||prep.OTHERNAMES as PREPARER,
             ri.PREPARED_DATE DATE_PREPARED,
             cert.FIRSTNAME||' '||cert.OTHERNAMES as CERTIFIER,
             invtxns.CERTIFIED_DATE DATE_CERTIFIED,
             app.FIRSTNAME||' '||app.OTHERNAMES as APPROVER,
             invtxns.APPROVED_DATE DATE_APPROVED,
    curr.CODE currency
  FROM RENT_INVOICES ri
    INNER JOIN TEN_AGRMNTS ag ON ri.CONTRACT_ID=ag.ID
    INNER JOIN TEN_AGRMNTS_UNITS tau ON ag.ID=tau.TEN_AGRMNTS_ID
    LEFT JOIN ACC_TAX_RATES tax ON ag.VAT_ID = tax.ID
    LEFT JOIN INVESTMENTS invest ON ri.PROPERTY_ID = invest.ID
    left jOIN UNITS un ON tau.UNITS_ID=un.ID
    left JOIN TENANTS tn ON ag.TENANT_ID = tn.ID
    left JOIN INVESTMENT_TXNS invtxns ON ag.ID = invtxns.CONTRACT_ID
    LEFT JOIN USERS prep ON ri.PREPAREDBY_ID = prep.ID
    LEFT JOIN USERS cert ON invtxns.CERTIFIEDBY_ID = cert.ID
    LEFT JOIN USERS app ON invtxns.APPROVEDBY_ID = app.ID
    LEFT JOIN CURRENCIES curr on invest.CURRENCY_ID = curr.ID
  where ri.ID BETWEEN (select grp.invoice_id_from from V_GENERAL_REPORTS_PARAMS grp)
        and (select grp.invoice_id_to from V_GENERAL_REPORTS_PARAMS grp) and ag.SCHEME_ID=(select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp)
/

