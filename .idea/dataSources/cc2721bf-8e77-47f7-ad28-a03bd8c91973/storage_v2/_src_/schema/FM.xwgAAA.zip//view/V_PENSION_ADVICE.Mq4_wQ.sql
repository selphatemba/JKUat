create view V_PENSION_ADVICE as
  with params as(
      select (select pensioner_id from V_GENERAL_REPORTS_PARAMS grp) id_prm from dual
  )select "SCHEME_ID","DATED","TO_DATE","FROM_DATE","ID","ACCOUNT_NO","ARREAS","BANKBRANCH_ID","CLEARED","DATE_PREPARED","DEDS","GROSS","MONTH","NET","PAID","PAY_TYPE","PENSION_STATUS","PREVIOUS","TAX","YEAR","PENSIONER_ID","TAX_ON_ARREAS","PREPAREDBY_ID","TYPE","MONTH_YEAR","BRANCH_NAME","BANK_NAME" from(
    select
      (select SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) scheme_id,
      to_date(01||'-'||p.month||'-'||p.year) dated,
      (select max(to_date(01||'-'||p.month||'-'||p.year)) from payroll where p.pensioner_id = p.pensioner_id and year = p.year) to_date,
      (select min(to_date(01||'-'||p.month||'-'||p.year)) from payroll where p.pensioner_id = p.pensioner_id and year = p.year) from_date,
      p.ID, p.ACCOUNT_NO, p.ARREAS, p.BANKBRANCH_ID, p.CLEARED, p.DATE_PREPARED, p.DEDS, p.GROSS, p.MONTH, p.NET, p.PAID, p.PAY_TYPE, p.PENSION_STATUS, p.PREVIOUS, p.TAX, p.YEAR, p.PENSIONER_ID, TAX_ON_ARREAS, p.PREPAREDBY_ID, p.TYPE,
      p.MONTH||'/'||p.YEAR month_year, bb.NAME branch_name, b.NAME bank_name
    from PAYROLL p
      LEFT JOIN BANK_BRANCHES bb ON p.BANKBRANCH_ID = bb.ID
      LEFT JOIN BANKS b ON bb.BANK_ID = b.ID,
      params a where PENSIONER_ID = a.id_prm AND p.TYPE='NORMAL'--and p.PENSION_STATUS='ACTIVE'
                     and p.YEAR=(select grp.YEAR from V_GENERAL_REPORTS_PARAMS grp) ORDER BY DATED ASC
  )ORDER BY dated asc
/

