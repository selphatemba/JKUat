create view V_NET_PAYROLL_FOOTER as
  SELECT pb.SCHEME_ID scheme_id, (p.FIRSTNAME ||' '||p.OTHERNAMES) preparer, pb.DATE_PREPARED date_prepared,
         (c.FIRSTNAME ||' '||c.OTHERNAMES) checker, pb.DATE_CHECKED date_checked,
         (a.FIRSTNAME ||' '||a.OTHERNAMES) authorizer, pb.DATE_AUTHORIZED date_authorized
  FROM PAYROLL_BATCHES pb
    LEFT JOIN USERS p ON pb.PREPAREDBY_ID = p.ID
    LEFT JOIN USERS c ON pb.CHECKEDBY_ID = c.ID
    LEFT JOIN USERS a ON pb.AUTHORIZEDBY_ID = a.ID
  WHERE MONTH=(select MONTH from V_NET_PAYROLL_PARAMS) AND YEAR=(select YEAR from V_NET_PAYROLL_PARAMS) AND pb.SCHEME_ID=(select scheme_id from V_NET_PAYROLL_PARAMS)
/

