create view V_ACC_BANK_REC_BALS_AND_ADJUST as
  select
      --BANK BAL
      case when (select coalesce(br.BANK_BAL, 0) from BANK_RECONCILIATION br where br.id=(select grp.BANK_RECON_ID from V_GENERAL_REPORTS_PARAMS grp))<0
        then (select coalesce(br.BANK_BAL, 0) from BANK_RECONCILIATION br where br.id=(select grp.BANK_RECON_ID from V_GENERAL_REPORTS_PARAMS grp))*(-1)
      else NULL end crbank_bal,
      case when (select coalesce(br.BANK_BAL, 0) from BANK_RECONCILIATION br where br.id=(select grp.BANK_RECON_ID from V_GENERAL_REPORTS_PARAMS grp))>=0
        then (select coalesce(br.BANK_BAL, 0) from BANK_RECONCILIATION br where br.id=(select grp.BANK_RECON_ID from V_GENERAL_REPORTS_PARAMS grp))*(1)
      else NULL end drbank_bal,
      --CASHBOOK BAL
      case when (select coalesce(br.CB_BAL, 0) from BANK_RECONCILIATION br where br.id=(select grp.BANK_RECON_ID from V_GENERAL_REPORTS_PARAMS grp))<0
        then (select coalesce(br.CB_BAL, 0) from BANK_RECONCILIATION br where br.id=(select grp.BANK_RECON_ID from V_GENERAL_REPORTS_PARAMS grp))*(-1)
      else NULL end crcashbook_bal,
      case when (select coalesce(br.CB_BAL, 0) from BANK_RECONCILIATION br where br.id=(select grp.BANK_RECON_ID from V_GENERAL_REPORTS_PARAMS grp))>=0
        then (select coalesce(br.CB_BAL, 0) from BANK_RECONCILIATION br where br.id=(select grp.BANK_RECON_ID from V_GENERAL_REPORTS_PARAMS grp))*(1)
      else NULL end drcashbook_bal,
      --ADD UPRESENTED CHEQUES - ADJUSTMENTS
      ((select coalesce(br.CB_BAL, 0) from BANK_RECONCILIATION br where br.id=(select grp.BANK_RECON_ID from V_GENERAL_REPORTS_PARAMS grp))+
       ((select unpres_chq_total from V_ACC_UNPRESCHQTOTAL)+(select ucptotal from V_ACC_SUM_UNPRE_CHQ_FRM_PMT))) ADJUSTED_CB,
      case when ((select coalesce(br.CB_BAL, 0) from BANK_RECONCILIATION br where br.id=(select grp.BANK_RECON_ID from V_GENERAL_REPORTS_PARAMS grp))+
                 ((select unpres_chq_total from V_ACC_UNPRESCHQTOTAL)+(select ucptotal from V_ACC_SUM_UNPRE_CHQ_FRM_PMT)))<0
        then ((select coalesce(br.CB_BAL, 0) from BANK_RECONCILIATION br where br.id=(select grp.BANK_RECON_ID from V_GENERAL_REPORTS_PARAMS grp))+
              ((select unpres_chq_total from V_ACC_UNPRESCHQTOTAL)+(select ucptotal from V_ACC_SUM_UNPRE_CHQ_FRM_PMT)))*(-1)
      else NULL end cradjustedcashbook_bal,
      case when ((select coalesce(br.CB_BAL, 0) from BANK_RECONCILIATION br where br.id=(select grp.BANK_RECON_ID from V_GENERAL_REPORTS_PARAMS grp))+
                 ((select unpres_chq_total from V_ACC_UNPRESCHQTOTAL)+(select ucptotal from V_ACC_SUM_UNPRE_CHQ_FRM_PMT)))>=0
        then ((select coalesce(br.CB_BAL, 0) from BANK_RECONCILIATION br where br.id=(select grp.BANK_RECON_ID from V_GENERAL_REPORTS_PARAMS grp))+
              ((select unpres_chq_total from V_ACC_UNPRESCHQTOTAL)+(select ucptotal from V_ACC_SUM_UNPRE_CHQ_FRM_PMT)))*(1)
      else NULL end dradjustedcashbook_bal
    from dual
/

