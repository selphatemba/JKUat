create view V_INV_TXNS_EQUITIES as
  select
    tx.ID,
    tx.SCHEME_ID,
    lc.CODE company_code,
    lc.NAME company_name,
    i.NAME inv_name,
    rpt.AMOUNT,
    rpt.CONTRACTNOTE,
    rpt.DEALDATE,
    rpt.FUNDMANAGER,
    rpt.POSTED,
    rpt.PRICEPERSHARE,
    rpt.SHARESBOUGHT,
    rpt.SHARESONSPLIT,
    rpt.SHARESSOLD,
    rpt.BONUSSHARES,
    rpt.TXNTYPE,
    rpt.TXN_ID,
    tx.PARTICULARS,
    lc.NAME blank1,
    lc.NAME blank2,
    lc.NAME blank3,
    lc.NAME blank4,
    lc.NAME blank5,
    lc.NAME blank6,
    lc.NAME blank7
  from equity_txns_rpt rpt
    INNER JOIN INVESTMENT_TXNS tx on rpt.TXN_ID=tx.ID
    INNER JOIN INVESTMENTS i on tx.INVESTMENT_ID = i.ID
    INNER JOIN LISTED_COMPANIES lc on i.LISTEDCOMPANY_ID=lc.ID
/

