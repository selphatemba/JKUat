create view V_ACC_TAX_SCHEDULE as
  select
    p.PMT_DATE,
    p.SCHEME_ID,
    ln.PARTICULARS,
    ln.TAXABLE gross,--p.CONTROL_AMT-COALESCE(p.VAT_AMOUNT, 0) gross,
    ln.TAX witholding_tax,
    p.VAT_AMOUNT vat,
    ln.NET_PAYMENT net_paid,
    decode(tps.CATEGORY, 'WITH_HOLDING', 'Withholding Tax') category,
    tps.AMOUNT_DUE total_schedule_amt,
    tps.DATE_FROM,
    tps.DATE_TO,
    tps.DATE_GENERATED,
    cd.NAME,
    case when cd.TAX_PIN is NULL then '-' else cd.TAX_PIN END pin,
    whtxcat.NAME whtholdingtax_cat,
    ln.TAX_RATE wthtaxRate,
    case when tps.POSTED=0 then 'Yes' else 'No' END posted,
    INVOICENO,
    ln.id
  from TAX_PMT_LINES ln INNER JOIN TAX_PMT_SCHEDULE tps ON ln.SCHEDULE_ID = tps.ID
    INNER JOIN PAYMENTS p ON ln.payment_id=p.ID
    INNER JOIN CREDITOR_DEBTOR cd ON p.CREDITORDEBTOR_ID = cd.ID
    INNER JOIN WITHHOLDINGTAX_CAT whtxcat ON tps.WITHHOLDINGTAX_ID = whtxcat.ID
  where tps.ID=(select grp.tax_schedule_id from V_GENERAL_REPORTS_PARAMS grp)
/

