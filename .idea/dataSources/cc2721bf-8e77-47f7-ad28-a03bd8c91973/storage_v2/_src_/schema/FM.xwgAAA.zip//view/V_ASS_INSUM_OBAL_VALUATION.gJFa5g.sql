create view V_ASS_INSUM_OBAL_VALUATION as
  select
    inv.SCHEME_ID,
    (DECODE(INVESTMENT_CATEGORY, 'EQUITY', 'Equity', 'CORPORATE_BONDS' , 'Corporate Bonds', 'GOVERNMENT_SECURITIES', 'Government Securities', 'FIXED_TERM_DEPOSIT', 'Fixed Term Deposits', 'PROPERTY', 'Property', 'CASH_CALL_DEPOSITS', 'Cash and Call Deposits', INVESTMENT_CATEGORY)) category,
    sum(
        case when inv.INVESTMENT_CATEGORY = 'EQUITY' and (txns.TRANSACTION_TYPE = 'EQUITY_VALUATION') then coalesce(txns.AMOUNT, 0)
        when (inv.INVESTMENT_CATEGORY = 'CORPORATE_BONDS' or inv.INVESTMENT_CATEGORY='GOVERNMENT_SECURITIES') AND txns.BONDTRANS_TYPE='VALUATION' then coalesce(txns.AMOUNT, 0)
        when (inv.INVESTMENT_CATEGORY = 'FIXED_TERM_DEPOSIT' AND txns.TRANSACTION_TYPE='FXD_TRM_DEP_TRANS' AND lower(txns.PARTICULARS) LIKE '%valuation%') then coalesce(inv.INITIAL_VALUE, 0)
        when (inv.INVESTMENT_CATEGORY = 'CASH_CALL_DEPOSITS' AND lower(txns.PARTICULARS) LIKE '%valuation%') then coalesce(txns.AMOUNT, 0)
        when inv.INVESTMENT_CATEGORY = 'PROPERTY' and txns.TRANSACTION_TYPE='PROPERTY_VALUATION_TXN' then coalesce(txns.AMOUNT, 0)
        ELSE 0
        END
    )sales_redeem
  from INVESTMENTS inv
    INNER JOIN INVESTMENT_TXNS txns ON inv.ID = txns.INVESTMENT_ID
  where inv.SCHEME_ID=(select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp)
        and txns.TRANS_DATE < (select grp.DATE_FROM from V_GENERAL_REPORTS_PARAMS grp)
        and (lower(txns.PARTICULARS) LIKE '%valuation%')
        and (txns.DELETED!='DELETED' or txns.DELETED is null) and (inv.DELETED!='DELETED' or inv.DELETED is null)
  GROUP BY inv.INVESTMENT_CATEGORY, inv.SCHEME_ID ORDER BY inv.INVESTMENT_CATEGORY ASC
/

