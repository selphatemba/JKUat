create view V_WITHDRAWAL_SETTLEMENTS as
  select
     mem.SCHEME_ID,
     ben.DATE_OF_EXIT,
    mem.EXIT_ID,
    mem.MEMBER_NO,
    pay.DATE_OF_CALC,
    pay.DATE_AUTHORIZED,
    decode(mem.TITLE , 'MR', 'Mr', 'MRS', 'Mrs', mem.TITLE )||mem.SURNAME||', '||mem.FIRSTNAME||' '||mem.OTHER_NAMES name,
    pay.NET_PAYMENT,
    pay.WITHOLDING_TAX,
    (coalesce(ben.defered_unreg,0)+coalesce(ben.deffered_reg,0)) deffered,
    (select coalesce(unv.GROSS,0) from BENEFIT_PAYMENTS unv where unv.BENEFIT_ID=mem.EXIT_ID and unv.TYPE='UNVESTED_BENEFITS') unvested,
    pay.GROSS
  from
    BENEFIT_PAYMENTS pay
    left join members mem on mem.EXIT_ID = pay.BENEFIT_ID
      left join benefits ben on ben.id = mem.EXIT_ID
  where ben.DATE_OF_EXIT between (select grp.DATE_FROM from V_GENERAL_REPORTS_PARAMS grp) and (select grp.DATE_TO from V_GENERAL_REPORTS_PARAMS grp) and pay.TYPE<>'UNVESTED_BENEFITS' and mem.scheme_id = (select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp)
  order by member_no ASC
/

