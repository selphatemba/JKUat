create view V_AGE_BANDS as
  SELECT cb.AP_ID,
    m.SCHEME_ID,
    CURRENT_AGE_BAND,
    COUNT (m.id) memeber_count,
    SUM (COALESCE (ee_bal, 0))
    + SUM (COALESCE (ee_balintr, 0))
    + SUM (COALESCE (ee_intr, 0))
    + SUM (COALESCE (ee_contr, 0))
    + SUM (COALESCE (ee_withdr_intr, 0))
    - SUM (COALESCE (ee_withdr, 0))
    + SUM (COALESCE (er_bal, 0))
    + SUM (COALESCE (er_balintr, 0))
    + SUM (COALESCE (er_intr, 0))
    + SUM (COALESCE (er_contr, 0))
    + SUM (COALESCE (er_withdr_intr, 0))
    - SUM (COALESCE (er_withdr, 0))
    + SUM (NVL (avc_bal, 0))
    + SUM (COALESCE (avc_balintr, 0))
    + SUM (COALESCE (avc_intr, 0))
    + SUM (COALESCE (avc_contr, 0))
    + SUM (COALESCE (avc_withdr_intr, 0))
    - SUM (COALESCE (avc_withdr, 0))
    + SUM (COALESCE (avcer_bal, 0))
    + SUM (COALESCE (avcer_balintr, 0))
    + SUM (COALESCE (avcer_intr, 0))
    + SUM (COALESCE (avcer_contr, 0))
    + SUM (COALESCE (avcer_withdr_intr, 0))
    - SUM (COALESCE (avcer_withdr, 0)) RET_BALS
  FROM CLOSING_BALANCES cb RIGHT JOIN V_MEMBER_DETAILS m ON m.ID = cb.MEMBER_ID WHERE MBSHIP_STATUS = 'ACTIVE' GROUP BY cb.AP_ID, m.SCHEME_ID, CURRENT_AGE_BAND
/

