create view V_DBWRKSHT_DIR_BENEFITS as
  with params as(
      select (select grp.BENEFITS_ID from V_GENERAL_REPORTS_PARAMS grp) exitID from dual
  )
  select
    (select SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) scheme_id,
    ((monthly_pens+monthly_pens2) * 12) annual_pension_com,
    trunc(to_date(TO_CHAR(ADD_MONTHS(date_of_calculation,2),'DD-MON-YY')),'MM')-1  effective_date,
    b.ID,
    b.ANNUAL_PENSION,
    b.COMMENTS,
    b.DATE_APPROVED,
    b.DATE_AUTHORIZED,
    b.DATE_CERTIFIED,
    b.DATE_OF_CALCULATION,
    b.DATE_OF_EXIT,
    b.DATE_PREPARED,
    b.PREPAREDBY_ID,
    b.CERTIFIEDBY_ID,
    b.AUTHORIZEDBY_ID,
    b.ACCR_ANN_PEN,
    b.RED_ANN_PEN,
    b.NET_ARREARS,
    b.PENSION_GUARANTEE,
    b.YEARS_WORKED,
    coalesce(b.ANNUAL_SALARY, 0)ANNUAL_SALARY,
    (select pct_monthly from beneficiaries where (relationship='WIFE' or relationship='HUSBAND') and member_id =
                                                                                                     (select id from members
                                                                                                     where exit_id=exitID and rownum=1) and rownum=1) thome_sp,
    (select pct_monthly from beneficiaries where (relationship='SON' or relationship='DAUGHTER') and member_id =
                                                                                                     (select id from members
                                                                                                     where exit_id=exitID and rownum=1)  and rownum=1) thome_ch,
    (select count(id) from beneficiaries be where be.member_id = (select id from members where exit_id = exitID) and (relationship = 'DAUGHTER' or relationship = 'SON') and status='ELIGIBLE') children,
    (select count(id) from beneficiaries be where be.member_id = (select id from members where exit_id = exitID) and (relationship = 'WIFE' or relationship = 'HUSBAND') and (status='ELIGIBLE' or status = 'MARRIED')) spouses
  from benefits b,params where id = exitID
/

