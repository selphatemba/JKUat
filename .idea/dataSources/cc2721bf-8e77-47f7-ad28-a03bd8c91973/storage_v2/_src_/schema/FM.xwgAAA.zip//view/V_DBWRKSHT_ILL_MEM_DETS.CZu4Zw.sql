create view V_DBWRKSHT_ILL_MEM_DETS as
  with params as (
      select (select MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS) member_param, (select AP_ID from V_GENERAL_REPORTS_PARAMS) ap_param, (select SCHEME_ID from V_GENERAL_REPORTS_PARAMS) scheme_param from dual
  )
  SELECT mb.ID, SCHEME_ID,
    (select c.name from  companies c,members m, params p where c.id=m.company_id and m.id=p.member_param) company,
    (select to_date from accounting_periods where id = p.ap_param) to_date,
    (select contributions from interest_rates where scheme_id = m.scheme_id and status = 'REGISTERED' and type = 'DECLARED' and ap_id = p.ap_param) interest,
    (select normal from retirement_ages re where memberclass_id = m.mclass_id and re.gender = mb.gender) retire_age_normal,
    add_months(mb.dob, 12*(select normal from retirement_ages re where memberclass_id = m.mclass_id and re.gender = mb.gender)) retire,
    (SELECT SCHEME_NAME FROM SCHEMES WHERE ID = M.SCHEME_ID) SCHEME,
    payroll_no,
    case when ben.AGE_AT_EXIT is null then (to_char(current_date, 'yyyy')-to_char(mb.dob,'yyyy')) else ben.AGE_AT_EXIT end age,
    DECODE(mb.TITLE,'MR','Mr.', 'MRS', 'Mrs.', 'DR', 'Dr.', 'PROF', 'Prof.', 'REV', 'Rev.', 'ENG', 'Eng.', 'MISS', 'Ms.', '')
    ||' '||M.SURNAME
    ||', '||M.FIRSTNAME
    ||' '||M.OTHER_NAMES NAME,
    M.MEMBER_NO,
    mb.GENDER,
    M.DATE_JOINED_SCHEME,
    M.DATE_OF_EMPL,
    M.DEPARTMENT_NO,
    mb.DOB,
    (select  distinct salary from members where salary = m.id) emolument
  FROM MEMBERS M
    left join benefits ben on M.EXIT_ID = ben.ID
    INNER JOIN MEMBERS_BIOS mb ON M.MEMBERBIO_ID = mb.ID, params p WHERE mb.ID = p.member_param
/

