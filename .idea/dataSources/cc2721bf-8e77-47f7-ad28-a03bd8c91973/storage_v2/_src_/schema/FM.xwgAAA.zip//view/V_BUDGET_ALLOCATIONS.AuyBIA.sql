create view V_BUDGET_ALLOCATIONS as
  SELECT ba.id BUDGET_ALLOCATIONS_ID,
  ba.AMOUNT,
  ba.SEQ,
       ap.ID ap_id,
  ap.FROM_DATE,
  ap.TO_DATE,
  ap.PERIOD_TYPE,
  ap.PERIOD_STATUS,
       ap.SCHEME_ID SCHEME_ID_ap,
  ap.PRV_AP_ID,
       bi.ID budget_items_id,
  bi.CODE,
  bi.DESCRIPTION,
  bi.NAME,
  bi.HDR_NAME,
       bi.SCHEME_ID SCHEME_ID_bi
FROM BUDGET_ALLOCATIONS ba
LEFT JOIN V_ACCOUNTING_PERIODS ap ON ba.AP_ID = ap.ID
LEFT JOIN v_budget_items bi ON ba.ITEM_ID = bi.ID
/

