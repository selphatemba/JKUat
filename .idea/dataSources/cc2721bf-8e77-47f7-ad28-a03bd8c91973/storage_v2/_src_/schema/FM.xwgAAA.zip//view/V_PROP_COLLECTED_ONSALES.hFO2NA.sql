create view V_PROP_COLLECTED_ONSALES as
  select
    tx.ID,
    u.UNIT_NO,
    tx.TRANS_DATE,
    tx.TRANSACTION_TYPE,
    tx.AMOUNT sc_value,
    coalesce(tx.SPOT_RATE, 1) spot_rate,
    tx.AMOUNT*coalesce(tx.SPOT_RATE, 1) bc_value,
    tx.POSTED,
    tx.DATE_POSTED,
    tx.APPROVED_DATE,
    tx.PARTICULARS,
    tx.INVTXN_TYPE,
    tx.RECEIVED_BY_ACCOUNTS,
    curr.NAME,
    curr.CODE
  from INVESTMENT_TXNS tx
    INNER JOIN UNITS u on tx.UNIT_ID = u.ID
    INNER JOIN INVOICES i on tx.ID = i.INVESTMENTTXN_ID
    left JOIN CURRENCIES curr on i.CURRENCY_ID = curr.ID
  where tx.UNITSALETRANSACTION_ID in (SELECT utx.ID FROM UNIT_TXNS utx)
        AND tx.flow_type=0 and tx.POSTED='YES' and tx.SCHEME_ID=(select SCHEME_ID FROM V_GENERAL_REPORTS_PARAMS)
        and tx.TRANS_DATE BETWEEN (select grp.DATE_FROM from V_GENERAL_REPORTS_PARAMS grp) and (select grp.DATE_TO from V_GENERAL_REPORTS_PARAMS grp)
        and tx.INVESTMENT_ID BETWEEN (select grp.INVEST_ID_FROM from V_GENERAL_REPORTS_PARAMS grp) and (select grp.INVEST_ID_TO from V_GENERAL_REPORTS_PARAMS grp)
  order by tx.TRANS_DATE ASC
/

