create view V_INV_PVM_FV_HOLDINGPERINV as
  SELECT
    ids.ID,
    coalesce(fvacqob.FV_ACQUISITIONS, 0) OB_ACQ,
    coalesce(fvacq.FV_ACQUISITIONS, 0) ACQUISITIONS,
    coalesce(fvsaleob.FV_SALES, 0) OB_SALES,
    coalesce(fvsale.FV_SALES, 0) SALES,
    (coalesce(fvacqob.FV_ACQUISITIONS, 0)+coalesce(fvacq.FV_ACQUISITIONS, 0))-(coalesce(fvsaleob.FV_SALES, 0)+coalesce(fvsale.FV_SALES, 0))fv_closing_bal
  FROM V_INV_PVM_LISTALLIDS ids
    left JOIN V_INV_PVM_OB_FACEVACQ_PER_INV fvacqob ON ids.ID=fvacqob.INVESTMENT_ID
    left JOIN V_INV_PVM_OB_FACEVSALE_PER_INV fvsaleob ON ids.ID=fvsaleob.INVESTMENT_ID
    left JOIN V_INV_PVM_FACEVACQ_PER_INV fvacq ON ids.ID=fvacq.INVESTMENT_ID
    left JOIN V_INV_PVM_FACEVSALE_PER_INV fvsale ON ids.ID=fvsale.INVESTMENT_ID
/

