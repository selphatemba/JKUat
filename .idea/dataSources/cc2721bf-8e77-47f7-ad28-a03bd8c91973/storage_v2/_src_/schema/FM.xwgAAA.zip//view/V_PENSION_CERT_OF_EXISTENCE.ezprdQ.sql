create view V_PENSION_CERT_OF_EXISTENCE as
  select c.PENSION_NO,
    'Dear '||c.PENSIONER_NAME||',' dear_pensioner,
    'C/O '||C.CARE_OF||',' co,
    c.POSTAL_ADDRESS postal_address,
    c.TOWN||'.' town,
    (case when c.IS_RETIREE='RETIREE' and c.ALIVE='YES' then ('Pensioner''s Name: '||c.MEMBER_NAME) else ('Deceased''s Name: '||c.MEMBER_NAME) END) name_label_val,
    (case when c.IS_RETIREE='RETIREE' and c.ALIVE='YES' and c.DATE_RETIRE is not NULL then ('Date of Retirement: '||c.DATE_RETIRE)
     when c.IS_RETIREE='RETIREE' and c.ALIVE='YES' and c.DATE_RETIRE is NULL then ('Date of Retirement: --')
     when (c.IS_RETIREE!='RETIREE' or c.ALIVE!='YES') and c.DATE_DECEASED is not NULL then ('Date of Death: '||c.DATE_DECEASED)
     when (c.IS_RETIREE!='RETIREE' or c.ALIVE!='YES') and c.DATE_RETIRE is not NULL then ('Date of Death: '||c.DATE_RETIRE)
     when (c.IS_RETIREE!='RETIREE' or c.ALIVE!='YES') and c.DATE_RETIRE is NULL then ('Date of Death: --')
     else ('Deceased''s Name:') END) retire_or_death_label, c.DOB dob, c.STAFF_NO staff_no, c.RELATIONSHIP relationship, c.ID_NO id_no, pcel.DATEPREPARED date_processed, pcel.RETURNDATE, pcel.RECEIVED received, pcel.SCHEMENO SCHEME_ID
  from V_PENSION_CERT_OF_EXT_BATCH c LEFT JOIN V_PENSION_CERT_OF_EXT_LIST pcel ON c.PENSION_NO=pcel.PENNO
  WHERE pcel.DATEPREPARED=(select DATE_FROM from V_GENERAL_REPORTS_PARAMS) and pcel.SCHEMENO=(select SCHEME_ID from V_GENERAL_REPORTS_PARAMS) and
        (pcel.RECEIVED=(case when (select COE_RECEIVED FROM V_GENERAL_REPORTS_PARAMS) is NULL then ('YES') else (select COE_RECEIVED from V_GENERAL_REPORTS_PARAMS) END) or pcel.RECEIVED=(case when (select COE_RECEIVED FROM V_GENERAL_REPORTS_PARAMS) is NULL then ('NO') else (select COE_RECEIVED from V_GENERAL_REPORTS_PARAMS) END))
  and STAFF_NO>=(select MEMBER_NO from MEMBERS m where m.ID=(select MEMBER_ID_FROM FROM V_GENERAL_REPORTS_PARAMS)) and STAFF_NO<=(select MEMBER_NO from MEMBERS m where m.ID=(select MEMBER_ID_TO FROM V_GENERAL_REPORTS_PARAMS))
/

