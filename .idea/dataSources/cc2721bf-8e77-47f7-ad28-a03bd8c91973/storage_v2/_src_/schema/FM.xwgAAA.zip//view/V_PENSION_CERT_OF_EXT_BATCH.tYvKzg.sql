create view V_PENSION_CERT_OF_EXT_BATCH as
  SELECT (case when p.beneficiary_id is null then (p.pensioner_type)
        when p.member_id is null then (select relationship from beneficiaries
        where id = p.beneficiary_id) else '' end) relationship,
       (select date_of_exit from benefits where rownum = 1 and id = (select exit_id from members
       where id = (select (case when member_id is not null then member_id when member_id is null then
         (select member_id from beneficiaries where id = beneficiary_id and rownum=1) else null end) from pensioners where pension_no = p.pension_no and ROWNUM=1))) date_retire,
  p.id,p.account_no pensioner_account,to_char(p.DATE_DECEASED, 'dd/MM/yyyy') DATE_DECEASED,
       (case when p.beneficiary_id is null then ('RETIREE') when p.member_id is null then ('BENEFICIARY') else '' end) IS_RETIREE,
       (case when p.beneficiary_id is null then (select member_no from members m where m.id = p.member_id)
        when p.member_id is null then (select member_no from members m where m.id = (select member_id from beneficiaries where id = p.beneficiary_id)) else 0 end) MEMBER_NO,
       (case when p.beneficiary_id is null then (select DECODE(m.TITLE,'MR','Mr.', 'MRS', 'Mrs.', 'DR', 'Dr.', 'PROF', 'Prof.', 'REV', 'Rev.', 'ENG', 'Eng.', 'MISS', 'Ms.', '')||' '||M.SURNAME||', '||M.FIRSTNAME||' '||M.OTHER_NAMES from members m where m.id = p.member_id)
        when p.member_id is null then (select firstname||' '||othernames from beneficiaries where id = p.beneficiary_id) else '' end) pensioner_name,
       (case when p.beneficiary_id is null then (select care_of from members m where m.id = p.member_id) when p.member_id is null then (select care_of from beneficiaries where id = p.beneficiary_id) else '' end) care_of,
       (case when p.beneficiary_id is null then (select dob from members m where m.id = p.member_id) when p.member_id is null then (select dob from beneficiaries where id = p.beneficiary_id) else null end) dob,
       (case when p.beneficiary_id is null then (select DECODE(m.TITLE,'MR','Mr.', 'MRS', 'Mrs.', 'DR', 'Dr.', 'PROF', 'Prof.', 'REV', 'Rev.', 'ENG', 'Eng.', 'MISS', 'Ms.', '')||' '||M.SURNAME||', '||M.FIRSTNAME||' '||M.OTHER_NAMES from members m where m.id = p.member_id)
        when p.member_id is null then (select DECODE(m.TITLE,'MR','Mr.', 'MRS', 'Mrs.', 'DR', 'Dr.', 'PROF', 'Prof.', 'REV', 'Rev.', 'ENG', 'Eng.', 'MISS', 'Ms.', '')||' '||M.SURNAME||', '||M.FIRSTNAME||' '||M.OTHER_NAMES from members m where m.id = (select member_id from beneficiaries where id = p.beneficiary_id)) else '' end) member_name, p.ACCOUNT_NAME,
       (case when p.beneficiary_id is null then (select TOWN from members m where m.id=p.member_id)
        when p.member_id is null then (select TOWN from beneficiaries where id = p.beneficiary_id) else '' end) TOWN,
       (case when p.beneficiary_id is null then (select POSTAL_ADDRESS from members m where m.id=p.member_id)
        when p.member_id is null then (select ADDRESS from beneficiaries where id = p.beneficiary_id) else '' end) POSTAL_ADDRESS,
  p.PENSION_FREQ, p.PENSION_STATUS, p.PENSIONER_TYPE, p.ACCOUNT_NO, to_char(PENSION_START_DATE, 'dd/MM/yyyy') PENSION_START_DATE,
  (case when p.beneficiary_id is null then (select coalesce(ID_NO, '--') from members m where m.id=p.member_id)
   when p.member_id is null then (select '--' from beneficiaries where id = p.beneficiary_id) else '' end) ID_NO,
  (case when p.beneficiary_id is null then (select coalesce(pin, '--') from members m where m.id=p.member_id)
   when p.member_id is null then (select '--' from beneficiaries where id = p.beneficiary_id) else '' end) pin,
  (case when p.beneficiary_id is null then (select coalesce(CELL_PHONE, '--') from members m where m.id=p.member_id)
   when p.member_id is null then (select coalesce(CELL_PHONE, '--') from beneficiaries where id = p.beneficiary_id) else '' end) PHONE,
  (select distinct name from bank_branches where id = p.branch_id and rownum=1) branch_name,
  (select name from banks where id = (select distinct bank_id from bank_branches where id = p.branch_id and rownum=1)) bank_name, pension_no, alive, SCHEME_ID
from pensioners p
/

