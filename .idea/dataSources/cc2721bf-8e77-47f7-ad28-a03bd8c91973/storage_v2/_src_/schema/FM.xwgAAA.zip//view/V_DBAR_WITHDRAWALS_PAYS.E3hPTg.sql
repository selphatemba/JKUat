create view V_DBAR_WITHDRAWALS_PAYS as
  with quarter as (
    select (select QUARTER from V_AR_PARAMS) q, (select SCHEME_ID from V_AR_PARAMS) scheme_id, (select YEAR FROM V_AR_PARAMS) yr from dual),quarterdef as (
    select case
           when q = 1 then '01-JAN-'||''||qt.yr
           when q = 2 then '01-APR-'||''||qt.yr
           when q = 3 then '01-JUL-'||''||qt.yr
           when q = 4 then '01-OCT-'||''||qt.yr
           else ''
           end as from_date_qt,
           case
           when q = 1 then '31-MAR-'||''||qt.yr
           when q = 2 then '30-JUN-'||''||qt.yr
           when q = 3 then '30-SEP-'||''||qt.yr
           when q = 4 then '31-DEC-'||''||qt.yr
           else ''
           end as to_date_qt
    from quarter qt
)
select from_date_qt, to_date_qt, mem.SCHEME_ID AS scheme_id, member_no, mem.surname||', '||mem.firstname||' '||other_names member_name,
                  to_char(mem.DATE_JOINED_SCHEME,  'dd/MM/yyyy') join_date,(select name from sponsors where id = (select sponsor_id from companies where id = mem.company_id)) sponsor,
                  (select reason from REASONS_FOR_EXIT where id = ben.reasonforexit_id) reason,
  ben.date_of_exit,
                  (select sum(coalesce(net_payment,0)) from benefit_payments where benefit_id = ben.id) net_payment,
                  (select max(payment_date) from benefit_payments where benefit_id = ben.id) payment_date
from members mem, quarterdef pe,  quarter qtr, benefits ben,benefit_payments where  mem.exit_id = ben.id and mem.scheme_id=qtr.scheme_id and ben.reasonforexit_id in (select id from REASONS_FOR_EXIT where reason = 'Resignation' or reason = 'Termination' or reason = 'Dismissal' or reason = 'Immigrants' or reason = 'Transfer of Contributions')  and mem.scheme_id=qtr.scheme_id and date_of_exit between from_date_qt and to_date_qt and payment_date is not null
/

