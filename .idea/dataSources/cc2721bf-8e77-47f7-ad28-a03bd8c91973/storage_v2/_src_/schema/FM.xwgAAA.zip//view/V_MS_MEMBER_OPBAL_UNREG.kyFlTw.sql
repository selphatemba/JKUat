create view V_MS_MEMBER_OPBAL_UNREG as
  select cb.AP_ID, cb.MEMBER_ID, cb.ASAT, cb.EE_BAL, cb.ER_BAL, cb.AVC_BAL
  FROM CLOSING_BALANCES cb where cb.AP_ID=(select MS_APIDONE apIdOne from V_GENERAL_REPORTS_PARAMS) and status='UNREGISTERED' and MEMBER_ID in (select st.member_id from MEMSTMT_RPT_MEMIDS st)
/

