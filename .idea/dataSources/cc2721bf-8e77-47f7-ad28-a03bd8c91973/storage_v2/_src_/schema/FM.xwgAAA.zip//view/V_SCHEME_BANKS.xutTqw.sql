create view V_SCHEME_BANKS as
  SELECT sb.ID scheme_banks_ID,
  sb.ACCOUNT_NAME,
  sb.ACCOUNT_NO,
  sb.CASH_LIMIT,
  sb.MANAGER_IN_CHARGE,
  sb.OPRTN_ACCOUNT,
  sb.PETTYCASH,
  sb.START_DATE,
  sb.STATUS,
       bb.name BRANCH,
  sb.BRANCH_ID,
  sb.currency_id,
       c.name CURRENCY,
  sb.SCHEME_ID
FROM scheme_banks sb
  LEFT JOIN CURRENCIES c ON sb.CURRENCY_ID = c.ID
  LEFT JOIN BANK_BRANCHES bb ON sb.BRANCH_ID = bb.ID
/

