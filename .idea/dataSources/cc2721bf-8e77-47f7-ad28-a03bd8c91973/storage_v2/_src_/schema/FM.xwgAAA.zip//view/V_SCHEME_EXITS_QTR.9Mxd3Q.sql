create view V_SCHEME_EXITS_QTR as
  SELECT SCHEME_ID,
            QRTR_DATE_OF_EXIT,
            QRTR_DATE_OF_EXIT_START_DATE,
            QRTR_DATE_OF_EXIT_END_DATE,
            SUM (DECODE (APPROVED, 'YES', 1, 0)) all_exited_members,
            SUM (DECODE (REASON, 'Resignation', 1, 0)) REASON_Resignation,
            SUM (DECODE (REASON, 'Immigrants', 1, 0)) REASON_Immigrants,
            SUM (DECODE (REASON, 'Death in Deferment', 1, 0))
               REASON_Death_in_Deferment,
            SUM (DECODE (REASON, 'Death Notice', 1, 0)) REASON_Death_Notice,
            SUM (DECODE (REASON, 'Medical Retirement', 1, 0))
               REASON_Medical_Retirement,
            SUM (DECODE (REASON, 'Transfer of Contributions', 1, 0))
               REASON_Transfer_of_Contr,
            SUM (DECODE (REASON, 'Death in service', 1, 0))
               REASON_Death_in_service,
            SUM (DECODE (REASON, 'Withdrawals', 1, 0)) REASON_Withdrawals,
            SUM (DECODE (REASON, 'Dismissal', 1, 0)) REASON_Dismissal,
            SUM (DECODE (REASON, 'Death in retirement', 1, 0))
               REASON_Death_in_retirement,
            SUM (DECODE (REASON, 'Normal Retirement', 1, 0))
               REASON_Normal_Retirement,
            SUM (DECODE (REASON, 'Termination', 1, 0)) REASON_Termination,
            SUM (DECODE (REASON, 'Early Retirement', 1, 0))
               REASON_Early_Retirement,
            SUM (DECODE (REASON, 'Late Retirement', 1, 0))
               REASON_Late_Retirement,
            SUM (DECODE (MBSHIP_STATUS, 'RETIRED_ILL_HEALTH', 1, 0))
               STATUS_ILL_HEALTH,
            SUM (DECODE (MBSHIP_STATUS, 'WITHDRAWN', 1, 0)) STATUS_WITHDRAWN,
            SUM (DECODE (MBSHIP_STATUS, 'DEFFERED', 1, 0)) STATUS_DEFFERED,
            SUM (DECODE (MBSHIP_STATUS, 'RETIRED', 1, 0)) STATUS_RETIRED,
            SUM (DECODE (MBSHIP_STATUS, 'DEATH_IN_SERVICE', 1, 0))
               STATUS_DEATH_IN_SERVICE
       FROM v_member_status_qtr
   GROUP BY SCHEME_ID,
            QRTR_DATE_OF_EXIT,
            QRTR_DATE_OF_EXIT_START_DATE,
            QRTR_DATE_OF_EXIT_END_DATE
/

