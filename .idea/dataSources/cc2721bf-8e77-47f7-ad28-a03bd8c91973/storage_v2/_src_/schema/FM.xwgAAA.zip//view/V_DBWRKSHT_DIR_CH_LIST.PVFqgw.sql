create view V_DBWRKSHT_DIR_CH_LIST as
  select
    (select SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) scheme_id,
    be.RELATIONSHIP,
    be.GENDER,
    be.firstname||' '||be.OTHERNAMES||' '||be.SURNAME name,
    (months_between(pe.DATE_OF_CALCULATION , pe.DATE_DECEASED)) months_unpaid,
    (coalesce(be.pct_monthly/100, 0)*(coalesce(pe. TARGET_PENSION_PRE, 0) + coalesce(TARGET_PENSION_POST,0))) child_aloc,
    --coalesce(be.pct_monthly/100, 0) * (coalesce(pe. TARGET_PENSION_PRE, 0) + coalesce(TARGET_PENSION_POST,0))  * (select count(*) from BENEFICIARIES bi where bi.PCT_MONTHLY>0 and (RELATIONSHIP = 'DAUGHTER' or  RELATIONSHIP = 'SON') and member_id = pe.member_id) child_alloc,
    pe.OVER_PMT  overpaid
  from pensioners pe
    inner join beneficiaries be on be.member_id = pe.member_id
  where pe.ID = (select PENSIONER_ID from V_GENERAL_REPORTS_PARAMS grp) and (RELATIONSHIP = 'DAUGHTER' or  RELATIONSHIP = 'SON') and be.PCT_MONTHLY > 0
/

