create view V_DEATHRET_PENSION_COMP as
  select
    (SELECT COALESCE(sum(coalesce(TARGET_PENSION_PRE, 0)+coalesce(TARGET_PENSION_POST, 0)), 0)annualpensionspouse FROM V_DEATHRET_PENSION_WRKSHT where RELATIONSHIP in ('HUSBAND', 'WIFE'))annualpensionspouse,
    (SELECT COALESCE(sum(coalesce(TARGET_PENSION_PRE, 0)+coalesce(TARGET_PENSION_POST, 0)), 0)annualpensionchild FROM V_DEATHRET_PENSION_WRKSHT where RELATIONSHIP in ('DAUGHTER', 'SON'))annualpensionchild,
    (SELECT COALESCE(sum(coalesce(PENSION, 0)), 0)totalspousepension FROM V_DEATHRET_PENSION_WRKSHT where RELATIONSHIP in ('HUSBAND', 'WIFE'))totalspousepension,
    (SELECT COALESCE(sum(coalesce(PENSION, 0)), 0)totalchildpension FROM V_DEATHRET_PENSION_WRKSHT where RELATIONSHIP in ('DAUGHTER', 'SON'))totalchildpension,
    (SELECT count(ID) countchildren FROM V_DEATHRET_PENSION_WRKSHT where RELATIONSHIP in ('DAUGHTER', 'SON'))countchildren,
    (SELECT count(ID) countspouses FROM V_DEATHRET_PENSION_WRKSHT where RELATIONSHIP in ('HUSBAND', 'WIFE'))countspouses,
    (SELECT COALESCE(sum(coalesce(pension_tax, 0)), 0)totalspousetax FROM V_DEATHRET_PENSION_WRKSHT where RELATIONSHIP in ('HUSBAND', 'WIFE'))totalspousetax,
    (SELECT COALESCE(sum(coalesce(pension_tax, 0)), 0)totalchildtax FROM V_DEATHRET_PENSION_WRKSHT where RELATIONSHIP in ('DAUGHTER', 'SON'))totalchildtax,
    (SELECT COALESCE(sum(coalesce(arrears, 0)), 0)totalspousearrears FROM V_DEATHRET_PENSION_WRKSHT where RELATIONSHIP in ('HUSBAND', 'WIFE'))totalspousearrears,
    (SELECT COALESCE(sum(coalesce(arrears, 0)), 0)totalchildarrears FROM V_DEATHRET_PENSION_WRKSHT where RELATIONSHIP in ('DAUGHTER', 'SON'))totalchildarrears,
    (SELECT COALESCE(sum(coalesce(netpension, 0)), 0)totalspousenetpension FROM V_DEATHRET_PENSION_WRKSHT where RELATIONSHIP in ('HUSBAND', 'WIFE'))totalspousenetpension,
    (SELECT COALESCE(sum(coalesce(netpension, 0)), 0)totalchildnetpension FROM V_DEATHRET_PENSION_WRKSHT where RELATIONSHIP in ('DAUGHTER', 'SON'))totalchildnetpension
  from dual
/

