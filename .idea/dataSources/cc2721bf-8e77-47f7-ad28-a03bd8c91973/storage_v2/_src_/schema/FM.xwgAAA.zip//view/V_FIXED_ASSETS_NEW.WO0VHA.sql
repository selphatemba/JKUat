create view V_FIXED_ASSETS_NEW as
  select
    fa.scheme_id,
    fa.NAME,
    fa.ASSET_CODE,
    fa.STATUS,
    fa.DATE_ACQUIRED,
    fa.DESCR,
    fa.ORIGINAL_COST,
    fa.PREV_VALUE,
    fa.RETIRED,
    fa.DATE_RETIRED dateSoldOrRetired,
    fa.SOLD,
    fa.CARETAKER,
    coalesce(fa.INITIAL_BOOK_ALUE, 0) initialValue,
    coalesce(fa.CURRENT_VALUE, 0) currentValue,
    coalesce(fa.CURRENT_VALUE, 0)-coalesce(fa.INITIAL_BOOK_ALUE, 0) cumulatedDepreciation,
    fa.LOCATION,
    fa.PREV_DEPRECTDATE,
    fa.ASSET_CONDITION,
    fa.REGION_ID,
    ac.DEPRECIATION_FACTOR,
    ac.DEPRECIATIONMETHOD,
    ac.DESCR,
    ac.MONTHS_TO_DEPRECIATE,
    ac.NAME,
    ac.YEARS_TO_DEPRECIATE
  from FIXED_ASSETS fa INNER JOIN ASSET_CLASSES ac on fa.ASSETCLASS_ID=ac.ID
  WHERE fa.SCHEME_ID=(select scheme_id from V_GENERAL_REPORTS_PARAMS)
/

