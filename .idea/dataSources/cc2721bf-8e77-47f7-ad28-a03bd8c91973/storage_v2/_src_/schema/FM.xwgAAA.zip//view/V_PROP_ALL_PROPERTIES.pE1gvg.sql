create view V_PROP_ALL_PROPERTIES as
  select
    inv.SCHEME_ID,
    inv.ID,
    inv.DATE_OF_COMM,
    inv.DESCR,
    inv.INITIAL_VALUE,
    inv.LOCALITY,
    inv.MARKET_VALUE,
    inv.NAME,
    inv.AREA,
    inv.CODE,
    inv.DEVELOPED,
    inv.LOCATION,
    inv.LR_NUMBER,
    coalesce(inv.ROAD, '-') ROAD,
    inv.TOWN,
    pm.NAME as MANAGER,
    (select count(u.ID) from UNITS u WHERE u.INVESTMENT_ID=inv.ID) as UNITS_COUNT,
    coalesce(inv.SOLD, 'NO')SOLD
  from INVESTMENTS inv
    INNER JOIN PROPERTY_MANAGERS pm ON inv.MANAGER_ID = pm.ID
  where inv.INVESTMENT_CATEGORY='PROPERTY' and inv.SCHEME_ID=(select SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp)
/

