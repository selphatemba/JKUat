create view V_PRINT_RECEIPT as
  with curr as (
      select (select scheme_id from general_reports_params) scheme, (select receipt_id from general_reports_params) id from dual
  ),
      zero as(
        select case when
          ((select sum(control_amt) from payments where id = cur.id) - trunc((select sum(control_amt) from payments where id = cur.id))) != 0  then to_char(to_date((((select sum(control_amt) from payments where id = cur.id) - trunc((select sum(control_amt) from payments where id = cur.id)))*100),'J'),'JSP')||' CENTS ONLY '
               else 'ZERO CENTS ONLY'
               end as deci from dual, curr cur
    )
  select (
           to_char( to_timestamp( lpad(TRUNC((select sum(control_amt) from payments where id = p.id)),9,'0'), 'FF9' ), 'FFSP' )
           || ' AND ' || (select z.deci from zero z)
         ) WORDS,
    p.ID,
    APPROVED_DATE,
    AUTHORIZED_DATE,
    BANK_TXN_NO,
    BATCH_IMP_ID,
    CHEQUE_NO,
    CLEARED,
    CONTROL_AMT,
    CREDIT_AMT,
    PMT_DATE,
    IMPREST_NO,
    PARENT_ID,
    PARTICULARS,
    PAYMENT_MODE,
    PAYMENT_NO,
    PAYMENT_TYPE,
    POSTED,
    PREPARED_DATE,
    REF_NO,
    SPOT_RATE,
    TXN_TYPE,
    VAT_AMOUNT,
    VOUCHER_DATE,
    WHTAX_AMOUNT,
    WHTAX_RATE,
    WHTAXRATE_ID,
    APPROVEDBY_ID,
    p.AUTHORIZEBY_ID,
    BUDGETITEM_ID,
    CASHBOOK_ID,
    CREDITORDEBTOR_ID,
    CURRENCY_ID,
    FUNDMANAGER_ID_FK,
    GLBATCH_ID,
    IMPREST_ID,
    INVESTMENTTXN_ID,
    PERIOD_ID,
    PREPAREDBY_ID,
    p.SCHEME_ID,
    p.SPONSOR_ID,
    STAGEDPAYMENT_AX_XI_TRANSIDFK,
    STAGEDPAYMENT_ID,
    STAGEDRECEIPT_ID,
    LEDGER_NO,
    UNITTXN_ID,
    CATEGORY,
    CELL_PHONE,
    DELETED,
    PAYMENT_FOR,
    POSTED_DATE,
    RECEIPT_TYPE,
    REG_AMOUNT,
    p.STATUS,
    UNREG_AMOUNT,
    INVESTMENT_ID,
    RECEIPT_ID,
    STAFFIMPREST_ID,
    REF_CODE,
    SHOW_DIRECT_RECEIPTS,
         (select c.name from currencies c where c.id = (select b.basecurrency_id from schemes b, curr cu where b.id = cu.scheme)) currency,
         (select c.code from currencies c where c.id = (select b.basecurrency_id from schemes b, curr cu where b.id = cu.scheme)) currency_code,
         (select d.name from creditor_debtor d where d.id = creditordebtor_id ) received_from,
         (prep.FIRSTNAME||' '||prep.OTHERNAMES) preparer
  from payments p, curr cu, USERS prep
  where p.id = cu.id and p.PREPAREDBY_ID=prep.ID
/

