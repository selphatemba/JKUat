create view V_GENERAL_MEMBER_DETAILS as
  select
    me.ID,
    DECODE(mb.TITLE,'MR','Mr.', 'MRS', 'Mrs.', 'DR', 'Dr.', 'PROF', 'Prof.', 'REV', 'Rev.', 'ENG', 'Eng.', 'MISS', 'Ms.', '')||' '||me.FIRSTNAME||' '||me.SURNAME||' '||me.OTHER_NAMES name,
    (select name from sponsors where id = (select sponsor_id from companies where id = me.company_id and rownum=1)) sponsor,
    me.MEMBER_NO member_no,
    initcap(me.DEPARTMENT_NO) department_no,
    mb.ID_NO id_no,
    initcap(me.DESIGNATION) designation,
    mb.DOB dob,
    FLOOR ( (SYSDATE - NVL (mb.dob, mb.dob)) / 365)age,
    date_of_empl,
    decode(case when mb.GENDER is null then me.gender else mb.gender end, 'MALE', 'Male', 'FEMALE', 'Female') gender,
    me.DATE_JOINED_SCHEME,
    mb.REGION_ADDR,
    add_months(mb.dob, 12*(select normal from retirement_ages re where memberclass_id = me.mclass_id and re.gender = mb.gender and rownum=1)) retire,
    mb.SUB_REGION,
    (select normal from retirement_ages re where memberclass_id = me.mclass_id and re.gender = mb.gender and rownum=1) retire_age_normal,
    me.DEPOT,
    (select date_of_exit from benefits where id = me.exit_id) date_of_exit,
    (select to_date from accounting_periods where id = (select AP_ID from V_GENERAL_REPORTS_PARAMS)) to_date,
    (select contributions from interest_rates where scheme_id = me.scheme_id and status = 'REGISTERED' and type = 'DECLARED' and ap_id = (select AP_ID from V_GENERAL_REPORTS_PARAMS)) interest,
    SCHEME_ID
  from members me
    INNER JOIN MEMBERS_BIOS mb ON me.MEMBERBIO_ID = mb.ID
  where me.id >= (select grp.MEMBER_ID_FROM from V_GENERAL_REPORTS_PARAMS grp) and me.id <= (select grp.MEMBER_ID_TO from V_GENERAL_REPORTS_PARAMS grp)
/

