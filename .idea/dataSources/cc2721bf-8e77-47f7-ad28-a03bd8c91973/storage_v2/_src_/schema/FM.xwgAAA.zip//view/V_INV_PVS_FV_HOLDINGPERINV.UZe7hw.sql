create view V_INV_PVS_FV_HOLDINGPERINV as
  SELECT
    ids.ID,
    coalesce(acq.FV_ACQUISITIONS, 0),
    coalesce(sales.FV_SALES, 0),
    (coalesce(acq.FV_ACQUISITIONS, 0)-coalesce(sales.FV_SALES, 0))holding
  FROM V_INV_PVS_LISTALLIDS ids
    left JOIN V_INV_PVS_FACEVACQ_PER_INV acq ON ids.ID=acq.INVESTMENT_ID
    left JOIN V_INV_PVS_FACEVSALE_PER_INV sales ON ids.ID=sales.INVESTMENT_ID
/

