create view V_GROSS_PAYROLL_UNGRPD as
  with params as (
      select (select month from V_GENERAL_REPORTS_PARAMS) month_p, (select YEAR from V_GENERAL_REPORTS_PARAMS) year_p , (select SCHEME_ID from V_GENERAL_REPORTS_PARAMS) scheme, (select 1 from dual) bank_id from dual
  ), tabo as(
      select
        (to_char(trunc(to_date('01-'||par.month_p||'-'||par.year_p),'MM')-1, 'MON') ) prevmonth,
        to_char(trunc(to_date('01-'||par.month_p||'-'||par.year_p),'MM')-1, 'YYYY') prevyear
      from params par
  )
  select
                  (select name from banks where id = (select bank_id from bank_branches where id = pa.bankbranch_id)) bank_name, pe.PENSION_NO,
                  (case when pe.member_id is null then (select be.FIRSTNAME||' '||be.OTHERNAMES||' '||be.surname from beneficiaries be  where id = pe.BENEFICIARY_ID) else (select me.FIRSTNAME||' '||me.OTHER_NAMES||' '||me.SURNAME from members me where id = pe.member_id) end) name,
    pe.ACCOUNT_NO,(select bank_branches.NAME from bank_branches where bank_branches.id = pa.BANKBRANCH_ID) branch, pa.GROSS, pa.TAX, pa.DEDS, pa.ARREAS, pa.TAX_ON_ARREAS,pa.NET, SCHEME_ID, MONTH, YEAR
  from payroll pa
    inner join pensioners pe on pa.PENSIONER_ID = pe.ID
    left join tabo on 'true' = 'true'
    left join params  on 'true' = 'true'
  where
    (pa.PENSION_STATUS = 'ACTIVE' or pa.PENSION_STATUS = 'STOPPED') and
    pa.MONTH = month_p and pa.YEAR = year_p
    and pa.PENSIONER_ID not in ((select lp.pensioner_id from tabo, payroll lp where lp.year = prevyear and lp.month = prevmonth and  lp.pension_status = 'SUSPENDED' and (lp.pensioner_id not in (select tp.pensioner_id from params, payroll tp , pensioners p where tp.month = month_p and tp.year = year_p and tp.pensioner_id = p.id and p.pension_status = 'STOPPED' or p.pension_status = 'DECEASED')
                                                                                                                                                                          or lp.pensioner_id  in (select distinct(tp.pensioner_id) from payroll tp  where (tp.pension_status = 'STOPPED' or tp.pension_status = 'DECEASED'))
    )))
/

