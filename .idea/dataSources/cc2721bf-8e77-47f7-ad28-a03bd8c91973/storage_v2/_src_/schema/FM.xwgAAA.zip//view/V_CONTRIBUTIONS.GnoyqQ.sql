create view V_CONTRIBUTIONS as
  SELECT ACCOUNTINGPERIOD_ID,
            date_paid,
            TO_CHAR (date_paid, 'YYYY') year_paid,
            TO_CHAR (date_paid, 'mon/YYYY') month_paid,
            member_id,
            TYPE,
            SALARY_TYPE,
            SALARY,
            SUM (DECODE (cb.status, 'REGISTERED', NVL (cb.ee, 0), 0)) reg_ee,
            SUM (DECODE (cb.status, 'UNREGISTERED', NVL (cb.ee, 0), 0))
               unreg_ee,
            SUM (DECODE (cb.status, 'REGISTERED', NVL (cb.er, 0), 0)) reg_er,
            SUM (DECODE (cb.status, 'UNREGISTERED', NVL (cb.er, 0), 0))
               unreg_er,
            SUM (DECODE (cb.status, 'REGISTERED', NVL (cb.AVC, 0), 0)) reg_AVC,
            SUM (DECODE (cb.status, 'UNREGISTERED', NVL (cb.AVC, 0), 0))
               unreg_AVC,
            SUM (DECODE (cb.status, 'REGISTERED', NVL (cb.AVCER, 0), 0))
               reg_AVCER,
            SUM (DECODE (cb.status, 'UNREGISTERED', NVL (cb.AVCER, 0), 0))
               unreg_AVCER
       FROM contributions cb GROUP BY ACCOUNTINGPERIOD_ID,
            date_paid,
            member_id,
            TYPE,
            SALARY_TYPE,
            SALARY
/

