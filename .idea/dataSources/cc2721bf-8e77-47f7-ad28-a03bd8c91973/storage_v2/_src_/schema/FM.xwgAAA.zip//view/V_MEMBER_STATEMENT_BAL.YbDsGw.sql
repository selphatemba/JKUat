create view V_MEMBER_STATEMENT_BAL as
  SELECT AP_ID,
          member_id,
          asat,
          item_name,
          SUBSTR (item_name, 1, INSTR (item_name, '_') - 1) STATUS,
          DECODE (SUBSTR (item_name, INSTR (item_name, '_') + 1, 2),
                  'EE', 'EMPLOYEE',
                  'ER', 'EMPLOYER',
                  'AV', 'AVC')
             EE_ER_AVC,
          CASE SUBSTR (item_name,
                         INSTR (item_name,
                                '_',
                                1,
                                2)
                       + 1)
             WHEN 'BAL' THEN 'Opening Balance'
             WHEN 'RSV_INCOME' THEN 'Reserve Income'
             WHEN 'BALINTR' THEN 'Interest on Balances'
             WHEN 'CONTR' THEN 'Contributions'
             WHEN 'INTR' THEN 'Interest on Contributions'
             WHEN 'TRANSFER' THEN 'Transfers'
             WHEN 'PAYMENTS' THEN 'Payments'
          END
             TITLE,
          CASE SUBSTR (item_name,
                         INSTR (item_name,
                                '_',
                                1,
                                2)
                       + 1)
             WHEN 'BAL' THEN 1
             WHEN 'RSV_INCOME' THEN 2
             WHEN 'BALINTR' THEN 3
             WHEN 'CONTR' THEN 4
             WHEN 'INTR' THEN 5
             WHEN 'TRANSFER' THEN 6
             WHEN 'PAYMENTS' THEN 7
          END
             INDX,
          item_value
     FROM (SELECT AP_ID,
                  member_id,
                  STATUS,
                  asat,
                  DECODE (STATUS, 'REGISTERED', EE_BAL, 0) REGISTERED_EE_BAL,
                  DECODE (STATUS, 'UNREGISTERED', EE_BAL, 0)
                     UNREGISTERED_EE_BAL,
                  DECODE (STATUS, 'REGISTERED', EE_RSV_INCOME, 0)
                     REGISTERED_EE_RSV_INCOME,
                  DECODE (STATUS, 'UNREGISTERED', EE_RSV_INCOME, 0)
                     UNREGISTERED_EE_RSV_INCOME,
                  DECODE (STATUS, 'REGISTERED', EE_BALINTR, 0)
                     REGISTERED_EE_BALINTR,
                  DECODE (STATUS, 'UNREGISTERED', EE_BALINTR, 0)
                     UNREGISTERED_EE_BALINTR,
                  DECODE (STATUS, 'REGISTERED', EE_CONTR, 0)
                     REGISTERED_EE_CONTR,
                  DECODE (STATUS, 'UNREGISTERED', EE_CONTR, 0)
                     UNREGISTERED_EE_CONTR,
                  DECODE (STATUS, 'REGISTERED', EE_INTR, 0)
                     REGISTERED_EE_INTR,
                  DECODE (STATUS, 'UNREGISTERED', EE_INTR, 0)
                     UNREGISTERED_EE_INTR,
                  DECODE (STATUS, 'REGISTERED', TRANSFER_EE, 0)
                     REGISTERED_TRANSFER_EE,
                  DECODE (STATUS, 'UNREGISTERED', TRANSFER_EE, 0)
                     UNREGISTERED_TRANSFER_EE,
                  DECODE (STATUS, 'REGISTERED', ee_payments, 0)
                     REGISTERED_ee_payments,
                  DECODE (STATUS, 'UNREGISTERED', ee_payments, 0)
                     UNREGISTERED_ee_payments,
                  DECODE (STATUS, 'REGISTERED', Er_BAL, 0) REGISTERED_Er_BAL,
                  DECODE (STATUS, 'UNREGISTERED', Er_BAL, 0)
                     UNREGISTERED_Er_BAL,
                  DECODE (STATUS, 'REGISTERED', Er_RSV_INCOME, 0)
                     REGISTERED_Er_RSV_INCOME,
                  DECODE (STATUS, 'UNREGISTERED', Er_RSV_INCOME, 0)
                     UNREGISTERED_Er_RSV_INCOME,
                  DECODE (STATUS, 'REGISTERED', Er_BALINTR, 0)
                     REGISTERED_Er_BALINTR,
                  DECODE (STATUS, 'UNREGISTERED', Er_BALINTR, 0)
                     UNREGISTERED_Er_BALINTR,
                  DECODE (STATUS, 'REGISTERED', Er_CONTR, 0)
                     REGISTERED_Er_CONTR,
                  DECODE (STATUS, 'UNREGISTERED', Er_CONTR, 0)
                     UNREGISTERED_Er_CONTR,
                  DECODE (STATUS, 'REGISTERED', Er_INTR, 0)
                     REGISTERED_Er_INTR,
                  DECODE (STATUS, 'UNREGISTERED', Er_INTR, 0)
                     UNREGISTERED_Er_INTR,
                  DECODE (STATUS, 'REGISTERED', TRANSFER_ER, 0)
                     REGISTERED_TRANSFER_ER,
                  DECODE (STATUS, 'UNREGISTERED', TRANSFER_ER, 0)
                     UNREGISTERED_TRANSFER_ER,
                  DECODE (STATUS, 'REGISTERED', er_payments, 0)
                     REGISTERED_er_payments,
                  DECODE (STATUS, 'UNREGISTERED', er_payments, 0)
                     UNREGISTERED_er_payments,
                  DECODE (STATUS, 'REGISTERED', AVC_BAL, 0)
                     REGISTERED_AVC_BAL,
                  DECODE (STATUS, 'UNREGISTERED', AVC_BAL, 0)
                     UNREGISTERED_AVC_BAL,
                  DECODE (STATUS, 'REGISTERED', AVC_RSV_INCOME, 0)
                     REGISTERED_AVC_RSV_INCOME,
                  DECODE (STATUS, 'UNREGISTERED', AVC_RSV_INCOME, 0)
                     UNREGISTERED_AVC_RSV_INCOME,
                  DECODE (STATUS, 'REGISTERED', AVC_BALINTR, 0)
                     REGISTERED_AVC_BALINTR,
                  DECODE (STATUS, 'UNREGISTERED', AVC_BALINTR, 0)
                     UNREGISTERED_AVC_BALINTR,
                  DECODE (STATUS, 'REGISTERED', AVC_CONTR, 0)
                     REGISTERED_AVC_CONTR,
                  DECODE (STATUS, 'UNREGISTERED', AVC_CONTR, 0)
                     UNREGISTERED_AVC_CONTR,
                  DECODE (STATUS, 'REGISTERED', AVC_INTR, 0)
                     REGISTERED_AVC_INTR,
                  DECODE (STATUS, 'UNREGISTERED', AVC_INTR, 0)
                     UNREGISTERED_AVC_INTR,
                  DECODE (STATUS, 'REGISTERED', TRANSFER_AVC, 0)
                     REGISTERED_TRANSFER_AVC,
                  DECODE (STATUS, 'UNREGISTERED', TRANSFER_AVC, 0)
                     UNREGISTERED_TRANSFER_AVC,
                  DECODE (STATUS, 'REGISTERED', AVC_payments, 0)
                     REGISTERED_AVC_payments,
                  DECODE (STATUS, 'UNREGISTERED', AVC_payments, 0)
                     UNREGISTERED_AVC_payments
             FROM CLOSING_BALANCES                                     --where
                                                        --  member_id = 277073
                                                                        -- and
                                  -- asat = to_date('31/03/2016','dd/mm/yyyy')
          ) UNPIVOT (item_value
            FOR item_name
            IN  (REGISTERED_EE_BAL AS 'REGISTERED_EE_BAL',
                UNREGISTERED_EE_BAL AS 'UNREGISTERED_EE_BAL',
                REGISTERED_EE_RSV_INCOME AS 'REGISTERED_EE_RSV_INCOME',
                UNREGISTERED_EE_RSV_INCOME AS 'UNREGISTERED_EE_RSV_INCOME',
                REGISTERED_EE_BALINTR AS 'REGISTERED_EE_BALINTR',
                UNREGISTERED_EE_BALINTR AS 'UNREGISTERED_EE_BALINTR',
                REGISTERED_EE_CONTR AS 'REGISTERED_EE_CONTR',
                UNREGISTERED_EE_CONTR AS 'UNREGISTERED_EE_CONTR',
                REGISTERED_EE_INTR AS 'REGISTERED_EE_INTR',
                UNREGISTERED_EE_INTR AS 'UNREGISTERED_EE_INTR',
                REGISTERED_TRANSFER_EE AS 'REGISTERED_EE_TRANSFER',
                UNREGISTERED_TRANSFER_EE AS 'UNREGISTERED_EE_TRANSFER',
                REGISTERED_EE_PAYMENTS AS 'REGISTERED_EE_PAYMENTS',
                UNREGISTERED_EE_PAYMENTS AS 'UNREGISTERED_EE_PAYMENTS',
                REGISTERED_ER_BAL AS 'REGISTERED_ER_BAL',
                UNREGISTERED_ER_BAL AS 'UNREGISTERED_ER_BAL',
                REGISTERED_ER_RSV_INCOME AS 'REGISTERED_ER_RSV_INCOME',
                UNREGISTERED_ER_RSV_INCOME AS 'UNREGISTERED_ER_RSV_INCOME',
                REGISTERED_ER_BALINTR AS 'REGISTERED_ER_BALINTR',
                UNREGISTERED_ER_BALINTR AS 'UNREGISTERED_ER_BALINTR',
                REGISTERED_ER_CONTR AS 'REGISTERED_ER_CONTR',
                UNREGISTERED_ER_CONTR AS 'UNREGISTERED_ER_CONTR',
                REGISTERED_ER_INTR AS 'REGISTERED_ER_INTR',
                UNREGISTERED_ER_INTR AS 'UNREGISTERED_ER_INTR',
                REGISTERED_TRANSFER_ER AS 'REGISTERED_ER_TRANSFER',
                UNREGISTERED_TRANSFER_ER AS 'UNREGISTERED_ER_TRANSFER',
                REGISTERED_ER_PAYMENTS AS 'REGISTERED_ER_PAYMENTS',
                UNREGISTERED_ER_PAYMENTS AS 'UNREGISTERED_ER_PAYMENTS',
                REGISTERED_AVC_BAL AS 'REGISTERED_AVC_BAL',
                UNREGISTERED_AVC_BAL AS 'UNREGISTERED_AVC_BAL',
                REGISTERED_AVC_RSV_INCOME AS 'REGISTERED_AVC_RSV_INCOME',
                UNREGISTERED_AVC_RSV_INCOME AS 'UNREGISTERED_AVC_RSV_INCOME',
                REGISTERED_AVC_BALINTR AS 'REGISTERED_AVC_BALINTR',
                UNREGISTERED_AVC_BALINTR AS 'UNREGISTERED_AVC_BALINTR',
                REGISTERED_AVC_CONTR AS 'REGISTERED_AVC_CONTR',
                UNREGISTERED_AVC_CONTR AS 'UNREGISTERED_AVC_CONTR',
                REGISTERED_AVC_INTR AS 'REGISTERED_AVC_INTR',
                UNREGISTERED_AVC_INTR AS 'UNREGISTERED_AVC_INTR',
                REGISTERED_TRANSFER_AVC AS 'REGISTERED_AVC_TRANSFER',
                UNREGISTERED_TRANSFER_AVC AS 'UNREGISTERED_AVC_TRANSFER',
                REGISTERED_AVC_PAYMENTS AS 'REGISTERED_AVC_PAYMENTS',
                UNREGISTERED_AVC_PAYMENTS AS 'UNREGISTERED_AVC_PAYMENTS'))
--WHERE asat IS NOT NULL AND ROWNUM < 10000
/

