create view V_ASS_INVEST_TXNS as
  select
    txns.ID id,
    txns.TRANSACTION_TYPE,
    txns.AMOUNT,
    txns.TRANS_DATE,
    txns.PARTICULARS,
    txns.POSTED,
    txns.TRANS_FEES,
    txns.COST_OF_SALE,
    txns.PRICE_PER_SHARE,
    txns.REMARKS,
    txns.SETTLEMENT_DATE,
    txns.SHARES_BOUGHT,
    txns.SHARES_SOLD,
    txns.CHEQUE_NO,
    txns.RECEIPT_NUMBER,
    txns.DOC_REF_NO,
    case when txns.TRANSACTION_TYPE='EQUITY_ACQUISITION' then txns.SHARES_BOUGHT when txns.TRANSACTION_TYPE='EQUITY_SALE' then txns.SHARES_SOLD else txns.FACE_VALUE end face_value,
    txns.TRANSACTION_FEES,
    txns.SALE_COST,
    txns.BONDTRANS_TYPE,
    txns.BOND_TYPE,
    txns.SELLING_PRICE,
    txns.BALANCE,
    inv.QUANTITY,--from txns.RECEIPT_NO
    txns.TXN_REF_NO,
    txns.MONTH,
    txns.YEAR,
    txns.CURRENT_VALUE,
    txns.CONTRACT_NOTE_NO,
    txns.PNL_ON_SALE,
    txns.DISCNT_AMNT,
    txns.PRINCIPAL,
    txns.DATE_DECLARED,
    txns.DATE_PAID,
    txns.DIVIDEND_PER_SHARE,
    txns.DIVIDEND_TYPE,
    txns.SCHEME_ID,
    txns.CHANGE_INMARKET_PRICE,
    txns.PREV_VALUE,
    txns.SHARES_AT_VALUATION,
    txns.VALUATION_MRKTPRICE,
    txns.TRANS_TYPE,
    txns.APPROVED_DATE,
    txns.AUTHORIZED_DATE,
    txns.PREPARED_DATE,
    txns.CERTIFIED_DATE,
    prep.FIRSTNAME||' '||prep.OTHERNAMES PREPARER,
    auth.FIRSTNAME||' '||auth.OTHERNAMES AUTHORIZER,
    app.FIRSTNAME||' '||app.OTHERNAMES APPROVER,
    cert.FIRSTNAME||' '||cert.OTHERNAMES CERTIFIER,
    txns.NAME_OF_BUYER,
    txns.SALE_VALUE,
    txns.DATE_POSTED,
    fm.NAME FUND_MANAGER,
    comp.NAME COMPANY_NAME,
    txns.SRC_AMOUNT,
    txns.SPOT_RATE,
    txns.SALEORVALUGAINLOSS,
    inv.NAME INVESTMENT_NAME,
    inv.INVESTMENT_TYPE,
    inv.INVESTMENT_CATEGORY,
    inv.MARKET_VALUE,
    inv.FACE_VALUE,
    inv.ISSUER,
    inv.REDEEMED,
    case when inv.INVESTMENT_CATEGORY='EQUITY' then inv.VALUE_PER_SHARE else inv.COUPON_RATE end COUPON_RATE
  from INVESTMENT_TXNS txns
    INNER JOIN INVESTMENTS inv ON txns.INVESTMENT_ID = inv.ID
    LEFT JOIN USERS prep ON txns.APPROVEDBY_ID = prep.ID
    LEFT JOIN USERS auth ON txns.AUTHORIZEBY_ID = auth.ID
    LEFT JOIN USERS app ON txns.APPROVEDBY_ID = app.ID
    LEFT JOIN USERS cert ON txns.CERTIFIEDBY_ID = cert.ID
    LEFT JOIN FUND_MANAGERS fm ON inv.FUNDMANAGER_ID = fm.ID
    LEFT JOIN COMPANIES comp ON txns.COMPANY_ID=comp.ID
  WHERE inv.ID BETWEEN (select grp.INVEST_ID_FROM from V_GENERAL_REPORTS_PARAMS grp) and (select grp.INVEST_ID_TO from V_GENERAL_REPORTS_PARAMS grp)
        AND TRANS_DATE BETWEEN (select grp.DATE_FROM from V_GENERAL_REPORTS_PARAMS grp) and (select grp.DATE_TO from V_GENERAL_REPORTS_PARAMS grp)
        AND inv.SCHEME_ID=(select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) ORDER BY txns.TRANS_DATE
/

