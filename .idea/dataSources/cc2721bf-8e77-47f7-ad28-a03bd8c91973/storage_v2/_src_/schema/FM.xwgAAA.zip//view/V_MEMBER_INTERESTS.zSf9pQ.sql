create view V_MEMBER_INTERESTS as
  SELECT ap_id,
            member_id,
            SUM (
               DECODE (
                  STATUS,
                  'REGISTERED', (  NVL (ee_intr, 0)
                                 + NVL (EE_PAYMENTS_INTR, 0)
                                 + NVL (EE_WITHDR_INTR, 0)
                                 + NVL (transfer_ee_intr, 0)),
                  0))
               REG_Normal_EE_int,
            SUM (
               DECODE (
                  STATUS,
                  'UNREGISTERED', (  NVL (ee_intr, 0)
                                   + NVL (EE_PAYMENTS_INTR, 0)
                                   + NVL (EE_WITHDR_INTR, 0)
                                   + NVL (transfer_ee_intr, 0)),
                  0))
               UNREG_Normal_EE_int,
            SUM (
               DECODE (
                  STATUS,
                  'REGISTERED', (  NVL (er_intr, 0)
                                 + NVL (ER_WITHDR_INTR, 0)
                                 + NVL (TRANSFER_ER_INTR, 0)),
                  0))
               REG_Normal_ER_int,
            SUM (
               DECODE (
                  STATUS,
                  'UNREGISTERED', (  NVL (er_intr, 0)
                                   + NVL (ER_WITHDR_INTR, 0)
                                   + NVL (TRANSFER_ER_INTR, 0)),
                  0))
               UNREG_Normal_ER_int,
            SUM (
               DECODE (
                  STATUS,
                  'REGISTERED', (  NVL (AVCER_INTR, 0)
                                 + NVL (AVCER_WITHDR_INTR, 0)
                                 + NVL (AVC_INTR, 0)
                                 + NVL (AVC_WITHDR_INTR, 0)
                                 + NVL (TRANSFER_AVC_INTR, 0)
                                 + NVL (TRANSFER_AVCER_INTR, 0)),
                  0))
               REG_Combined_Avc_Int,
            SUM (
               DECODE (
                  STATUS,
                  'UNREGISTERED', (  NVL (AVCER_INTR, 0)
                                   + NVL (AVCER_WITHDR_INTR, 0)
                                   + NVL (AVC_INTR, 0)
                                   + NVL (AVC_WITHDR_INTR, 0)
                                   + NVL (TRANSFER_AVC_INTR, 0)
                                   + NVL (TRANSFER_AVCER_INTR, 0)),
                  0))
               UNREG_Combined_Avc_Int,
            SUM (
               DECODE (
                  STATUS,
                  'REGISTERED', (  NVL (ee_intr, 0)
                                 + NVL (er_intr, 0)
                                 + NVL (avc_intr, 0)
                                 + NVL (avcer_intr, 0)
                                 + NVL (AVC_WITHDR_INTR, 0)
                                 + NVL (AVCER_WITHDR_INTR, 0)
                                 + NVL (EE_PAYMENTS_INTR, 0)),
                  0))
               REG_total,
            SUM (
               DECODE (
                  STATUS,
                  'UNREGISTERED', (  NVL (ee_intr, 0)
                                   + NVL (er_intr, 0)
                                   + NVL (avc_intr, 0)
                                   + NVL (avcer_intr, 0)
                                   + NVL (AVC_WITHDR_INTR, 0)
                                   + NVL (AVCER_WITHDR_INTR, 0)
                                   + NVL (EE_PAYMENTS_INTR, 0)),
                  0))
               UNREG_total,
            SUM (
               DECODE (
                  STATUS,
                  'REGISTERED', (  NVL (ER_BALINTR, 0)
                                 + NVL (TRANSFER_ER_BALINTR, 0)),
                  0))
               REG_Opening_Bal_EE,
            SUM (
               DECODE (
                  STATUS,
                  'UNREGISTERED', (  NVL (ER_BALINTR, 0)
                                   + NVL (TRANSFER_ER_BALINTR, 0)),
                  0))
               UNREG_Opening_Bal_EE,
            SUM (
               DECODE (
                  STATUS,
                  'REGISTERED', (  NVL (EE_BALINTR, 0)
                                 + NVL (TRANSFER_EE_BALINTR, 0)),
                  0))
               REG_Opening_Bal_ER,
            SUM (
               DECODE (
                  STATUS,
                  'UNREGISTERED', (  NVL (EE_BALINTR, 0)
                                   + NVL (TRANSFER_EE_BALINTR, 0)),
                  0))
               UNREG_Opening_Bal_ER,
            SUM (
               DECODE (
                  STATUS,
                  'REGISTERED', (  NVL (AVCER_BALINTR, 0)
                                 + NVL (AVC_BALINTR, 0)
                                 + NVL (TRANSFER_AVC_BALINTR, 0)
                                 + NVL (TRANSFER_AVCER_BALINTR, 0)),
                  0))
               REG_Opening_Bal_Avc,
            SUM (
               DECODE (
                  STATUS,
                  'UNREGISTERED', (  NVL (AVCER_BALINTR, 0)
                                   + NVL (AVC_BALINTR, 0)
                                   + NVL (TRANSFER_AVC_BALINTR, 0)
                                   + NVL (TRANSFER_AVCER_BALINTR, 0)),
                  0))
               UNREG_Opening_Bal_Avc,
            SUM (
               DECODE (
                  STATUS,
                  'REGISTERED', (  NVL (EE_BAL, 0)
                                 + NVL (EE_WITHDR, 0)
                                 + NVL (AVC_BAL, 0)
                                 + NVL (AVCER_BAL, 0)
                                 + NVL (AVCER_WITHDR, 0)
                                 + NVL (AVC_WITHDR, 0)
                                 + NVL (ER_BAL, 0)
                                 + NVL (ER_WITHDR, 0)
                                 + NVL (EE_BALINTR, 0)
                                 + NVL (AVCER_BALINTR, 0)
                                 + NVL (AVC_BALINTR, 0)
                                 + NVL (ER_BALINTR, 0)
                                 + NVL (EE_CONTR, 0)
                                 + NVL (AVC_CONTR, 0)
                                 + NVL (AVCER_CONTR, 0)
                                 + NVL (ER_CONTR, 0)
                                 + NVL (EE_INTR, 0)
                                 + NVL (EE_WITHDR_INTR, 0)
                                 + NVL (AVCER_INTR, 0)
                                 + NVL (AVCER_WITHDR_INTR, 0)
                                 + NVL (AVC_INTR, 0)
                                 + NVL (AVC_WITHDR_INTR, 0)
                                 + NVL (ER_INTR, 0)
                                 + NVL (ER_WITHDR_INTR, 0)
                                 + NVL (er_payments, 0)
                                 + NVL (ee_payments, 0)
                                 + NVL (TRANSFER_ER, 0)
                                 + NVL (TRANSFER_ER_BAL, 0)
                                 + NVL (TRANSFER_ER_BALINTR, 0)
                                 + NVL (TRANSFER_ER_INTR, 0)
                                 + NVL (TRANSFER_EE, 0)
                                 + NVL (TRANSFER_EE_BAL, 0)
                                 + NVL (TRANSFER_EE_BALINTR, 0)
                                 + NVL (TRANSFER_EE_INTR, 0)
                                 + NVL (TRANSFER_AVC, 0)
                                 + NVL (TRANSFER_AVC_BAL, 0)
                                 + NVL (TRANSFER_AVC_BALINTR, 0)
                                 + NVL (TRANSFER_AVC_INTR, 0)
                                 + NVL (TRANSFER_AVCER_BALINTR, 0)
                                 + NVL (TRANSFER_AVCER_INTR, 0)
                                 + NVL (TRANSFER_AVCER, 0)
                                 + NVL (TRANSFER_AVCER_BAL, 0)
                                 + NVL (EE_RSV_INCOME, 0)),
                  0))
               REG_grand_Total,
            SUM (
               DECODE (
                  STATUS,
                  'UNREGISTERED', (  NVL (EE_BAL, 0)
                                   + NVL (EE_WITHDR, 0)
                                   + NVL (AVC_BAL, 0)
                                   + NVL (AVCER_BAL, 0)
                                   + NVL (AVCER_WITHDR, 0)
                                   + NVL (AVC_WITHDR, 0)
                                   + NVL (ER_BAL, 0)
                                   + NVL (ER_WITHDR, 0)
                                   + NVL (EE_BALINTR, 0)
                                   + NVL (AVCER_BALINTR, 0)
                                   + NVL (AVC_BALINTR, 0)
                                   + NVL (ER_BALINTR, 0)
                                   + NVL (EE_CONTR, 0)
                                   + NVL (AVC_CONTR, 0)
                                   + NVL (AVCER_CONTR, 0)
                                   + NVL (ER_CONTR, 0)
                                   + NVL (EE_INTR, 0)
                                   + NVL (EE_WITHDR_INTR, 0)
                                   + NVL (AVCER_INTR, 0)
                                   + NVL (AVCER_WITHDR_INTR, 0)
                                   + NVL (AVC_INTR, 0)
                                   + NVL (AVC_WITHDR_INTR, 0)
                                   + NVL (ER_INTR, 0)
                                   + NVL (ER_WITHDR_INTR, 0)
                                   + NVL (er_payments, 0)
                                   + NVL (ee_payments, 0)
                                   + NVL (TRANSFER_ER, 0)
                                   + NVL (TRANSFER_ER_BAL, 0)
                                   + NVL (TRANSFER_ER_BALINTR, 0)
                                   + NVL (TRANSFER_ER_INTR, 0)
                                   + NVL (TRANSFER_EE, 0)
                                   + NVL (TRANSFER_EE_BAL, 0)
                                   + NVL (TRANSFER_EE_BALINTR, 0)
                                   + NVL (TRANSFER_EE_INTR, 0)
                                   + NVL (TRANSFER_AVC, 0)
                                   + NVL (TRANSFER_AVC_BAL, 0)
                                   + NVL (TRANSFER_AVC_BALINTR, 0)
                                   + NVL (TRANSFER_AVC_INTR, 0)
                                   + NVL (TRANSFER_AVCER_BALINTR, 0)
                                   + NVL (TRANSFER_AVCER_INTR, 0)
                                   + NVL (TRANSFER_AVCER, 0)
                                   + NVL (TRANSFER_AVCER_BAL, 0)
                                   + NVL (EE_RSV_INCOME, 0)),
                  0))
               UNREG_grand_Total
       FROM CLOSING_BALANCES
   --where
   --    member_id = 280565
   --    and ap_id = 5985894
   GROUP BY ap_id, member_id
/

