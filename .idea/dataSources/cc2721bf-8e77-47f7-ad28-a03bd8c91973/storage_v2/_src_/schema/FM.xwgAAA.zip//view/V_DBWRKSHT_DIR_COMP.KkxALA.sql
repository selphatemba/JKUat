create view V_DBWRKSHT_DIR_COMP as
  SELECT
    (select SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) scheme_id,
    (select count(*) from V_DBWRKSHT_DIR_CH_LIST) count_children,
    (select count(*) from V_DBWRKSHT_DIR_SP_LIST) count_spouses,
    (select sum(coalesce(CHILD_ALLOC, 0)) from V_DBWRKSHT_DIR_CH_LIST) sum_children,
    (select sum(coalesce(SPOUSE_ALLOC, 0)) from V_DBWRKSHT_DIR_SP_LIST) sum_spouses
    FROM DUAL
/

