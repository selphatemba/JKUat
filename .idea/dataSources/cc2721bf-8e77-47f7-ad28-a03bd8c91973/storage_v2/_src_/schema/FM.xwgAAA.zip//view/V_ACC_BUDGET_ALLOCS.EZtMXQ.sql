create view V_ACC_BUDGET_ALLOCS as
  select ba.id, bi.NAME, bi.CODE, bi.TYPE, ap.FROM_DATE, ap.TO_DATE, coalesce(ba.AMOUNT, 0) budgeted, coalesce(ba.TRANSFER_IN, 0) transferIn, coalesce(ba.SUPLEMENT, 0), coalesce(ba.AMOUNT_USED, 0) used, coalesce(ba.TRANSFER_OUT, 0) transferOut, coalesce(ba.BALANCE, 0) balance, bi.SCHEME_ID, case when ba.BUDGET_TYPE=1 then 'Supplementary' else 'Initial' END budget_type, ba.ap_id, ba.FISCALYEAR_ID
  from BUDGET_ALLOCATIONS ba
    INNER JOIN BUDGET_ITEMS bi on ba.ITEM_ID = bi.ID
    INNER JOIN ACCOUNTING_PERIODS ap ON ba.AP_ID = ap.ID
  where ba.FISCALYEAR_ID=(select ap_id from V_GENERAL_REPORTS_PARAMS grp) and ba.AP_ID=(select ap_id from V_GENERAL_REPORTS_PARAMS grp) and ba.SCHEME_ID=(select grp.scheme_id from V_GENERAL_REPORTS_PARAMS grp)
/

