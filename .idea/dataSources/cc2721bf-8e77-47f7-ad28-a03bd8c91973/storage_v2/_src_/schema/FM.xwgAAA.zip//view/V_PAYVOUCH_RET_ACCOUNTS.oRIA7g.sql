create view V_PAYVOUCH_RET_ACCOUNTS as
  SELECT
    acc.SCHEME_ID scheme_id,
    acc.CODE code,
    acc.NAME,
    pay.ID,
    pay.PARTICULARS,
    coalesce(gl.DEBIT, 0) debit,
    coalesce(gl.CREDIT, 0) credit
  FROM STAFF_IMPREST si
    INNER JOIN STAFF_IMPREST_TYPES sit ON si.IMPRESTTYPE_ID = sit.ID
    LEFT JOIN PAYMENTS pay ON si.ID = pay.STAFFIMPREST_ID
    LEFT JOIN GL_BATCHES gb ON pay.GLBATCH_ID = gb.ID
    LEFT JOIN GL gl ON gb.ID = gl.GLBATCH_ID
    LEFT JOIN ACCOUNTS acc on gl.ACCOUNT_ID=acc.ID
  where si.ID=(select IMPREST_ID from V_GENERAL_REPORTS_PARAMS) ORDER BY gl.ID ASC
/

