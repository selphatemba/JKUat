create view V_PROV_OPENBAL_REG_D as
  with pa1 as (
      select (SELECT MEMBER_ID_FROM FROM V_GENERAL_REPORTS_PARAMS) member_id_p, (SELECT AP_ID FROM V_GENERAL_REPORTS_PARAMS) ap_id_p from dual
  ), pa0 as (
      select id from accounting_periods, pa1  p where  scheme_id=(select scheme_id from members where id = p.member_id_p) and id<p.ap_id_p  and period_type=(select period_type from accounting_periods where id = p.ap_id_p ) order by id desc
  ),pa2 as(
      select id prev_ap from pa0 where rownum=1
  )
  SELECT
    sum(coalesce(avc_bal,0)+coalesce(AVC_CONTR,0)+coalesce(avc_withdr_intr,0)+coalesce(avc_intr,0)+coalesce(avc_balintr,0)-coalesce(avc_withdr,0)+coalesce(avc_rsv_income,0)
        +coalesce(avcer_bal,0)+coalesce(avcer_contr,0)+coalesce(avcer_withdr_intr,0)+coalesce(avcer_balintr,0)+coalesce(avcer_intr,0)-coalesce(avc_withdr,0)+coalesce(avcer_rsv_income,0)
        +coalesce(transfer_avc_bal,0)+coalesce(transfer_avc_balintr,0)+coalesce(transfer_avc,0)+coalesce(transfer_avc_intr,0)
        +coalesce(transfer_avcer_bal,0)+coalesce(transfer_avcer_balintr,0)+coalesce(transfer_avcer,0)+coalesce(transfer_avcer_intr,0)
    )avcall,
    sum(coalesce(EE_BAL,0)+coalesce(ee_balintr,0)+ coalesce(EE_CONTR,0)+
        coalesce(ee_intr,0)-coalesce(EE_WITHDR,0)+coalesce(EE_WITHDR_INTR,0)+
        coalesce(ee_rsv_income,0)+coalesce(EE_PAYMENTS,0)+coalesce(EE_PAYMENTS_INTR,0)
        +coalesce(transfer_ee_bal,0)+ coalesce(transfer_ee,0)+coalesce(transfer_ee_intr,0)+
        coalesce(transfer_ee_balintr,0)+coalesce(reserve_income,0) ) ee_bal,
    sum(coalesce(ER_BAL,0)+coalesce(ER_CONTR, 0)-coalesce(ER_WITHDR, 0)+coalesce(ER_WITHDR_INTR, 0)
        +coalesce(ER_INTR, 0)+coalesce(er_balintr,0)+coalesce(er_rsv_income,0)+coalesce(ER_PAYMENTS,0)
        +coalesce(ER_PAYMENTS_INTR,0)
        +coalesce(transfer_er_bal, 0)+coalesce(transfer_er_balintr,0)+coalesce(transfer_er,0)+coalesce(transfer_er_intr,0)
    )er_bal,
    SUM((SELECT SCHEME_ID FROM V_GENERAL_REPORTS_PARAMS)+0) SCHEME_ID
  FROM CLOSING_BALANCES cb, pa2 p, pa1 where member_id = member_id_p and status = 'REGISTERED' and cb.AP_ID=(select grp.MS_APIDONE from V_GENERAL_REPORTS_PARAMS grp)
/

