create view V_BENEFICIARIES as
  SELECT ID ben_id,
          MEMBER_ID,
          FIRSTNAME || ' ' || OTHERNAMES || ' ' || SURNAME full_names,
          ID_NO,
          DATE_OF_APPOINTMENT,
          DOB,
          GENDER,
          GUARDIAN,
          GUARDIAN_RELATION,
          NVL (LUMPSUM_ENTITLEMENT, 0) LUMPSUM_ENTITLEMENT,
          MONTHLY_ENTITLEMENT,
          NOMINATION_FORM,
          INITCAP (RELATIONSHIP) RELATIONSHIP,
          INITCAP (STATUS) STATUS,
          INITCAP (RELSHIP_CATEGORY) RELSHIP_CATEGORY,
          DECODE (INITCAP (RELATIONSHIP),  'Wife', 1,  'Husband', 1,  0)
             RELATION_spouse,
          DECODE (INITCAP (RELATIONSHIP),  'Sister', 1,  'Brother', 1,  0)
             RELATION_sibling,
          DECODE (INITCAP (RELATIONSHIP),  'Daughter', 1,  'Son', 1,  0)
             RELATION_child,
          DECODE (INITCAP (RELATIONSHIP),  'Father', 1,  'Mother', 1,  0)
             RELATION_parrent,
          DECODE (INITCAP (RELATIONSHIP),  'Other', 1,  NULL, 1,  0)
             RELATION_other
     FROM beneficiaries
/

