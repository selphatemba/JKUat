create view V_PENSION_CERT_OF_EXT_LIST as
  select ce."ID",ce."ACCOUNTNAME",ce."CURR",ce."DATEPREPARED",ce."DATEPRINTED",ce."DATEREC",ce."DATERESTORED",ce."DEPCODE",ce."MEMBERNO",ce."MONPENSION",ce."PAYYEAR",ce."PENSIONERNAME",ce."PENNO",ce."POBPRINTED",ce."RECEIVED",ce."REMARKS",ce."RESTOREREASON",ce."RETURNDATE",ce."SCHEMENO",ce."APPROVED_DATE",ce."AUTHORIZED_DATE",ce."BOOKED_DATE",ce."REASON",ce."APPROVEDBY_ID",ce."AUTHORIZEBY_ID",ce."BOOKEDBY_ID",ce."PREPAREDBY_ID", uapp.FIRSTNAME||' '||uapp.OTHERNAMES approver, uauth.FIRSTNAME||' '||uauth.OTHERNAMES authorizer, ubked.FIRSTNAME||' '||ubked.OTHERNAMES booker, uprep.FIRSTNAME||' '||uprep.OTHERNAMES preparer
  from certificate_of_existence ce
    LEFT JOIN USERS uapp ON ce.APPROVEDBY_ID=uapp.ID
    LEFT JOIN USERS uauth ON ce.AUTHORIZEBY_ID=uauth.ID
    LEFT JOIN USERS ubked ON ce.BOOKEDBY_ID=ubked.ID
    LEFT JOIN USERS uprep ON ce.PREPAREDBY_ID=uprep.ID
  where ce.schemeno=(select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) AND ce.DATEPREPARED=(select grp.DATE_FROM from V_GENERAL_REPORTS_PARAMS grp) order by ce.penno
/

