create view V_MEMBER_AVC_BOTHREGUNREG as
  select
    MEMBER_NO, m.ID,M.FIRSTNAME||' '||M.SURNAME||' '||M.OTHER_NAMES NAME,
                    (coalesce(AVC_BAL,0)-coalesce(avc_withdr,0)) EE_BAL,
                    (coalesce(AVC_CONTR,0))  EE_CONTR,
                    (coalesce(AVC_INTR,0)+coalesce(avc_BALINTR,0)+coalesce(avc_withdr_intr,0)) EE_INTR,
                    ((coalesce(AVC_BAL,0))-(coalesce(avc_withdr,0))+(coalesce(AVC_CONTR,0))+(coalesce(AVC_INTR,0)+coalesce(avc_BALINTR,0)+coalesce(avc_withdr_intr,0)))EE_CLOSING,
                    (coalesce(AVCer_BAL,0))-(coalesce(avcer_withdr,0))Er_BAL,
                    (coalesce(AVCer_CONTR,0))  Er_CONTR,
                    (coalesce(AVCer_INTR,0)+coalesce(avcer_BALINTR,0)+coalesce(avcer_withdr_intr,0))  Er_INTR,
                    ((coalesce(AVCer_BAL,0))-(coalesce(avcer_withdr,0))+(coalesce(AVCer_CONTR,0))+(coalesce(AVCer_INTR,0)+coalesce(avcer_BALINTR,0)+coalesce(avcer_withdr_intr,0)))ER_CLOSING,
                    (SELECT MAX(TO_DATE) TO_DATE FROM accounting_periods WHERE parent_id = b.ap_id) AS_AT,
                    (select grp.AP_ID from V_GENERAL_REPORTS_PARAMS grp) apId,
                    (select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) schemeId,
                    (select grp.BALSTATUS from V_GENERAL_REPORTS_PARAMS grp) status
  from members m, closing_balances b where m.id = b.member_id and ap_id =(select grp.AP_ID from V_GENERAL_REPORTS_PARAMS grp) and  m.scheme_id = (select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp)
                                           and (((coalesce(AVC_BAL,0))-(coalesce(avc_withdr,0))+(coalesce(AVC_CONTR,0))+(coalesce(AVC_INTR,0)+coalesce(avc_BALINTR,0)+coalesce(avc_withdr_intr,0)))+((coalesce(AVCer_BAL,0))-(coalesce(avcer_withdr,0))+(coalesce(AVCer_CONTR,0))+(coalesce(AVCer_INTR,0)+coalesce(avcer_BALINTR,0)+coalesce(avcer_withdr_intr,0))))>0
/

