create view V_PAYREC_SUS_CURRENTAMOUNTTOT as
  with params as (
      select (SELECT MONTH FROM V_PAYREC_PARAMS) monthpar, (SELECT YEAR FROM V_PAYREC_PARAMS) yearpar from dual
  ), addparams as(
      select to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM')-1, 'MON') prevmonth,
             to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM')-1, 'YYYY') prevyear,
             to_char(trunc(to_date('01-'||par.monthpar||'-'||par.yearpar),'MM'), 'Month') monthlong,
        par.*
      from params par
  ), cachetab as(
      select * from payroll pay, addparams adp
      where (pay.year = adp.yearpar and pay.month = adp.monthpar) or (pay.month = adp.prevmonth and pay.year = adp.prevyear )
  ) , thispayroll as(
      select ct.* from cachetab ct, addparams adp where month = adp.monthpar and year = adp.yearpar
  ), lastpayroll as(
      select ct.* from cachetab ct, addparams adp where month = adp.prevmonth and year = adp.prevyear
  )
  SELECT (select PAYROLL_RECON_PARAMS.SCHEME_ID from PAYROLL_RECON_PARAMS) scheme_id,
         (select sum((coalesce(net,0)+coalesce(arreas,0))+(coalesce(deds,0)+coalesce(tax,0))) sus_currentamounttot  from pensioners pe inner join thispayroll tp on pe.id = tp.pensioner_id where tp.pension_status = 'SUSPENDED' and tp.account_no not in(select d.account_no from deductions d inner join thispayroll tp on  d.account_no = tp.account_no) and tp.pensioner_id not in ((select  lp.pensioner_id from lastpayroll lp where lp.pension_status = 'SUSPENDED' and (lp.pensioner_id not in (select tp.pensioner_id from thispayroll tp , pensioners p where tp.pensioner_id = p.id and p.pension_status = 'STOPPED' or p.pension_status ='DECEASED') or lp.pensioner_id  in (select distinct(tp.pensioner_id) from thispayroll tp  where (tp.pension_status = 'STOPPED' or tp.pension_status = 'DECEASED')))))) sus_currentamounttot from dual
/

