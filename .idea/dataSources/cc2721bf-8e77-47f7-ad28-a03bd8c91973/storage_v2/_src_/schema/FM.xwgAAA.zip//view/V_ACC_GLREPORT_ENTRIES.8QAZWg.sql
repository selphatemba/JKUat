create view V_ACC_GLREPORT_ENTRIES as
  select
    g.ID,
    g.SCHEME_ID,
    g.GL_DATE,
    coalesce(g.DEBIT, 0) debit,
    coalesce(g.CREDIT, 0) credit,
    g.DESCR,
    g.ACCOUNTINGPERIOD_ID apId,
    g.ACCOUNT_ID,
    g.GLBATCH_ID,
    g.REVERSED,
    g.REVERSAL,
    COALESCE(crdr.NAME, '-') creditorDebtorName
  from gl g
    INNER JOIN GL_BATCHES batch on g.GLBATCH_ID = batch.ID
    INNER JOIN payments p on batch.ID = p.GLBATCH_ID
    LEFT JOIN CREDITOR_DEBTOR crdr on p.CREDITORDEBTOR_ID = crdr.ID
  where g.ACCOUNT_ID=(SELECT grp.account_id FROM V_GENERAL_REPORTS_PARAMS grp)
        and g.GL_DATE BETWEEN (select grp.date_from from V_GENERAL_REPORTS_PARAMS grp)
        and (select grp.DATE_TO from V_GENERAL_REPORTS_PARAMS grp) ORDER BY g.GL_DATE ASC
/

