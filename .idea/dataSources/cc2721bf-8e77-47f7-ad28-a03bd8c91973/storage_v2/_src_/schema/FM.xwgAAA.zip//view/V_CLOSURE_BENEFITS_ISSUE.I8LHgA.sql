create view V_CLOSURE_BENEFITS_ISSUE as
  select 'YES' as status from dual
/

