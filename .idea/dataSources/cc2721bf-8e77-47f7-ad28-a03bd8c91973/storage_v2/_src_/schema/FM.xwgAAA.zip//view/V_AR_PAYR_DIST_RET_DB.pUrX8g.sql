create view V_AR_PAYR_DIST_RET_DB as
  with quarter as (
      select (select QUARTER from V_AR_PARAMS) q, (select SCHEME_ID from V_AR_PARAMS) scheme_id, (select YEAR FROM V_AR_PARAMS) yr from dual
  ),quarterdef as (
      select case
             when q = 1 then '01-JAN-'||''||qt.yr
             when q = 2 then '01-APR-'||''||qt.yr
             when q = 3 then '01-JUL-'||''||qt.yr
             when q = 4 then '01-OCT-'||''||qt.yr
             else ''
             end as from_date_qt,
             case
             when q = 1 then '31-MAR-'||''||qt.yr
             when q = 2 then '30-JUN-'||''||qt.yr
             when q = 3 then '30-SEP-'||''||qt.yr
             when q = 4 then '31-DEC-'||''||qt.yr
             else ''
             end as to_date_qt
      from quarter qt
  ), addparams as(
      select to_char(trunc(to_date(from_date_qt),'MM')-1, 'MON') prevmonth,
             to_char(trunc(to_date(from_date_qt),'MM')-1, 'YYYY') prevyear
      from quarterdef qd
  ),quarter_months as(
      SELECT to_char(ADD_MONTHS(TRUNC(TO_DATE(pe.from_date_qt, 'DD-MON-YYYY'), 'MON'), ROWNUM - 1),'MON') date_out
      FROM   DUAL, quarterdef pe
      CONNECT BY ADD_MONTHS(TRUNC(TO_DATE(pe.from_date_qt, 'DD-MON-YYYY'), 'MON'), ROWNUM - 1)
                 <= TRUNC(TO_DATE(pe.to_date_qt, 'DD-MON-YYYY'), 'MON')
  ), thispayroll1 as(
      select * from payroll pay, quarter qtr,quarterdef qd where
        (month = (select date_out from (select date_out,rownum as rn from (select date_out from quarter_months)) where rn = 1)
         or
         month = (select date_out from (select date_out,rownum as rn from (select date_out from quarter_months)) where rn = 2)
         or
         month = (select date_out from (select date_out,rownum as rn from (select date_out from quarter_months)) where rn = 3))
        and year = qtr.yr
  )
  select
    (select par.SCHEME_ID from V_AR_PARAMS par) scheme_id,
    (select (sum((coalesce(net,0)+coalesce(arreas,0))+(coalesce(deds,0)+coalesce(tax,0))) ) retirees  from thispayroll1 tp inner join pensioners pe on pe.id = tp.pensioner_id where pe.PENSIONER_TYPE = 'SELF' and tp.pension_status != 'SUSPENDED' and tp.account_no not in(select d.account_no from deductions d inner join thispayroll1 tp on  d.account_no = tp.account_no) and tp.pensioner_id not in ((select  lp.pensioner_id from payroll lp,addparams adp where month = adp.prevmonth and year = adp.prevyear and lp.pension_status = 'SUSPENDED' and (lp.pensioner_id not in (select tp.pensioner_id from thispayroll1 tp , pensioners p where tp.pensioner_id = p.id and p.pension_status = 'STOPPED' or p.pension_status = 'DECEASED') or lp.pensioner_id  in (select distinct(tp.pensioner_id) from thispayroll1 tp  where (tp.pension_status = 'STOPPED' or tp.pension_status = 'DECEASED')))))) RETIREES from dual
/

