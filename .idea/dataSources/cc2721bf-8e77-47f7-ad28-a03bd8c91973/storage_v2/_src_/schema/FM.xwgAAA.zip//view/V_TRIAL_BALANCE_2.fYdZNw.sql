create view V_TRIAL_BALANCE_2 as
  select ac.SCHEME_ID, ac.code,
    ac.name ||'('||frh.NAME||'->'||finRptHdDets.NAME||')' ac_name, ac.category, coalesce(debit_bal,0) dr, coalesce(credit_bal, 0) cr, gb.AP_ID
  from gl_account_balances gb, accounts ac left JOIN FIN_REPORTING_HEADER_DETS finRptHdDets ON ac.FRHD_ID = finRptHdDets.ID LEFT JOIN FINANCIAL_REPORTING_HEADERS frh on finRptHdDets.HEADER_ID = frh.ID
  where ap_id = (SELECT AP_ID FROM V_GENERAL_REPORTS_PARAMS) and ac.id = gb.account_id order by ac.category asc
/

