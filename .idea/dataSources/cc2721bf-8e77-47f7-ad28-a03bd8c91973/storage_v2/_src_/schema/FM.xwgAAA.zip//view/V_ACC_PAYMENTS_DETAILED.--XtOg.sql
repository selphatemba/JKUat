create view V_ACC_PAYMENTS_DETAILED as
  select
    p.ID,
    P.PARTICULARS,
    p.PMT_DATE,
    p.PAYMENT_NO,
    coalesce(p.CONTROL_AMT, 0)-(coalesce(p.WHVAT_AMOUNT, 0)+coalesce(p.WHTAX_AMOUNT, 0)) netpayment,
    p.SPOT_RATE,
    p.CONTROL_AMT*p.SPOT_RATE base_amount,
    curr.CODE CURRENCY,
    p.PAYMENT_MODE,
    sc.ACCOUNT_NAME cashbook,
    initcap(cd.NAME) creditor,
    initcap(cd.ACCOUNT_NAME),
    cd.ACCOUNT_NO,
    initcap(bb.NAME) branch_name,
    bb.CODE branch_code,
    initcap(b.NAME) bank_name,
    b.CODE bank_code,
    p.POSTED,
    p.POSTED_DATE
  from PAYMENTS p
    INNER JOIN CREDITOR_DEBTOR cd on p.CREDITORDEBTOR_ID = cd.ID
    INNER JOIN CURRENCIES curr on p.CURRENCY_ID=curr.ID
    LEFT JOIN SCHEME_BANKS sc on p.CASHBOOK_ID=sc.ID
    LEFT JOIN BANK_BRANCHES bb on cd.BANKBRANCH_ID = bb.ID
    LEFT JOIN BANKS b on bb.BANK_ID = b.ID
    LEFT JOIN users prep on p.PREPAREDBY_ID=prep.ID
    LEFT JOIN users cert on p.CERTIFIEDBY_ID=cert.ID
    LEFT JOIN users app on p.APPROVEDBY_ID=app.ID
  where p.PMT_DATE BETWEEN (select grp.DATE_FROM from V_GENERAL_REPORTS_PARAMS grp) and (select grp.DATE_TO from V_GENERAL_REPORTS_PARAMS grp) and p.SCHEME_ID=(select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp)
/

