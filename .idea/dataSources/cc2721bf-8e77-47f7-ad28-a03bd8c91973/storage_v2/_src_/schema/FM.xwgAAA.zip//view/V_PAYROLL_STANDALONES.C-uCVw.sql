create view V_PAYROLL_STANDALONES as
  SELECT b.id, b.code, b.name FROM BANKS b
  where b.STANDALONE_PAYPOINT='YES' and b.MAIN_PAYPOINT!='YES' and b.STATUS='ACTIVE' AND b.ACCOUNTNO is not NULL
/

