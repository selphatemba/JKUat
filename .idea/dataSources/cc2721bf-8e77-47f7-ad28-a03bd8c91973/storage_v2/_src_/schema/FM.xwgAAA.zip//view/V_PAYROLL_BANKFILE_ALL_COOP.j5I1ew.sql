create view V_PAYROLL_BANKFILE_ALL_COOP as
  select
    (select 'COOPERATIVE_BANK' from dual) member_no,
    al.BANK_CODE,
    (select '01240000025094' from dual) ac_no,
    (select 'E-CHANNELS' from dual) ac_name,
    al.BANKBRANCH_ID,
    al.TRANSFER_CODE,
    al.BRANCH_CODE,
    (select a.PAYROLL_DATE from V_PAYROLL_BANKFILE_3X a where ROWNUM=1) payroll_date,
    (select sum(al.PENSION) from V_PAYROLL_BANKFILE_3X al INNER JOIN BANKS b on al.BANK_CODE=b.CODE where b.CODE='11') PENSION,
    (select a.COMMENTS from V_PAYROLL_BANKFILE_3X a where ROWNUM=1) COMMENTS,
    PENSIONER_ID
  from V_PAYROLL_BANKFILE_3X al INNER JOIN BANKS b on al.BANK_CODE=b.CODE where b.CODE='11' AND ROWNUM=1
/

