create view V_MEM_BEN_LISTING as
  SELECT b.ID ben_id,
    MEMBER_ID,
         b.FIRSTNAME || ' ' || OTHERNAMES || ' ' || b.SURNAME full_names,
    b.ID_NO,
    DATE_OF_APPOINTMENT,
    b.DOB,
         decode(b.GENDER, 'MALE', 'Male', 'FEMALE', 'Female') gender,
    GUARDIAN,
    GUARDIAN_RELATION,
         NVL (LUMPSUM_ENTITLEMENT, 0) LUMPSUM_ENTITLEMENT,
    MONTHLY_ENTITLEMENT,
    NOMINATION_FORM,
    INITCAP (case when upper(RELATIONSHIP)='WIFE' then 'SPOUSE' when upper(RELATIONSHIP)='HUSBAND' then 'SPOUSE' when upper(RELATIONSHIP)='SON' then 'CHILD' when upper(RELATIONSHIP)='DAUGHTER' then 'CHILD' else '' END) RELATIONSHIP,
         INITCAP (STATUS) STATUS,
         INITCAP (RELSHIP_CATEGORY) RELSHIP_CATEGORY,
         DECODE (INITCAP (RELATIONSHIP),  'Wife', 1,  'Husband', 1,  0)
           RELATION_spouse,
         DECODE (INITCAP (RELATIONSHIP),  'Sister', 1,  'Brother', 1,  0)
           RELATION_sibling,
         DECODE (INITCAP (RELATIONSHIP),  'Daughter', 1,  'Son', 1,  0)
           RELATION_child,
         DECODE (INITCAP (RELATIONSHIP),  'Father', 1,  'Mother', 1,  0)
           RELATION_parrent,
         DECODE (INITCAP (RELATIONSHIP),  'Other', 1,  NULL, 1,  0)
           RELATION_other,
         FLOOR ( (SYSDATE - NVL (b.DOB, b.dob)) / 365)age,
         b.CELL_PHONE BEN_PHONE,
    m.SCHEME_ID,
    m.MEMBER_NO
  FROM beneficiaries b
    LEFT JOIN MEMBERS m ON b.MEMBER_ID = m.ID where m.SCHEME_ID=(select SCHEME_ID from V_GENERAL_REPORTS_PARAMS) AND UPPER(b.STATUS)!='DIVORCED' AND UPPER(b.STATUS)!='DECEASED'
/

