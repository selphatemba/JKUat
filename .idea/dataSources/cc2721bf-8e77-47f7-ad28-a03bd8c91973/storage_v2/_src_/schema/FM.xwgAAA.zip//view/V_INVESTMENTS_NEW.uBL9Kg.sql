create view V_INVESTMENTS_NEW as
  select
    i.INVESTMENT_TYPE,
    i.ID,
    i.ACCRUEDINTEREST,
    i.ACCUM_INTEREST_BKD,
    i.DATE_REDEEMED,
    i.INITIAL_VALUE,
    i.INTEREST_AT_REDEMPTION,
    i.INV_REDEEMED,
    i.INVESTMENT_CATEGORY,
    i.LASTINTRDATEBOOK,
    i.LAST_INTRCALCDATE,
    i.LAST_TXN_DATE,
    i.LAST_VALUE_DATE,
    i.LOCALITY,
    i.MARKET_VALUE,
    i.MATURED,
    i.NAME,
    i.QUANTITY,
    i.REDEEMED,
    i.REF_CODE,
    i.SOLD,
    coalesce(case when i.INVESTMENT_TYPE='EQUITY' then
      (select ep.ACTUAL_PRICE from EQUITY_PRICES ep where ROWNUM=1 and ep.LISTEDCOMPANY_ID=lc.ID and ep.AS_AT=(select max(AS_AT) from EQUITY_PRICES e where e.LISTEDCOMPANY_ID=lc.ID))
             else i.VALUE_PER_SHARE END, 0) VALUE_PER_SHARE,
    i.DEAL_DATE,
    i.SETTLMNT_DATE,
    i.FACE_VALUE,
    i.HANDLING_FEES,
    i.INTEREST_FREQUENCY,
    i.INTEREST_START_DATE,
    i.INTEREST_TYPE,
    issuer.NAME issuer_name,
    issuer.CODE issuer_code,
    i.MATURITY_DATE,
    i.COUPON_RATE,
    i.CUMULATIVE_COST,
    i.DAYSINAYEAR,
    i.SUB_CLASS,
    i.VALUATION_INDEX,
    fm.NAME fundmanager_name,
    i.SCHEME_ID,
    lc.NAME listedcompany_name,
    lc.CODE listedcompnay_code
  from INVESTMENTS i
    LEFT JOIN APPROVED_ISSUERS issuer on i.APPROVEDISSUER_ID = issuer.ID
    LEFT JOIN FUND_MANAGERS fm on i.FUNDMANAGER_ID = fm.ID
    LEFT JOIN LISTED_COMPANIES lc on i.LISTEDCOMPANY_ID=lc.ID
  where i.INVESTMENT_TYPE = (select grp.investmentclass from V_GENERAL_REPORTS_PARAMS grp) AND i.SCHEME_ID = (select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp)
/

