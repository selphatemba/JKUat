create view V_DBWRKSHT_DIS_BEN_ALLOC as
  with param as (
      select (select grp.BENEFITS_ID from V_GENERAL_REPORTS_PARAMS grp) exit_param from dual
  )
  select
    (select grp.SCHEME_ID from V_GENERAL_REPORTS_PARAMS grp) SCHEME_ID,
    (select coalesce(sum(coalesce(monthly_pension,0)),0) monthly_pension from pensioners pe, param pa where member_id = (select id from members, param pi where exit_id = pi.exit_param AND approved='YES' and rownum=1)  and beneficiary_id in (select id from beneficiaries where relationship = 'Daughter' or relationship = 'Son')) child_monthly,
    (select count(*) from beneficiaries be, param pa where be.member_id = (select id from members, param pi where exit_id = pi.exit_param AND approved='YES' and rownum=1) and (relationship = 'DAUGHTER' or relationship = 'SON') and status='ELIGIBLE') children,
    (select count(*) from beneficiaries be, param pa where be.member_id = (select id from members, param pi where exit_id = pi.exit_param AND approved='YES' and rownum=1) and (relationship = 'WIFE' or relationship = 'HUSBAND') and status='ELIGIBLE') spouses,
    (select coalesce(sum(coalesce(monthly_pension,0)),0) monthly_pension from pensioners pe, param pa where member_id = (select id from members, param pi where exit_id = pi.exit_param AND approved='YES' and rownum=1)  and beneficiary_id in (select id from beneficiaries where relationship = 'Spouse')) spouse_monthly,
    (select PENSION_START_DATE from pensioners where member_id = (select id from members, param pi where exit_id = pi.exit_param AND approved='YES' and rownum=1)) effective_date
  from dual
/

