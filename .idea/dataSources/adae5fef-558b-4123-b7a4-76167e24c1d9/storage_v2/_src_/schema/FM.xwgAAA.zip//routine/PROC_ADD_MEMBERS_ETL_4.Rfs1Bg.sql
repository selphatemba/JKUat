create procedure proc_add_members_ETL_4 is
  v_scheme_id number(19);
  v_member_no VARCHAR2(20);
  v_m_id number(19);
  v_Sponsor_id number(19);
  v_company_id number(19);
  v_mclass_id number(19);
  v_Orig_ID number(19);
  v_sponsor_Number VARCHAR2(20);

  cursor cont_kengen1 is
    select distinct(select s.id from SPONSORS s where s.SCHEME_ID=m.SCHEME_ID and ROWNUM=1) as sponsorId, m.scheme_id,m.member_no,m.id from ETL_MEMBERS_1 m inner join ETL_CLAIMS_3 et
on m.MEMBER_NO=et.MEMBERNO
and et.MEMBERNO in (
    select distinct MEMBERNO from ETL_CLAIMS_3 where id not in(select COMMENTS from BENEFIT_PAYMENTS)
    group by SPONSORCODE,MEMBERNO,SCHEMENO

  ) and m.SCHEME_ID=et.SCHEMENO and MEMBER_NO not in(select mm.member_no from MEMBERS mm where mm.MEMBER_NO=et.MEMBERNO and mm.SCHEME_ID=et.SCHEMENO) ORDER BY m.ID DESC;

  begin
    open cont_kengen1;
    loop
      fetch cont_kengen1 into v_Sponsor_id,v_scheme_id, v_member_no,v_Orig_ID;

      exit when cont_kengen1%notfound;

      select min(id) into v_company_id from Companies where sponsor_id = v_Sponsor_id;

      select MIN(mc.ID) into v_mclass_id from MEMBER_CLASSES mc where sponsor_id = v_Sponsor_id and ROWNUM=1 ;

      select hibernate_sequence.nextval into v_m_id from dual;

      if v_company_id is null then
        v_company_id := 0;
      end if;

      commit;

      if (v_company_id > 0) then
        begin
          Insert into MEMBERS_BIOS (ID,CELL_PHONE,COUNTRY,EMAIL,POSTAL_ADDRESS
            ,GENDER
            , SURNAME,TITLE, FIRSTNAME,DOB
          )
            SELECT v_m_id,CELL_PHONE,COUNTRY,EMAIL,POSTAL_ADDRESS,
              GENDER,SURNAME,TITLE, FIRSTNAME,DOB FROM ETL_MEMBERS_1 WHERE ID =v_Orig_ID;
          COMMIT;

          Insert into Members (MEMBER_NO,ID,BUILDING,CELL_PHONE,COUNTRY,EMAIL,FAX,FIXED_PHONE,POSTAL_ADDRESS,ROAD,TELEX,TOWN,CUR_PENS_SAL,DATE_JOINED_SCHEME,
                               DATE_OF_EMPL,DEPARTMENT_NO,DOB,GENDER,ID_NO,ID_TYPE,MARTL_STATUS,MBSHIP_STATUS,OTHER_NAMES,  PIN,
                               SURNAME,TITLE,COMPANY_ID,SCHEME_ID, FIRSTNAME,DATE_PREPARED,DATES_CONFIRMED,APPROVED,MEMBERSHIP_NO,QUOTE_NO,STAFF_NO,
                               MEMBERBIO_ID,ALLOW_NOTIFICATIONS)
            SELECT MEMBER_NO,hibernate_sequence.nextval,BUILDING,CELL_PHONE,COUNTRY,EMAIL,FAX,FIXED_PHONE,POSTAL_ADDRESS,ROAD,TELEX,TOWN,CUR_PEN_SAL,DATE_OF_EMPL,
              DATE_OF_EMPL,DEPARTMENT_NO, DOB,GENDER,ID_NO,ID_TYPE,MARTL_STATUS,MBSHIP_STATUS,OTHER_NAMES, PIN,
              SURNAME,TITLE,v_company_id,SCHEME_ID, FIRSTNAME,DATE_OF_CALCULATION,DATES_CONFIRMED,
              APPROVED,v_member_no,v_Orig_ID,STAFF_NO,v_m_id,1 FROM ETL_MEMBERS_1 WHERE  ID = v_Orig_ID;

          COMMIT;

        end;
      end if;

      commit;

      v_Sponsor_id := 0;
      v_company_id := 0;
      v_scheme_id := 0;
      v_member_no := 0;

    end loop;
    close cont_kengen1;
  end;
/

