create PROCEDURE      "PROC_ADD_MEMBERS" is
v_scheme_id number(19);
v_member_no number(19);
v_m_id number(19);
v_sponsorname varchar2(100);
v_Sponsor_id number(19);
v_company_id number(19);
v_Exists number(19);
v_MEMBERSHIP_NO number(19);

cursor cont_kengen1 is 
SELECT distinct m.scheme_id,m.id,m.MEMBER_NO,(select s.id from SPONSORS s where s.SCHEME_ID=m.SCHEME_ID and ROWNUM=1) as sponsorId
from ETL_MEMBERS_1 m where  m.member_no not in (select membership_no from members)
ORDER BY m.ID DESC;

begin
  open cont_kengen1;
  loop
    fetch cont_kengen1 into v_scheme_id, v_member_no,v_MEMBERSHIP_NO,v_Sponsor_id;

    exit when cont_kengen1%notfound;
    
    select min(id) into v_company_id from Companies where sponsor_id = v_Sponsor_id; 
    
    select hibernate_sequence.nextval into v_m_id from dual;
    

    if v_company_id is null then
       v_company_id := 0;
    end if;
    
    --dbms_output.put_line('COMPANY ID '|| v_company_id);
    --dbms_output.put_line('ID '|| v_m_id);
    --dbms_output.put_line('MEMBER NO '|| v_member_no);
    
    --dbms_output.put_line('SCHEME ID '|| v_scheme_id);
    --dbms_output.put_line('MEMBERSHIP_NO '|| v_MEMBERSHIP_NO);
    
    
    select count(*) into   v_Exists
    from   Members
    where  rownum = 1 and scheme_id = v_Scheme_ID and MEMBERSHIP_NO =  v_MEMBERSHIP_NO;
    
    if (v_Exists = 1) then
         begin
           v_Exists := 0;
         end;
      else 
         begin
            Insert into Members (MEMBER_NO,ID,CELL_PHONE,COUNTRY,EMAIL,FIXED_PHONE,POSTAL_ADDRESS,TOWN,CUR_PENS_SAL,DATE_JOINED_SCHEME,
            DATE_OF_EMPL,DOB,GENDER,ID_NO,ID_TYPE,MARTL_STATUS,MBSHIP_STATUS,OTHER_NAMES,  PIN, 
            SURNAME,TITLE,COMPANY_ID,SCHEME_ID, FIRSTNAME,DATE_PREPARED,DATES_CONFIRMED,APPROVED,MEMBERSHIP_NO)
            SELECT MEMBER_NO,hibernate_sequence.nextval,CELL_PHONE,COUNTRY,EMAIL,FIXED_PHONE,POSTAL_ADDRESS,TOWN,CUR_PEN_SAL,DATE_OF_EMPL,
            DATE_OF_EMPL, DOB,GENDER,ID_NO,ID_TYPE,MARTL_STATUS,MBSHIP_STATUS,OTHER_NAMES, PIN, 
            SURNAME,TITLE,v_company_id,SCHEME_ID, FIRSTNAME,DATE_OF_CALCULATION,DATES_CONFIRMED,
            APPROVED,MEMBER_NO FROM ETL_MEMBERS WHERE SCHEME_ID = v_scheme_id AND ID = v_member_no;
            
            dbms_output.put_line('MEMBERSHIP_NO '|| v_MEMBERSHIP_NO);
         end;
      end if;
      
      --desc ETL_MEMBERS;
      --desc Members;
     
    commit;
    
    v_Sponsor_id := 0;
    v_company_id := 0;
    v_scheme_id := 0;
    v_member_no := 0;
    v_sponsorname :='';
    v_Exists := 0;
    v_MEMBERSHIP_NO := 0;
    
  end loop;
  close cont_kengen1;
end;
/

