create procedure Proc_Load_ETL_Claims_3 is
V_MEMBERNO NUMBER(19);
V_CONTRYEAR NUMBER(19);
V_DATEPAID DATE;
V_EMPLOYEE NUMBER(19,2);
V_EMPLOYER NUMBER(19,2);
V_AVC NUMBER(19,2);
V_AVCEMPLOYER NUMBER(19,2);
V_APID NUMBER(19);
V_SCHEME_ID NUMBER(19);
v_ID NUMBER(19);
v_Member_ID number(19);
v_Month_Name varchar2(10);
V_FULLNAME VARCHAR2(100);
V_SPONSORNAME VARCHAR2(100);
V_REASONFOREXIT VARCHAR2(100);
V_BEN_ID NUMBER(19);
v_Status varchar(50);

--desc ETL_CLAIMS commit

cursor cont_kengen1 is 
SELECT  m.scheme_id, m.ID as Member_ID,c.Employee,c.Employer,c.AVC,c.AVCEMPLOYER,c.fullname,c.docalc, c.BenTYPE,
        c.month_name,c.Month_Year 
FROM ETL_CLAIMS C
     inner join Members m on c.membernO = m.membership_no
order by c.memberNo;


begin
  open cont_kengen1;
  loop
    fetch cont_kengen1 into V_SCHEME_ID,v_Member_ID,V_EMPLOYEE, V_EMPLOYER,V_AVC,V_AVCEMPLOYER,V_FULLNAME,V_DATEPAID,
	                        v_Status, v_Month_Name,V_CONTRYEAR;
    
    exit when cont_kengen1%notfound;
    
    
    select MIN(ID) into V_APID FROM ACCOUNTING_PERIODS WHERE scheme_Id = V_SCHEME_ID 
	  and V_DATEPAID >= FROM_DATE AND  V_DATEPAID <= TO_DATE AND PERIOD_TYPE = 'FISCAL_YEAR';

    --dbms_output.put_line('-----------------------------------------------MEMBER ID-------------------------------------------------- '|| v_Member_ID);
    --dbms_output.put_line('-----------------------------------------------MEMBER NUMBER-------------------------------------------------- '|| V_MEMBERNO);
    --dbms_output.put_line('--------------------------------------------ACCOUNTING PERIOD-------------------------------------------------- '|| V_APID);
    
    --select CONSTRAINT_NAME, TABLE_NAME from all_constraints where CONSTRAINT_NAME = 'FK_7LN1PD4UIOOQ12KURHEI3WVVO';
    --ALTER TABLE BENEFITS DISABLE CONSTRAINT "FK_7LN1PD4UIOOQ12KURHEI3WVVO";
    --COMMIT;

    if V_APID > 0 then
    BEGIN
    
       Insert into Contributions (ID,MEMBER_ID,AVC,AVCER,EE,ER,DATE_PAID,DEFICIT,DEFICIT_PENALTY,TAXFREE_EE_AMOUNT,TAXFREE_ER_AMOUNT,EEUNREG,
                           GROUP_LIFE,LIFE_COVER,MONTH,PENALTY,SALARY, SALARY_TYPE,SAVING_EE, SAVING_ER,STATUS,TRANSFER_DEF_AMOUNT,
                           TRANSFER_TAXFREE_UTILIZED,TYPE,UNIT_PRICE,UNITS,YEAR,ACCOUNTINGPERIOD_ID,NSSF)

               values(hibernate_sequence.nextval,v_Member_ID,V_AVC,V_AVCEMPLOYER,V_EMPLOYEE,V_EMPLOYER,V_DATEPAID,0,0,0,0,0,
                      0,0,v_Month_Name,0,0,'GIVEN',0,0,v_Status,0,0,'WITHDRAWAL',0,0,V_CONTRYEAR,V_APID,0);

      --alter table Benefits add Member_Id number(19);
      
      commit; 
	  
	  SELECT hibernate_sequence.nextval INTO V_BEN_ID FROM DUAL;

	  Insert into Benefits(ID,AVC,AVC_BAL,AVC_TOT_ONLY, AVCER,AVCER_BAL,AVCER_TOT_ONLY,EE,EE_BAL,EE_TOT,EE_TOT_ONLY,ENTITLEMENT,
	                       ER,ER_BAL,ER_TOT,ER_TOT_ONLY,TOT_BENEFITS,YEARS_WORKED,REASONFOREXIT_ID,DATE_OF_CALCULATION,DATE_OF_EXIT,
						   AGE_AT_EXIT,MEMBER_ID,MEMBER_NO)

                  VALUES(V_BEN_ID,V_AVC,V_AVC,V_AVC,V_AVCEMPLOYER,V_AVCEMPLOYER,V_AVCEMPLOYER,V_EMPLOYEE,V_EMPLOYEE,V_EMPLOYEE,V_EMPLOYEE,
                         100,V_EMPLOYER,V_EMPLOYER,V_EMPLOYER,V_EMPLOYER,V_AVC+V_AVCEMPLOYER+V_EMPLOYEE+V_EMPLOYER,
                         0,0,V_DATEPAID,V_DATEPAID,0,v_Member_ID,V_MEMBERNO);
     
     commit;
     --v_Payment := 0-v_Payment;

	   insert into Benefit_Payments(ID,DATE_OF_CALC,DATE_PROCESSED,IS_FIRST_PAYMENT,GROSS,IS_TRUST_FUND,LUMPSUM,LUMPSUM_TAX_FREE,
	                                REG_EE, REG_ER,REG_AVC,REG_AVCER,REG_NET,REG_TAX,PAYEE,MEMBER_ID,SCHEME_ID,
									                TYPE,BENEFIT_ID)
        
	               VALUES(hibernate_sequence.nextval,V_DATEPAID,V_DATEPAID,0,V_AVC+V_AVCEMPLOYER+V_EMPLOYEE+V_EMPLOYER,'NO', 
                        V_AVC+V_AVCEMPLOYER+V_EMPLOYEE+V_EMPLOYER,V_AVC+V_AVCEMPLOYER+V_EMPLOYEE+V_EMPLOYER,V_EMPLOYEE,V_EMPLOYER,
                        V_AVC,V_AVCEMPLOYER,V_AVC+V_AVCEMPLOYER+V_EMPLOYEE+V_EMPLOYER,0,V_FULLNAME,v_Member_ID,V_SCHEME_ID,
                        'WITHDRAWAL',V_BEN_ID);
         
    commit;
    
    END;
    END IF;
    
    V_BEN_ID := 0;
    
  end loop;
  close cont_kengen1;
end;


/

