create procedure Proc_Load_Acct_Periods_3 is
v_Scheme_ID number(19);
v_Count number(19);
v_ID number(19);
v_Max_ID number(19);
v_Exists number(19);


cursor cont_kengen1 is  
select DISTINCT scheme_id from sponsors;-- WHERE SCHEME_ID = 1355;

begin
  open cont_kengen1;
  loop
    fetch cont_kengen1 into v_Scheme_ID;
    
    exit when cont_kengen1%notfound;
    
    v_Max_ID := 0;
    
	IF v_Scheme_ID < 1359 THEN
     select max(SEQ) into v_Max_ID from ACCOUNTING_PERIODS where SCHEME_ID = v_Scheme_ID;
	ELSE
	   v_Max_ID:= 0;
	END IF;

      select count(*)
      into   v_Exists
      from   ACCOUNTING_PERIODS
      where  rownum = 1 and scheme_id = v_Scheme_ID and from_date = TO_DATE('01-JAN-10') and PERIOD_TYPE = 'FISCAL_YEAR';

      dbms_output.put_line('EXISTS 2010 '|| v_Exists);
     
      if (v_Exists = 1) then
         begin
            v_Exists := 0;
         end;
      else 
         begin
            if (v_Scheme_ID < 1359) then
               begin
                  v_Count := hibernate_sequence.nextval;

                  insert into ACCOUNTING_PERIODS(ID, FROM_DATE,PERIOD_STATUS,PERIOD_TYPE,SEQ,TO_DATE,PARENT_ID, SCHEME_ID)
                  select v_Count,TO_DATE('01-JAN-10'),'OPEN','FISCAL_YEAR',v_Max_ID,TO_DATE('31-DEC-10'),v_Count, v_Scheme_ID FROM DUAL;
            
			            COMMIT;
               end;
            end if;
         end;
      end if;
      
      v_Max_ID:= v_Max_ID + 1;
      v_Exists := 0;
      v_Count := hibernate_sequence.nextval;
      
      select count(*)
      into   v_Exists
      from   ACCOUNTING_PERIODS
      where  rownum = 1 and scheme_id = v_Scheme_ID and from_date = TO_DATE('01-JAN-11') and PERIOD_TYPE = 'FISCAL_YEAR';

      dbms_output.put_line('EXISTS 2011 '|| v_Exists);
      
      if (v_Exists = 1) then
         begin
            v_Exists := 0;
         end;
      else 
        begin
            if (v_Scheme_ID < 1359) then
                begin
                   v_Count := hibernate_sequence.nextval;

                   insert into ACCOUNTING_PERIODS(ID, FROM_DATE,PERIOD_STATUS,PERIOD_TYPE,SEQ,TO_DATE,PARENT_ID, SCHEME_ID)
                   select v_Count,TO_DATE('01-JAN-11'),'OPEN','FISCAL_YEAR',v_Max_ID,TO_DATE('31-DEC-11'),v_Count, v_Scheme_ID FROM DUAL;
            
                   COMMIT;
               end;
            end if;
        end;
      end if;
      
      v_Max_ID:= v_Max_ID + 1;
      v_Exists := 0;
      v_Count := hibernate_sequence.nextval;
      
      select count(*)
      into   v_Exists
      from   ACCOUNTING_PERIODS
      where  rownum = 1 and scheme_id = v_Scheme_ID and from_date = TO_DATE('01-JAN-12') and PERIOD_TYPE = 'FISCAL_YEAR';

      dbms_output.put_line('EXISTS 2012 '|| v_Exists);
      
      if (v_Exists = 1) then
         begin
           v_Exists := 0; 
         end;
      else 
         begin
            if (v_Scheme_ID < 1359) then
               begin
                   v_Count := hibernate_sequence.nextval;

                   insert into ACCOUNTING_PERIODS(ID, FROM_DATE,PERIOD_STATUS,PERIOD_TYPE,SEQ,TO_DATE,PARENT_ID, SCHEME_ID)
                   select v_Count,TO_DATE('01-JAN-12'),'OPEN','FISCAL_YEAR',v_Max_ID,TO_DATE('31-DEC-12'),v_Count, v_Scheme_ID FROM DUAL;
            
			             COMMIT;
              end;
            end if;
         end;
      end if;
      
      v_Max_ID:= v_Max_ID + 1;
      v_Exists := 0;
      v_Count := hibernate_sequence.nextval;
      
      select count(*)
      into   v_Exists
      from   ACCOUNTING_PERIODS
      where  rownum = 1 and scheme_id = v_Scheme_ID and from_date = TO_DATE('01-JAN-13') and PERIOD_TYPE = 'FISCAL_YEAR';

      dbms_output.put_line('EXISTS 2013 '|| v_Exists);
    
      if (v_Exists = 1) then
         begin
            v_Exists := 0;
         end;
      else 
         begin
            if (v_Scheme_ID < 1359) then
                begin
                   v_Count := hibernate_sequence.nextval;

                   insert into ACCOUNTING_PERIODS(ID, FROM_DATE,PERIOD_STATUS,PERIOD_TYPE,SEQ,TO_DATE,PARENT_ID, SCHEME_ID)
                   select v_Count,TO_DATE('01-JAN-13'),'OPEN','FISCAL_YEAR',v_Max_ID,TO_DATE('30-JUN-13'),v_Count, v_Scheme_ID FROM DUAL;
            
			             COMMIT;
               end;
            end if;
         end;
      end if;
      
      v_Max_ID:= v_Max_ID + 1;
      v_Exists := 0;
      v_Count := hibernate_sequence.nextval;
      
      select count(*)
      into   v_Exists
      from   ACCOUNTING_PERIODS
      where  rownum = 1 and scheme_id = v_Scheme_ID and from_date = TO_DATE('01-JUL-13') and PERIOD_TYPE = 'FISCAL_YEAR';

      dbms_output.put_line('EXISTS 2013 JUL '|| v_Exists);
      
      if (v_Exists = 1)  then
         begin
           v_Exists := 0; 
         end;
      else 
         begin
            if (v_Scheme_ID < 1359) then
               begin
                  v_Count := hibernate_sequence.nextval;

                  insert into ACCOUNTING_PERIODS(ID, FROM_DATE,PERIOD_STATUS,PERIOD_TYPE,SEQ,TO_DATE,PARENT_ID, SCHEME_ID)
                  select v_Count,TO_DATE('01-JUL-13'),'OPEN','FISCAL_YEAR',v_Max_ID,TO_DATE('30-JUN-14'),v_Count, v_Scheme_ID FROM DUAL;
            
			            COMMIT;
               end;
            end if;
         end;
      end if;
      
      v_Max_ID:= v_Max_ID + 1;
      v_Exists := 0;
      v_Count := hibernate_sequence.nextval;
      
      select count(*)
      into   v_Exists
      from   ACCOUNTING_PERIODS
      where  rownum = 1 and scheme_id = v_Scheme_ID and from_date = TO_DATE('01-JUL-14') and PERIOD_TYPE = 'FISCAL_YEAR';

      dbms_output.put_line('EXISTS 2014 '|| v_Exists);
      
      if (v_Exists = 1) then
         begin
           v_Exists := 0; 
         end;
      else
         begin
            if (v_Scheme_ID < 1359) then
               begin
                  v_Count := hibernate_sequence.nextval;

                  insert into ACCOUNTING_PERIODS(ID, FROM_DATE,PERIOD_STATUS,PERIOD_TYPE,SEQ,TO_DATE,PARENT_ID, SCHEME_ID)
                  select v_Count,TO_DATE('01-JUL-14'),'OPEN','FISCAL_YEAR',v_Max_ID,TO_DATE('30-JUN-15'),v_Count, v_Scheme_ID FROM DUAL;
            
                  COMMIT;
               end;
            end if;
         end;
      end if;
      
      v_Max_ID:= v_Max_ID + 1;
      v_Exists := 0;
      v_Count := hibernate_sequence.nextval;
      
      select count(*)
      into   v_Exists
      from   ACCOUNTING_PERIODS
      where  rownum = 1 and scheme_id = v_Scheme_ID and from_date = TO_DATE('01-JUL-15') and PERIOD_TYPE = 'FISCAL_YEAR';

      dbms_output.put_line('EXISTS 2015 '|| v_Exists);
      
      if (v_Exists = 1) then
         begin
           v_Exists := 0;
         end;
      else 
         begin
            if (v_Scheme_ID < 1359) then
               begin
                 v_Count := hibernate_sequence.nextval;

                 insert into ACCOUNTING_PERIODS(ID, FROM_DATE,PERIOD_STATUS,PERIOD_TYPE,SEQ,TO_DATE,PARENT_ID, SCHEME_ID)
                 select v_Count,TO_DATE('01-JUL-15'),'OPEN','FISCAL_YEAR',v_Max_ID,TO_DATE('30-JUN-16'),v_Count, v_Scheme_ID FROM DUAL;
            
			           COMMIT;
               end;
            end if;
         end;
      end if;
      
      v_Max_ID:= v_Max_ID + 1;
      v_Count := hibernate_sequence.nextval;
      

      insert into ACCOUNTING_PERIODS(ID, FROM_DATE,PERIOD_STATUS,PERIOD_TYPE,SEQ,TO_DATE,PARENT_ID, SCHEME_ID)
      select v_Count,TO_DATE('01-JUL-16'),'OPEN','FISCAL_YEAR',v_Max_ID,TO_DATE('30-JUN-17'),v_Count, v_Scheme_ID FROM DUAL;
            
			COMMIT;

			v_Max_ID:= v_Max_ID + 1;
			v_Count := hibernate_sequence.nextval;

			insert into ACCOUNTING_PERIODS(ID, FROM_DATE,PERIOD_STATUS,PERIOD_TYPE,SEQ,TO_DATE,PARENT_ID, SCHEME_ID)
	        select v_Count,TO_DATE('01-JUL-2017'),'OPEN','FISCAL_YEAR',v_Max_ID,TO_DATE('30-JUN-2018'),v_Count, v_Scheme_ID FROM DUAL;
            
			COMMIT;

    v_Max_ID := 0;
	  v_Scheme_ID := 0;
    
  end loop;
  close cont_kengen1;
end;


/

