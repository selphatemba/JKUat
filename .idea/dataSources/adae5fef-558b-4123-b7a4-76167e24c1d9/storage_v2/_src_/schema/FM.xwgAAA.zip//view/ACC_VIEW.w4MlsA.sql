create view ACC_VIEW as
SELECT 
        node.id, 
        ((COUNT(parent.name) - 1) ) as lvl, 
        node.name AS name, 
        parent.name Name1, 
        node.lft,
        node.rgt,
        node.account_type,
        node.code,
        node.CATEGORY, 
        node.frhd_id, 
        node.active,
        node.status,
        node.cf_header,
        node.REVALUE_ACCT,
        node.REVALACCT_ID,
        node.SRCCURRENCY_ID,
        node.scheme_id
    FROM 
        accounts node, 
        accounts parent 
    WHERE node.lft 
    BETWEEN parent.lft AND parent.rgt and parent.lft>1 and parent.active=1 and node.active=1 
    GROUP BY 
        node.id,
        node.name,
        node.lft,
        node.rgt,
        node.account_type,
        node.code,
        node.CATEGORY, 
        node.frhd_id, 
        parent.name,
        parent.lft, 
        node.active,
        node.status,
        node.cf_header,
        node.REVALUE_ACCT,
        node.REVALACCT_ID,
        node.SRCCURRENCY_ID,
        node.scheme_id
    ORDER BY node.lft, parent.lft


/

