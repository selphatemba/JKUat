create procedure Load_Contributions is
V_Scheme_ID NUMBER(19);
V_MemberNo Number(19);
v_avc number(19,4);
v_avcer number(19,4);
v_ee number(19,4);
v_er number(19,4);
v_date_paid DATE;
v_month number(19);
v_salary number(19,4);
v_salary_type varchar2(50);
v_status varchar2(50);
v_type varchar2(50);
v_year number(19);
v_accountingperiod_id number(19);
v_Month_Name varchar2(50);
v_Member_ID number(19);
v_count number(19);
v_ID number(19);
cursor cont_kengen1 is 

select ID,Scheme_ID,MemberNo,avc,avcer,ee,er,date_paid,month,salary,salary_type,status,type,year
from etl_contributions 
where MemberNo> 0 and (avc + avcer + ee + er) > 0 and Scheme_ID > 0 AND Scheme_ID =1396 and date_paid is not null
and month > 0 and year > 0 and ID not in (select SEQ from Contributions)
ORDER BY date_paid DESC;

begin
  open cont_kengen1;
  loop
   
   --delete from Contributions;
   
   --select ID from etl_contributions ORDER BY ID;
    
    fetch cont_kengen1 into v_ID,V_Scheme_ID,V_MemberNo,v_avc,v_avcer,v_ee,v_er,v_date_paid,v_month,v_salary,v_salary_type,v_status,v_type,v_year;
    
    exit when cont_kengen1%notfound;
    
    select max(ID) into v_accountingperiod_id FROM ACCOUNTING_PERIODS 
    WHERE scheme_Id = V_Scheme_ID and v_date_paid >= FROM_DATE 
    AND  v_date_paid <= TO_DATE AND PERIOD_TYPE = 'FISCAL_YEAR';
    
    select max(ID) into v_Member_ID from Members where scheme_id = V_Scheme_ID and Member_No = V_MemberNo;
    
    --dbms_output.put_line('Member ID first'|| v_Member_ID);
    
    if v_month = 1 THEN
		   v_Month_Name := 'JAN';
		END IF;

		if v_month = 2 THEN
		   v_Month_Name := 'FEB';
		END IF;

		if v_month = 3 THEN
		   v_Month_Name := 'MAR';
		END IF;

		if v_month = 4 THEN
		   v_Month_Name := 'APR';
		END IF;

		if v_month = 5 THEN
		   v_Month_Name := 'MAY';
		END IF;

		if v_month = 6 THEN
		   v_Month_Name := 'JUN';
		END IF;

		if v_month = 7 THEN
		   v_Month_Name := 'JUL';
		END IF;

		if v_month = 8 THEN
		   v_Month_Name := 'AUG';
		END IF;

		if v_month = 9 THEN
		   v_Month_Name := 'SEP';
		END IF;

		if v_month = 10 THEN
		   v_Month_Name := 'OCT';
		END IF;

		if v_month = 11 THEN
		   v_Month_Name := 'NOV';
		END IF;

		if v_month = 12 THEN
		   v_Month_Name := 'DEC';
		END IF;
 
    if v_accountingperiod_id is null then
       v_accountingperiod_id := 0;
    end if;
    
    if v_Member_ID is null then
       v_Member_ID:=0;
    end if;
    
    --dbms_output.put_line('Scheme NO '|| V_Scheme_ID);
    --dbms_output.put_line('Member NO '|| V_MemberNo);
    dbms_output.put_line('Member ID '|| v_Member_ID);
    dbms_output.put_line('v_accountingperiod_id '|| v_accountingperiod_id);
    
    if ((v_Member_ID > 0) and (v_accountingperiod_id > 0)) then
       BEGIN
           Insert into Contributions (ID,MEMBER_ID,AVC,AVCER,EE,ER,DATE_PAID,DEFICIT,DEFICIT_PENALTY,TAXFREE_EE_AMOUNT,TAXFREE_ER_AMOUNT,EEUNREG,
                           GROUP_LIFE,LIFE_COVER,MONTH,PENALTY,SALARY, SALARY_TYPE,SAVING_EE, SAVING_ER,STATUS,TRANSFER_DEF_AMOUNT,
                           TRANSFER_TAXFREE_UTILIZED,TYPE,UNIT_PRICE,UNITS,YEAR,ACCOUNTINGPERIOD_ID,SEQ)
               values(hibernate_sequence.nextval,v_Member_ID,v_avc,v_avcer,v_ee,v_er,v_date_paid,0,0,0,0,0,
                      0,0,v_Month_Name,0,v_salary,'GIVEN',0,0,v_status,0,0,'NORMAL',0,0,v_year,v_accountingperiod_id,v_ID);
       END;
    END IF;
                           
    commit;
  end loop;
  close cont_kengen1;
end;
/

