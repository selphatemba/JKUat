create procedure Proc_Load_ETL_Claims_4 is
--ALTER TABLE FM.ETL_CLAIMS_1 ADD ID NUMBER(19);
--commit;
--update ETL_CLAIMS_1 SET ID=HIBERNATE_SEQUENCE.nextval;
--COMMIT;
  V_MEMBER_NO VARCHAR2(200);
  V_CONTRYEAR NUMBER(19);
  V_DATEPAID DATE;
  V_EMPLOYEE NUMBER(19,6);
  V_EMPLOYER NUMBER(19,6);
  V_AVC NUMBER(19,2);
  V_AVCEMPLOYER NUMBER(19,2);
  V_TaxFreeEE NUMBER(19,2);
  V_TaxFreeER NUMBER(19,2);
  V_APID NUMBER(19);
  V_SCHEME_ID NUMBER(19);
  v_ID NUMBER(19);
  v_Member_ID number(19);
  v_Reason_ID number(19);
  v_Month_Name varchar2(10);
  V_FULLNAME VARCHAR2(100);
  V_SPONSORNAME VARCHAR2(100);
  V_REASONFOREXIT VARCHAR2(200);
  V_BEN_ID NUMBER(19);
  V_CONTR_ID NUMBER(19);
  V_MEMBERSHIP_STATUS VARCHAR2(200);
  V_UNIT_PRICE NUMBER(19,12);
  V_PRICE_ID NUMBER(19);
  v_tax number(19);
  v_Status varchar(50);
  v_AMOUNT_PAYABLE NUMBER(19,2);
  v_TAX_AMOUNT NUMBER(19,2);

  cursor cont_kengen1 is
   SELECT  m.scheme_id, m.ID as Member_ID,C.ID,coalesce(c.employee,0)CONTRIBUTION,coalesce(c.employer,0)CONTRIBUTION_ER,AVC AVC,AVCEMPLOYER AVCER,m.SURNAME||' '||m.FIRSTNAME name,c.docalc DATE_PAID,
                     (SELECT CATEGORY FROM REASONS_FOR_EXIT WHERE DESCRIPTION LIKE '%'||c.reasondesc||'%' and ROWNUM=1)category,
                     c.month_name Month_name,
                     c.month_year Year3,(SELECT id FROM REASONS_FOR_EXIT WHERE DESCRIPTION LIKE '%'||c.reasondesc||'%' and ROWNUM=1)Reason,
                     (SELECT REASONS_FOR_EXIT.MBSHIP_STATUS FROM REASONS_FOR_EXIT WHERE DESCRIPTION LIKE '%'||c.reasondesc||'%' and ROWNUM=1)mbstatus, m.member_no,coalesce(c.taxpayable,0)taxpayable,
                     0 TAXFREE_EE,c.BenTYPE,coalesce(c.amountpayable,0)amountpayable
FROM ETL_CLAIMS_3 C
  inner join Members m on c.membernO = m.MEMBER_NO
where m.scheme_id=c.schemeno and m.member_no not in(select mr.member_no from members mr where mr.id in(select member_id from benefit_payments) and mr.scheme_id=c.schemeno)  and docalc is not null
order by c.ID ;

  --      SELECT  m.scheme_id, m.ID as Member_ID,C.ID,coalesce(c.employee,0)CONTRIBUTION,coalesce(c.employer,0)CONTRIBUTION_ER,avc AVC,AVCEMPLOYER AVCER,m.SURNAME||' '||m.FIRSTNAME name,c.docalc DATE_PAID,
  --                           (SELECT CATEGORY FROM REASONS_FOR_EXIT WHERE DESCRIPTION LIKE '%'||c.reasondesc||'%' and ROWNUM=1)category,
  --                          c.month_name Month_name,
  --                           c.month_year Year3,(SELECT id FROM REASONS_FOR_EXIT WHERE DESCRIPTION LIKE '%'||c.reasondesc||'%' and ROWNUM=1)Reason,
  --                           (SELECT REASONS_FOR_EXIT.MBSHIP_STATUS FROM REASONS_FOR_EXIT WHERE DESCRIPTION LIKE '%'||c.reasondesc||'%' and ROWNUM=1)mbstatus, m.member_no,coalesce(c.taxpayable,0)taxpayable,
  --                           0 TAXFREE_EE,c.BenTYPE,coalesce(c.amountpayable,0)amountpayable
  --      FROM ETL_CLAIMS C
  --        inner join Members m on c.membernO = m.MEMBER_NO
  --        where  docalc is not null AND C.ID NOT IN (SELECT COMMENTS FROM BENEFITS)
  --        and m.scheme_id in (
  --  1391,
  --  1300,
  --  1248,
  --  1296,
  --  1310,
  --  1252,
  --  1381,
  --  1393,
  --  1355,
  --  1246,
  --  1308,
  --  1360,
  --  1318,
  --  1354,
  --  1365,
  --  1386,
  --  1290,
  --  1263,
  --  1372,
  --  1371,
  --  1231,
  --  1291,
  --  1270,
  --  1286,
  --  1237,
  --  1366,
  --  1379,
  --  1311,
  --  1295,
  --  1297,
  --  1361,
  --  1373,
  --  1319,
  --  1293,
  --  1267,
  --  1359,
  --  1385,
  --  1396,
  --  1256)
  --      order by c.ID ;


  begin
    open cont_kengen1;
    loop
      fetch cont_kengen1 into V_SCHEME_ID,v_Member_ID,v_ID,V_EMPLOYEE, V_EMPLOYER,V_AVC,V_AVCEMPLOYER,V_FULLNAME,V_DATEPAID,
      V_REASONFOREXIT, v_Month_Name,V_CONTRYEAR,v_Reason_ID,V_MEMBERSHIP_STATUS,V_MEMBER_NO,v_tax,V_TaxFreeEE,v_Status,v_AMOUNT_PAYABLE;

      exit when cont_kengen1%notfound;


      select MIN(ID) into V_APID FROM ACCOUNTING_PERIODS WHERE scheme_Id = V_SCHEME_ID
                                                               and V_DATEPAID >= FROM_DATE AND  V_DATEPAID <= TO_DATE AND PERIOD_TYPE = 'FISCAL_YEAR';

      SELECT hibernate_sequence.nextval INTO V_BEN_ID FROM DUAL;
      SELECT hibernate_sequence.nextval INTO V_CONTR_ID FROM DUAL;

      if(V_REASONFOREXIT='RETIREMENT') THEN
        V_EMPLOYEE:=(V_EMPLOYEE/3);
        V_EMPLOYER:=(V_EMPLOYER/3);
        V_AVC:=(V_AVC/3);
        V_AVCEMPLOYER:=(V_AVCEMPLOYER/3);
      end if;


      if(v_Member_ID>0 and V_APID > 0 ) then

        Insert into Benefits(ID,AVC,AVC_BAL,AVC_TOT_ONLY, AVCER,AVCER_BAL,AVCER_TOT_ONLY,EE,EE_BAL,EE_TOT,EE_TOT_ONLY,ENTITLEMENT,
                             ER,ER_BAL,ER_TOT,ER_TOT_ONLY,TOT_BENEFITS,YEARS_WORKED,REASONFOREXIT_ID,DATE_OF_CALCULATION,DATE_OF_EXIT,
                             AGE_AT_EXIT,MEMBER_ID,MEMBER_NO,COMMENTS, NEW_EXIT, PROCESSED,DATE_PREPARED, DATE_APPROVED, DATE_CERTIFIED, DATE_AUTHORIZED,
                             AUTHORIZEDBY_ID, APPROVEDBY_ID, CERTIFIEDBY_ID, REFERENCE_NO, DATE_CALCULATED)

        VALUES(V_BEN_ID,V_AVC,V_AVC,V_AVC,V_AVCEMPLOYER,V_AVCEMPLOYER,V_AVCEMPLOYER,V_EMPLOYEE,V_EMPLOYEE,V_EMPLOYEE,V_EMPLOYEE,
          100,V_EMPLOYER,V_EMPLOYER,V_EMPLOYER,V_EMPLOYER,V_AVC+V_AVCEMPLOYER+V_EMPLOYEE+V_EMPLOYER,
          0,v_Reason_ID,V_DATEPAID,V_DATEPAID,0,v_Member_ID,V_MEMBER_NO,v_ID,1,0,V_DATEPAID,null,V_DATEPAID,null, null, null,3347,V_MEMBER_NO,V_DATEPAID);

        commit;


        Insert into Contributions (ID,MEMBER_ID,AVC,AVCER,EE,ER,DATE_PAID,DEFICIT,DEFICIT_PENALTY,TAXFREE_EE_AMOUNT,TAXFREE_ER_AMOUNT,EEUNREG,
                                   GROUP_LIFE,LIFE_COVER,MONTH,PENALTY,SALARY, SALARY_TYPE,SAVING_EE, SAVING_ER,STATUS,TRANSFER_DEF_AMOUNT,
                                   TRANSFER_TAXFREE_UTILIZED,TYPE,UNIT_PRICE,UNITS,YEAR,ACCOUNTINGPERIOD_ID,NSSF,SEQ)

        values(V_CONTR_ID,v_Member_ID,V_AVC,V_AVCEMPLOYER,V_EMPLOYEE*-1,V_EMPLOYER*-1,V_DATEPAID,0,0,V_TaxFreeEE*-1,0,0,
                                                                                                                      0,0,v_Month_Name,0,0,'GIVEN',0,0,v_Status,0,0,
               'BENEFIT_PAYMENT',0,0,V_CONTRYEAR,V_APID,0,v_ID);


        commit;

        --v_Payment := 0-v_Payment;

        insert into Benefit_Payments(ID,DATE_OF_CALC,DATE_PROCESSED,IS_FIRST_PAYMENT,GROSS,IS_TRUST_FUND,LUMPSUM,LUMPSUM_TAX_FREE,
                                     REG_EE, REG_ER,REG_AVC,REG_AVCER,REG_NET,REG_TAX,PAYEE,MEMBER_ID,SCHEME_ID,
                                     TYPE,COMMENTS,SERVICE_PERIOD,TAXABLE_AMNT,WITHOLDING_TAX,NET_B4_LIAB, NET_PAYMENT,BENEFIT_ID,REGCONTR_ID)

        VALUES(hibernate_sequence.nextval,V_DATEPAID,V_DATEPAID,0,V_AVC+V_AVCEMPLOYER+V_EMPLOYEE+V_EMPLOYER,'NO',
                                          V_AVC+V_AVCEMPLOYER+V_EMPLOYEE+V_EMPLOYER,V_AVC+V_AVCEMPLOYER+V_EMPLOYEE+V_EMPLOYER,V_EMPLOYEE,V_EMPLOYER,
                                          V_AVC,V_AVCEMPLOYER,V_AVC+V_AVCEMPLOYER+V_EMPLOYEE+V_EMPLOYER,0,V_FULLNAME,v_Member_ID,V_SCHEME_ID,
                                                (case when V_REASONFOREXIT ='WITHDRAWAL' then 'WITHDRAWAL'  when  V_REASONFOREXIT='RETIREMENT' then 'RETIREMENT_BENEFITS'
                                                 when V_REASONFOREXIT='DEATH_IN_SERVICE' then 'DEATH_BENEFITS' else 'WITHDRAWAL' end) ,v_ID,0,V_AVC+V_AVCEMPLOYER+V_EMPLOYEE+V_EMPLOYER,v_tax,
               V_AVC+V_AVCEMPLOYER+V_EMPLOYEE+V_EMPLOYER,V_AVC+V_AVCEMPLOYER+V_EMPLOYEE+V_EMPLOYER-v_tax,V_BEN_ID,V_CONTR_ID);

        commit;

        update MEMBERS set MBSHIP_STATUS=V_MEMBERSHIP_STATUS, EXIT_ID=V_BEN_ID where id=v_Member_ID;

        commit;
      END IF;
      V_BEN_ID := 0;
      v_Member_ID:= 0;

    end loop;
    close cont_kengen1;
  end;
/

