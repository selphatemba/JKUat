create procedure Proc_Update_deffered is
  v_MONTH NUMBER(19);
    v_DEFFERED_REG NUMBER(19,2);
    v_DEFFERED_UNREG NUMBER(19,2);
    v_MEMBER_NO NUMBER(19);


  cursor cont_kengen1 is
    select m.member_no,
      COALESCE( cast (months_between ((select b.DATE_OF_EXIT from BENEFITS b where b.id=m.EXIT_ID),
                                      (m.DATE_JOINED_SCHEME)) as INTEGER),0)mths,
      coalesce(b.UNREG_ER,0),coalesce(b.ER,0)
    FROM members m INNER JOIN benefits b on b.id=m.EXIT_ID
      INNER JOIN REASONS_FOR_EXIT r on r.id=b.REASONFOREXIT_ID
    where  r.CATEGORY='WITHDRAWAL' and APPLY_DEFMNT='YES';
    begin
      open cont_kengen1;
      loop
        fetch cont_kengen1 INTO v_MEMBER_NO,V_MONTH,v_DEFFERED_UNREG,v_DEFFERED_REG;
        exit when cont_kengen1%notfound;
        if(v_MONTH>11) THEN
          v_DEFFERED_UNREG:=(v_DEFFERED_UNREG/2);
--          v_DEFFERED_REG:=(v_DEFFERED_REG/2);
        end if;
        if(v_MONTH>11)
        THEN
          UPDATE BENEFITS SET DEFERREDUNREG=v_DEFFERED_UNREG where member_no=v_MEMBER_NO;
          commit;
        end if;
        v_MEMBER_NO := 0;
      end loop;
      close cont_kengen1;
    end;
/

