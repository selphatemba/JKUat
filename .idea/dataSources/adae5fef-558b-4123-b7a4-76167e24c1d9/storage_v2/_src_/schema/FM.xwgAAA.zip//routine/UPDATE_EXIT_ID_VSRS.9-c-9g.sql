create procedure Update_Exit_Id_vsrs is
v_Benefit_ID Number(19);
v_member_ID Number(19);
v_Ben_ID Number(19);

cursor proc_update_exit_id is 

 select b.id,b.member_id,b.benefit_id
 from BENEFIT_PAYMENTS b;
       

begin
  open proc_update_exit_id;
  loop
    fetch proc_update_exit_id into v_Benefit_ID,v_member_ID,v_Ben_ID;
    
    exit when proc_update_exit_id%notfound;
  
    
    UPDATE MEMBERS SET EXIT_ID = v_Ben_ID WHERE id = v_member_ID;
        
    commit;
    
  end loop;
  close proc_update_exit_id;
end;
/

