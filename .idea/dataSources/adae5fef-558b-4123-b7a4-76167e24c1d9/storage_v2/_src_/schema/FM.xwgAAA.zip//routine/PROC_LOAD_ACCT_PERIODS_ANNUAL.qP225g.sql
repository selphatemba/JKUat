create procedure Proc_Load_Acct_Periods_Annual is
v_Scheme_ID number(19);
v_Count number(19);
v_ID number(19);
v_Max_ID number(19);
v_FROM_DATE DATE;
v_TO_DATE DATE;

cursor cont_kengen1 is  
select SCHEME_ID, FROM_DATE, TO_DATE 
from ETL_PERIODS WHERE SCHEME_ID > 1222
order by SCHEME_ID, FROM_DATE;

begin
  open cont_kengen1;
  loop
    fetch cont_kengen1 into v_Scheme_ID,v_FROM_DATE,v_TO_DATE;

    exit when cont_kengen1%notfound;

    v_Max_ID := 0;

	/*
	IF v_Scheme_ID < 1359 THEN
       select max(SEQ) into v_Max_ID from ACCOUNTING_PERIODS where SCHEME_ID = v_Scheme_ID;
	ELSE
	   v_Max_ID:= 0;
	END IF;
	*/

			v_Max_ID:= v_Max_ID + 1;
			v_Count := hibernate_sequence.nextval;

			insert into ACCOUNTING_PERIODS(ID, FROM_DATE,PERIOD_STATUS,PERIOD_TYPE,SEQ,TO_DATE,PARENT_ID, SCHEME_ID)
	        select v_Count,v_FROM_DATE,'OPEN','FISCAL_YEAR',v_Max_ID,v_TO_DATE,v_Count, v_Scheme_ID FROM DUAL;

			COMMIT;

    v_Max_ID := 0;
	v_Scheme_ID := 0;

  end loop;
  close cont_kengen1;
end;
/

