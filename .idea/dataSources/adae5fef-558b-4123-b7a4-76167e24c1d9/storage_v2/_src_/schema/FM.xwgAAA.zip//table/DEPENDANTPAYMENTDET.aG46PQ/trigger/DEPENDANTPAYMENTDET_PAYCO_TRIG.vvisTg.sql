create trigger DEPENDANTPAYMENTDET_PAYCO_TRIG
  before insert or update
  on DEPENDANTPAYMENTDET
  for each row
DECLARE 
v_newVal NUMBER(12) := 0;
v_incval NUMBER(12) := 0;
BEGIN
  IF INSERTING AND :new.PayCounter IS NULL THEN
    SELECT  DependantPaymentDet_PayCou_SEQ.NEXTVAL INTO v_newVal FROM DUAL;
    -- If this is the first time this table have been inserted into (sequence == 1)
    IF v_newVal = 1 THEN 
      --get the max indentity value from the table
      SELECT NVL(max(PayCounter),0) INTO v_newVal FROM DependantPaymentDet;
      v_newVal := v_newVal + 1;
      --set the sequence to that value
      LOOP
           EXIT WHEN v_incval>=v_newVal;
           SELECT DependantPaymentDet_PayCou_SEQ.nextval INTO v_incval FROM dual;
      END LOOP;
    END IF;
   -- assign the value from the sequence to emulate the identity column
   :new.PayCounter := v_newVal;
  END IF;
END;


/

