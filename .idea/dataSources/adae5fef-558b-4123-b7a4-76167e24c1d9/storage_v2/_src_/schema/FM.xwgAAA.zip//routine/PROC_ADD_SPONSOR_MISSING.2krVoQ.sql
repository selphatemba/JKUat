create procedure proc_add_sponsor_Missing is
v_scheme_id number(19);
v_name varchar2(200);
v_SCHEME_NUMBER varchar2(50); 
v_SPONSOR_PROD_NO varchar2(50);

cursor cont_kengen1 is 
SELECT E.SCHEME_ID,e.NAME,e.Employer_Ref_No 
from ETL_SPONSORS e
WHERE e.SCHEME_ID NOT IN (SELECT SCHEME_ID FROM SPONSORS) AND SCHEME_ID <> 1396
order by e.SCHEME_ID;

begin
  open cont_kengen1;
  loop
    fetch cont_kengen1 into v_scheme_id,v_name, v_SPONSOR_PROD_NO;

    exit when cont_kengen1%notfound;
    
	Insert into Sponsors(id,scheme_id,building,cell_phone,country,email,fax,fixed_phone,postal_address,road,town, employer_ref_no,Inspector,
                         MEMBERS_SPONSORED,name, pin, region, supervisor, depot, region_addr, sub_region, Residential_address,
					     SPONSOR_PROD_NO)
    
	select hibernate_sequence.nextval,v_scheme_id,building,cell_phone,country,email,fax,fixed_phone,postal_address,road,town, 
          Employer_Ref_No,Inspector,MEMBERS_SPONSORED,
          NAME, pin, region, supervisor, depot, region_addr, sub_region, Residential_address,Employer_Ref_No
          from ETL_SPONSORS
	where scheme_id = v_scheme_id; 

    commit;

    v_scheme_id := 0;
	v_SCHEME_NUMBER := '';
    v_name :='';
	v_SPONSOR_PROD_NO :='';
    
 
  end loop;
  close cont_kengen1;
end;


/

